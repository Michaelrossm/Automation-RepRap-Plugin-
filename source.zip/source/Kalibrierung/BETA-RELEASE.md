# Beta Release Hinweise

## Build-Check
- Plugin bauen mit:
  - `npm run build-plugin -- Kalibrierung`
- Erwartetes Artifact:
  - `dist/Kalibrierung-<version>.zip`

## Bekannte Einschraenkungen
- Bei aktiver `daemon.g` darf die Datei waehrend Ausfuehrung nicht geloescht werden.
- Neue Daemon- und Moduldateien werden in-place aktualisiert; Laufzeitdaten bleiben im RAM.
- PID-Reihen brauchen reale Heizstabilitaet; Hardware-Schutz (Thermistor, Heater) bleibt Pflicht.

## Beta-Testliste (Kurz)
1. Daemon-Module EIN/AUS toggeln und Datei-Updates pruefen.
2. LED-Statuswechsel (idle/heating/printing/error) pruefen.
3. PID-Serie mit einem Heater und optionalem Luefter pruefen.
4. Level-Test starten, Live-Z-Offset veraendern, Offset speichern pruefen.

## Backup-Hinweis
- Vor Installation ein komplettes Backup von `/sys` und relevanten Makros erstellen.
