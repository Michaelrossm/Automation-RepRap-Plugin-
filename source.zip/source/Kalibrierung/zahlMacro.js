export default String.raw`; Zahl.g  (RRF 3.6.2)
; Draws a value using 7-segment style strokes
;
; Required:
;   X = start X
;   Y = start Y
;   V = value
;
; Optional:
;   Q = decimals (default 0)
;   W = digit width
;   H = digit height
;   G = gap
;   Z = fixed Z
;   F = draw feed (mm/min)
;   T = travel feed (mm/min)
;
; Required globals:
;   global.eTotal
;   global.ePerMM

if !exists(param.X) || !exists(param.Y) || !exists(param.V)
  abort "Usage: M98 P""0:/sys/flow-zahl.g"" X.. Y.. V.. [Q..] [W..] [H..] [G..] [Z..] [F..] [T..]"

if !exists(global.eTotal)
  abort "Missing global.eTotal"
if !exists(global.ePerMM)
  abort "Missing global.ePerMM"

var x = param.X
var y = param.Y
var value = param.V

var decimals = 0
if exists(param.Q)
  set var.decimals = floor(param.Q)
  if var.decimals < 0
    set var.decimals = 0

var w = 4
if exists(global.digitW)
  set var.w = global.digitW
if exists(param.W)
  set var.w = param.W

var h = 8
if exists(global.digitH)
  set var.h = global.digitH
if exists(param.H)
  set var.h = param.H

var gap = 1.5
if exists(param.G)
  set var.gap = param.G

var fDraw = 2400
if exists(param.F)
  set var.fDraw = param.F

var fMove = 9000
if exists(param.T)
  set var.fMove = param.T

var z = move.axes[2].machinePosition
if exists(param.Z)
  set var.z = param.Z

var zHop = 0.3
var retract = 0.2
var fRetract = 1800
var fZ = 1200

var cursor = var.x
var isNeg = 0
if var.value < 0
  set var.isNeg = 1

var absVal = abs(var.value)
var scale = pow(10, var.decimals)
var scaled = round(var.absVal * var.scale)
var intPart = floor(var.scaled / var.scale)
var fracPart = mod(var.scaled, var.scale)

if var.isNeg = 1
  if global.eTotal >= var.retract
    set global.eTotal = global.eTotal - var.retract
  else
    set global.eTotal = 0
  G1 E{global.eTotal} F{var.fRetract}

  if move.axes[2].homed
    G1 Z{var.z + var.zHop} F{var.fZ}
  G1 X{var.cursor} Y{var.y + (var.h / 2)} F{var.fMove}
  if move.axes[2].homed
    G1 Z{var.z} F{var.fZ}

  set global.eTotal = global.eTotal + var.retract
  G1 E{global.eTotal} F{var.fRetract}

  set global.eTotal = global.eTotal + (global.ePerMM * var.w)
  G1 X{var.cursor + var.w} Y{var.y + (var.h / 2)} F{var.fDraw} E{global.eTotal}
  set var.cursor = var.cursor + var.w + var.gap

if var.intPart = 0
  var digit = 0

  var segA = 1
  var segB = 1
  var segC = 1
  var segD = 1
  var segE = 1
  var segF = 1
  var segG = 0

  if var.segA = 1
    if global.eTotal >= var.retract
      set global.eTotal = global.eTotal - var.retract
    else
      set global.eTotal = 0
    G1 E{global.eTotal} F{var.fRetract}
    if move.axes[2].homed
      G1 Z{var.z + var.zHop} F{var.fZ}
    G1 X{var.cursor} Y{var.y + var.h} F{var.fMove}
    if move.axes[2].homed
      G1 Z{var.z} F{var.fZ}
    set global.eTotal = global.eTotal + var.retract
    G1 E{global.eTotal} F{var.fRetract}
    set global.eTotal = global.eTotal + (global.ePerMM * var.w)
    G1 X{var.cursor + var.w} Y{var.y + var.h} F{var.fDraw} E{global.eTotal}

  if var.segB = 1
    if global.eTotal >= var.retract
      set global.eTotal = global.eTotal - var.retract
    else
      set global.eTotal = 0
    G1 E{global.eTotal} F{var.fRetract}
    if move.axes[2].homed
      G1 Z{var.z + var.zHop} F{var.fZ}
    G1 X{var.cursor + var.w} Y{var.y + var.h} F{var.fMove}
    if move.axes[2].homed
      G1 Z{var.z} F{var.fZ}
    set global.eTotal = global.eTotal + var.retract
    G1 E{global.eTotal} F{var.fRetract}
    set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
    G1 X{var.cursor + var.w} Y{var.y + (var.h / 2)} F{var.fDraw} E{global.eTotal}

  if var.segC = 1
    if global.eTotal >= var.retract
      set global.eTotal = global.eTotal - var.retract
    else
      set global.eTotal = 0
    G1 E{global.eTotal} F{var.fRetract}
    if move.axes[2].homed
      G1 Z{var.z + var.zHop} F{var.fZ}
    G1 X{var.cursor + var.w} Y{var.y + (var.h / 2)} F{var.fMove}
    if move.axes[2].homed
      G1 Z{var.z} F{var.fZ}
    set global.eTotal = global.eTotal + var.retract
    G1 E{global.eTotal} F{var.fRetract}
    set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
    G1 X{var.cursor + var.w} Y{var.y} F{var.fDraw} E{global.eTotal}

  if var.segD = 1
    if global.eTotal >= var.retract
      set global.eTotal = global.eTotal - var.retract
    else
      set global.eTotal = 0
    G1 E{global.eTotal} F{var.fRetract}
    if move.axes[2].homed
      G1 Z{var.z + var.zHop} F{var.fZ}
    G1 X{var.cursor} Y{var.y} F{var.fMove}
    if move.axes[2].homed
      G1 Z{var.z} F{var.fZ}
    set global.eTotal = global.eTotal + var.retract
    G1 E{global.eTotal} F{var.fRetract}
    set global.eTotal = global.eTotal + (global.ePerMM * var.w)
    G1 X{var.cursor + var.w} Y{var.y} F{var.fDraw} E{global.eTotal}

  if var.segE = 1
    if global.eTotal >= var.retract
      set global.eTotal = global.eTotal - var.retract
    else
      set global.eTotal = 0
    G1 E{global.eTotal} F{var.fRetract}
    if move.axes[2].homed
      G1 Z{var.z + var.zHop} F{var.fZ}
    G1 X{var.cursor} Y{var.y + (var.h / 2)} F{var.fMove}
    if move.axes[2].homed
      G1 Z{var.z} F{var.fZ}
    set global.eTotal = global.eTotal + var.retract
    G1 E{global.eTotal} F{var.fRetract}
    set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
    G1 X{var.cursor} Y{var.y} F{var.fDraw} E{global.eTotal}

  if var.segF = 1
    if global.eTotal >= var.retract
      set global.eTotal = global.eTotal - var.retract
    else
      set global.eTotal = 0
    G1 E{global.eTotal} F{var.fRetract}
    if move.axes[2].homed
      G1 Z{var.z + var.zHop} F{var.fZ}
    G1 X{var.cursor} Y{var.y + var.h} F{var.fMove}
    if move.axes[2].homed
      G1 Z{var.z} F{var.fZ}
    set global.eTotal = global.eTotal + var.retract
    G1 E{global.eTotal} F{var.fRetract}
    set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
    G1 X{var.cursor} Y{var.y + (var.h / 2)} F{var.fDraw} E{global.eTotal}

  if var.segG = 1
    if global.eTotal >= var.retract
      set global.eTotal = global.eTotal - var.retract
    else
      set global.eTotal = 0
    G1 E{global.eTotal} F{var.fRetract}
    if move.axes[2].homed
      G1 Z{var.z + var.zHop} F{var.fZ}
    G1 X{var.cursor} Y{var.y + (var.h / 2)} F{var.fMove}
    if move.axes[2].homed
      G1 Z{var.z} F{var.fZ}
    set global.eTotal = global.eTotal + var.retract
    G1 E{global.eTotal} F{var.fRetract}
    set global.eTotal = global.eTotal + (global.ePerMM * var.w)
    G1 X{var.cursor + var.w} Y{var.y + (var.h / 2)} F{var.fDraw} E{global.eTotal}

  set var.cursor = var.cursor + var.w + var.gap

else
  var div = 1
  while floor(var.intPart / var.div) >= 10
    set var.div = var.div * 10

  while var.div >= 1
    var digit = mod(floor(var.intPart / var.div), 10)
    var segA = 0
    var segB = 0
    var segC = 0
    var segD = 0
    var segE = 0
    var segF = 0
    var segG = 0

    if var.digit = 0
      set var.segA = 1
      set var.segB = 1
      set var.segC = 1
      set var.segD = 1
      set var.segE = 1
      set var.segF = 1
    elif var.digit = 1
      set var.segB = 1
      set var.segC = 1
    elif var.digit = 2
      set var.segA = 1
      set var.segB = 1
      set var.segG = 1
      set var.segE = 1
      set var.segD = 1
    elif var.digit = 3
      set var.segA = 1
      set var.segB = 1
      set var.segG = 1
      set var.segC = 1
      set var.segD = 1
    elif var.digit = 4
      set var.segF = 1
      set var.segG = 1
      set var.segB = 1
      set var.segC = 1
    elif var.digit = 5
      set var.segA = 1
      set var.segF = 1
      set var.segG = 1
      set var.segC = 1
      set var.segD = 1
    elif var.digit = 6
      set var.segA = 1
      set var.segF = 1
      set var.segG = 1
      set var.segC = 1
      set var.segD = 1
      set var.segE = 1
    elif var.digit = 7
      set var.segA = 1
      set var.segB = 1
      set var.segC = 1
    elif var.digit = 8
      set var.segA = 1
      set var.segB = 1
      set var.segC = 1
      set var.segD = 1
      set var.segE = 1
      set var.segF = 1
      set var.segG = 1
    elif var.digit = 9
      set var.segA = 1
      set var.segB = 1
      set var.segC = 1
      set var.segD = 1
      set var.segF = 1
      set var.segG = 1

    if var.segA = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor} Y{var.y + var.h} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * var.w)
      G1 X{var.cursor + var.w} Y{var.y + var.h} F{var.fDraw} E{global.eTotal}

    if var.segB = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor + var.w} Y{var.y + var.h} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
      G1 X{var.cursor + var.w} Y{var.y + (var.h / 2)} F{var.fDraw} E{global.eTotal}

    if var.segC = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor + var.w} Y{var.y + (var.h / 2)} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
      G1 X{var.cursor + var.w} Y{var.y} F{var.fDraw} E{global.eTotal}

    if var.segD = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor} Y{var.y} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * var.w)
      G1 X{var.cursor + var.w} Y{var.y} F{var.fDraw} E{global.eTotal}

    if var.segE = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor} Y{var.y + (var.h / 2)} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
      G1 X{var.cursor} Y{var.y} F{var.fDraw} E{global.eTotal}

    if var.segF = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor} Y{var.y + var.h} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
      G1 X{var.cursor} Y{var.y + (var.h / 2)} F{var.fDraw} E{global.eTotal}

    if var.segG = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor} Y{var.y + (var.h / 2)} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * var.w)
      G1 X{var.cursor + var.w} Y{var.y + (var.h / 2)} F{var.fDraw} E{global.eTotal}

    set var.cursor = var.cursor + var.w + var.gap
    set var.div = floor(var.div / 10)

if var.decimals > 0
  var dotLen = var.w * 0.18
  if var.dotLen < 0.6
    set var.dotLen = 0.6

  if global.eTotal >= var.retract
    set global.eTotal = global.eTotal - var.retract
  else
    set global.eTotal = 0
  G1 E{global.eTotal} F{var.fRetract}
  if move.axes[2].homed
    G1 Z{var.z + var.zHop} F{var.fZ}
  G1 X{var.cursor} Y{var.y} F{var.fMove}
  if move.axes[2].homed
    G1 Z{var.z} F{var.fZ}
  set global.eTotal = global.eTotal + var.retract
  G1 E{global.eTotal} F{var.fRetract}

  set global.eTotal = global.eTotal + (global.ePerMM * var.dotLen)
  G1 X{var.cursor + var.dotLen} Y{var.y} F{var.fDraw} E{global.eTotal}
  set var.cursor = var.cursor + var.dotLen + var.gap

  var fracDiv = floor(var.scale / 10)
  while var.fracDiv >= 1
    var digit = mod(floor(var.fracPart / var.fracDiv), 10)
    var segA = 0
    var segB = 0
    var segC = 0
    var segD = 0
    var segE = 0
    var segF = 0
    var segG = 0

    if var.digit = 0
      set var.segA = 1
      set var.segB = 1
      set var.segC = 1
      set var.segD = 1
      set var.segE = 1
      set var.segF = 1
    elif var.digit = 1
      set var.segB = 1
      set var.segC = 1
    elif var.digit = 2
      set var.segA = 1
      set var.segB = 1
      set var.segG = 1
      set var.segE = 1
      set var.segD = 1
    elif var.digit = 3
      set var.segA = 1
      set var.segB = 1
      set var.segG = 1
      set var.segC = 1
      set var.segD = 1
    elif var.digit = 4
      set var.segF = 1
      set var.segG = 1
      set var.segB = 1
      set var.segC = 1
    elif var.digit = 5
      set var.segA = 1
      set var.segF = 1
      set var.segG = 1
      set var.segC = 1
      set var.segD = 1
    elif var.digit = 6
      set var.segA = 1
      set var.segF = 1
      set var.segG = 1
      set var.segC = 1
      set var.segD = 1
      set var.segE = 1
    elif var.digit = 7
      set var.segA = 1
      set var.segB = 1
      set var.segC = 1
    elif var.digit = 8
      set var.segA = 1
      set var.segB = 1
      set var.segC = 1
      set var.segD = 1
      set var.segE = 1
      set var.segF = 1
      set var.segG = 1
    elif var.digit = 9
      set var.segA = 1
      set var.segB = 1
      set var.segC = 1
      set var.segD = 1
      set var.segF = 1
      set var.segG = 1

    if var.segA = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor} Y{var.y + var.h} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * var.w)
      G1 X{var.cursor + var.w} Y{var.y + var.h} F{var.fDraw} E{global.eTotal}

    if var.segB = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor + var.w} Y{var.y + var.h} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
      G1 X{var.cursor + var.w} Y{var.y + (var.h / 2)} F{var.fDraw} E{global.eTotal}

    if var.segC = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor + var.w} Y{var.y + (var.h / 2)} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
      G1 X{var.cursor + var.w} Y{var.y} F{var.fDraw} E{global.eTotal}

    if var.segD = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor} Y{var.y} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * var.w)
      G1 X{var.cursor + var.w} Y{var.y} F{var.fDraw} E{global.eTotal}

    if var.segE = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor} Y{var.y + (var.h / 2)} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
      G1 X{var.cursor} Y{var.y} F{var.fDraw} E{global.eTotal}

    if var.segF = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor} Y{var.y + var.h} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * (var.h / 2))
      G1 X{var.cursor} Y{var.y + (var.h / 2)} F{var.fDraw} E{global.eTotal}

    if var.segG = 1
      if global.eTotal >= var.retract
        set global.eTotal = global.eTotal - var.retract
      else
        set global.eTotal = 0
      G1 E{global.eTotal} F{var.fRetract}
      if move.axes[2].homed
        G1 Z{var.z + var.zHop} F{var.fZ}
      G1 X{var.cursor} Y{var.y + (var.h / 2)} F{var.fMove}
      if move.axes[2].homed
        G1 Z{var.z} F{var.fZ}
      set global.eTotal = global.eTotal + var.retract
      G1 E{global.eTotal} F{var.fRetract}
      set global.eTotal = global.eTotal + (global.ePerMM * var.w)
      G1 X{var.cursor + var.w} Y{var.y + (var.h / 2)} F{var.fDraw} E{global.eTotal}

    set var.cursor = var.cursor + var.w + var.gap
    set var.fracDiv = floor(var.fracDiv / 10)
`;
