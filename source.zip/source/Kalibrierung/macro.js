export default String.raw`; ===== Flow-plätchen (RRF 3.6.2) =====
; Beispiel:
; M98 P"0:/sys/flow-plaettchen.g" H210 B55 N0.4 C90 D4 R1 F40
;
; Druckt Flow-Test-Plättchen mit unterschiedlichen M221-Werten.
; Die Plättchen werden automatisch mittig im Bauraum angeordnet.
; Maximal 5 Pads pro Reihe, weitere Pads in neuer Reihe.
; Druck erfolgt lagenweise über alle Pads, um Kollisionen zu vermeiden.
; Beschriftung erfolgt über:
;   0:/sys/flow-zahl.g

var hotendTemp = 215
var bedTemp    = 60

var nozzleDia  = 0.4
var lineW      = 0.0
var layerH     = 0.20
var centerFlow = 90
var deltaFlow  = 4
var stepFlow   = 1
var fanPct     = 0
var fanS       = 0.0
var padSize    = 18
var gap        = 4
var padLayers  = 6
var margin     = 5

var offsetX    = 0
var offsetY    = 0

var travelRetract = 0.20
var travelZhop    = 0.30
var fRetract      = 1800
var fZ            = 1200
var fMove         = 9000
var fDraw         = 2400

if exists(param.H)
  set var.hotendTemp = param.H
if exists(param.B)
  set var.bedTemp = param.B
if exists(param.N)
  set var.nozzleDia = param.N
if exists(param.W)
  set var.lineW = param.W
if exists(param.L)
  set var.layerH = param.L
if exists(param.C)
  set var.centerFlow = param.C
if exists(param.D)
  set var.deltaFlow = param.D
if exists(param.R)
  set var.stepFlow = param.R
if exists(param.F)
  set var.fanPct = param.F
if exists(param.P)
  set var.padSize = param.P
if exists(param.G)
  set var.gap = param.G
if exists(param.Z)
  set var.padLayers = param.Z
if exists(param.M)
  set var.margin = param.M
if exists(param.X)
  set var.offsetX = param.X
if exists(param.Y)
  set var.offsetY = param.Y

if var.layerH <= 0
  abort "L must be > 0"
if var.padSize < 12
  abort "P too small"
if var.gap < 2
  abort "G too small"
if var.padLayers < 4
  abort "Z must be >= 4"
if var.stepFlow <= 0
  abort "R must be > 0"
if var.deltaFlow < 0
  abort "D must be >= 0"
if var.fanPct < 0
  set var.fanPct = 0
if var.fanPct > 100
  set var.fanPct = 100
set var.fanS = var.fanPct / 100.0

if !exists(param.W)
  if var.nozzleDia = 0.25
    set var.lineW = 0.30
  elif var.nozzleDia = 0.4
    set var.lineW = 0.48
  elif var.nozzleDia = 0.5
    set var.lineW = 0.60
  elif var.nozzleDia = 0.6
    set var.lineW = 0.72
  elif var.nozzleDia = 0.8
    set var.lineW = 0.96
  else
    abort "N unsupported (use 0.25/0.4/0.5/0.6/0.8)"

if var.lineW <= 0
  abort "W must be > 0"

var from = var.centerFlow - var.deltaFlow
var to   = var.centerFlow + var.deltaFlow

var padCount = floor(((var.to - var.from) / var.stepFlow) + 1)
if var.padCount < 1
  abort "Bad range/step"

var cols = var.padCount
if var.cols > 5
  set var.cols = 5

var rows = floor((var.padCount - 1) / var.cols) + 1

var totalW = (var.cols * var.padSize) + ((var.cols - 1) * var.gap)
var totalH = (var.rows * var.padSize) + ((var.rows - 1) * var.gap)

var bedMinX = move.axes[0].min
var bedMaxX = move.axes[0].max
var bedMinY = move.axes[1].min
var bedMaxY = move.axes[1].max

var centerX = (var.bedMinX + var.bedMaxX) / 2
var centerY = (var.bedMinY + var.bedMaxY) / 2

var startX = var.centerX - (var.totalW / 2) + var.offsetX
var startY = var.centerY - (var.totalH / 2) + var.offsetY

var minX = var.startX - var.margin
var minY = var.startY - var.margin
var maxX = var.startX + var.totalW + var.margin
var maxY = var.startY + var.totalH + var.margin

M98 P"0:/macros/print/start.g" S{var.bedTemp} H{var.hotendTemp} X{var.minX} Y{var.minY} I{var.maxX} J{var.maxY}

M106 S0
G90
M82
G92 E0

var filDia = 1.75
var rr = var.filDia / 2
var areaFil = 3.14159265 * var.rr * var.rr

if !exists(global.ePerMM)
  global ePerMM = 0
set global.ePerMM = (var.lineW * var.layerH) / var.areaFil

if !exists(global.eTotal)
  global eTotal = 0
set global.eTotal = 0

if !exists(global.digitW)
  global digitW = 5.5
set global.digitW = 5.5

if !exists(global.digitH)
  global digitH = 9.0
set global.digitH = 9.0

var digitGap = 1.6
var labelMargin = 1.2

var spacing = var.lineW
if var.spacing <= 0
  abort "Spacing invalid"

var layer = 0
while var.layer < var.padLayers

  if var.layer = 2
    M106 S{var.fanS}

  var zNow = var.layerH * (var.layer + 1)
  G1 Z{var.zNow} F{var.fZ}

  var padIndex = 0
  var factor = var.from

  while var.padIndex < var.padCount

    M221 S{var.factor}

    var col = mod(var.padIndex, var.cols)
    var row = floor(var.padIndex / var.cols)

    var px = var.startX + (var.col * (var.padSize + var.gap))
    var py = var.startY + (var.row * (var.padSize + var.gap))

    var yLine = var.py
    var dir = mod(var.layer + var.padIndex, 2)

    while var.yLine <= (var.py + var.padSize + 0.0001)

      if var.dir = 0
        if global.eTotal >= var.travelRetract
          set global.eTotal = global.eTotal - var.travelRetract
        else
          set global.eTotal = 0
        G1 E{global.eTotal} F{var.fRetract}

        if move.axes[2].homed
          G1 Z{var.zNow + var.travelZhop} F{var.fZ}
        G1 X{var.px} Y{var.yLine} F{var.fMove}
        if move.axes[2].homed
          G1 Z{var.zNow} F{var.fZ}

        set global.eTotal = global.eTotal + var.travelRetract
        G1 E{global.eTotal} F{var.fRetract}

        set global.eTotal = global.eTotal + (global.ePerMM * var.padSize)
        G1 X{var.px + var.padSize} Y{var.yLine} F{var.fDraw} E{global.eTotal}
        set var.dir = 1
      else
        if global.eTotal >= var.travelRetract
          set global.eTotal = global.eTotal - var.travelRetract
        else
          set global.eTotal = 0
        G1 E{global.eTotal} F{var.fRetract}

        if move.axes[2].homed
          G1 Z{var.zNow + var.travelZhop} F{var.fZ}
        G1 X{var.px + var.padSize} Y{var.yLine} F{var.fMove}
        if move.axes[2].homed
          G1 Z{var.zNow} F{var.fZ}

        set global.eTotal = global.eTotal + var.travelRetract
        G1 E{global.eTotal} F{var.fRetract}

        set global.eTotal = global.eTotal + (global.ePerMM * var.padSize)
        G1 X{var.px} Y{var.yLine} F{var.fDraw} E{global.eTotal}
        set var.dir = 0

      set var.yLine = var.yLine + var.spacing

    set var.padIndex = var.padIndex + 1
    set var.factor = var.factor + var.stepFlow

  set var.layer = var.layer + 1

var labelZ = var.layerH * var.padLayers

var idx = 0
var factor = var.from

while var.idx < var.padCount

  var col = mod(var.idx, var.cols)
  var row = floor(var.idx / var.cols)

  var px = var.startX + (var.col * (var.padSize + var.gap))
  var py = var.startY + (var.row * (var.padSize + var.gap))

  var labelValue = round(var.factor)
  var absLabel = abs(var.labelValue)
  var charCount = 1

  if var.absLabel >= 10
    var divChars = 10
    while var.absLabel >= var.divChars
      set var.charCount = var.charCount + 1
      set var.divChars = var.divChars * 10

  if var.labelValue < 0
    set var.charCount = var.charCount + 1

  var digitWLocal = global.digitW
  var digitHLocal = global.digitH
  var availW = var.padSize - (2 * var.labelMargin)
  var availH = var.padSize - (2 * var.labelMargin)

  if var.availW < 6
    set var.availW = 6
  if var.availH < 6
    set var.availH = 6

  var minWidthForDigits = var.availW - ((var.charCount - 1) * var.digitGap)
  if var.minWidthForDigits < (var.charCount * 2.2)
    set var.minWidthForDigits = var.charCount * 2.2

  var maxDigitW = var.minWidthForDigits / var.charCount
  if var.maxDigitW < var.digitWLocal
    set var.digitWLocal = var.maxDigitW

  if var.digitWLocal < 2.2
    set var.digitWLocal = 2.2

  set var.digitHLocal = global.digitH * (var.digitWLocal / global.digitW)
  if var.digitHLocal > var.availH
    set var.digitHLocal = var.availH

  var labelWidth = (var.charCount * var.digitWLocal) + ((var.charCount - 1) * var.digitGap)
  var dx = var.px + ((var.padSize - var.labelWidth) / 2)
  var dy = var.py + ((var.padSize - var.digitHLocal) / 2)

  M221 S{var.factor}
  M98 P"0:/sys/flow-zahl.g" X{var.dx} Y{var.dy} V{var.labelValue} Z{var.labelZ} W{var.digitWLocal} H{var.digitHLocal} G{var.digitGap} F{var.fDraw} T{var.fMove}

  set var.idx = var.idx + 1
  set var.factor = var.factor + var.stepFlow

M221 S100
M106 S0
M98 P"0:/macros/print/End.g"

M291 P{"Flow-Plaettchen fertig: " ^ var.from ^ " bis " ^ var.to ^ " in " ^ var.stepFlow ^ "% Schritten"} R"Flow-Plaettchen" S1 T12
`;
