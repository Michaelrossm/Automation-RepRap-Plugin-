import Kalibrierungs from "../Kalibrierungs.vue";

export default [
	{
		id: "kalibrierungs-plugin",
		title: "Kalibrierung",
		icon: "mdi-hammer-wrench",
		description: "Flow-Test und Flow-Auswertung in einem Plugin.",
		component: Kalibrierungs
	}
];
