# Haftungsausschluss (Deutschland)

Dieses Plugin wird im aktuellen Zustand ("as is") bereitgestellt.
Die Nutzung erfolgt auf eigenes Risiko.

## 1. Kein Sicherheitsversprechen
Es wird keine Zusicherung gegeben, dass das Plugin fehlerfrei, unterbrechungsfrei
oder fuer jeden Drucker, jede Firmware-Konfiguration und jede Hardware geeignet ist.

## 2. Typische Risiken
Insbesondere koennen durch falsche Konfiguration, Fehlbedienung, Firmware- oder
Hardwarebesonderheiten Schaeden entstehen, z. B.:
- Fehldrucke und Materialverlust
- Ueberhitzung von Heizern oder Hotends
- Beschaedigung von Druckbett, Duese, Extruder oder Mechanik
- Produktionsausfaelle und Zeitverlust

## 3. Eigenverantwortung des Nutzers
Vor der Nutzung sind folgende Punkte verpflichtend:
- Vollstaendiges Backup von `/sys`, Makros und relevanten Konfigurationsdateien
- Testbetrieb unter Aufsicht
- Pruefung von Temperaturen, Grenzen, Sensoren und Sicherheitsfunktionen

## 4. Haftungsbeschraenkung
Soweit gesetzlich zulaessig, ist die Haftung fuer unmittelbare, mittelbare,
zufaellige oder Folgeschaeden ausgeschlossen, insbesondere fuer:
- Sach- und Geraeteschaeden
- Produktions- und Nutzungsausfall
- Datenverlust
- entgangenen Gewinn

## 5. Zwingende gesetzliche Haftung
Unberuehrt bleiben Ansprueche aus Vorsatz, grober Fahrlaessigkeit,
Verletzung von Leben, Koerper oder Gesundheit sowie zwingende
gesetzliche Ansprueche nach deutschem Recht.

## 6. Keine Rechtsberatung
Dieser Text stellt keine Rechtsberatung dar.
Bei konkreten rechtlichen Fragen ist anwaltliche Beratung erforderlich.
