<template>
	<v-container fluid>
		<v-row>
			<v-col cols="12">
				<v-card outlined>
					<v-card-title class="text-h6">Kalibrierungs Plugin</v-card-title>
					<v-card-text>
						<v-btn-toggle v-model="activeMode" mandatory class="mb-4">
							<v-btn v-if="uiTabs.flow" value="flow" depressed>
								<v-icon left>mdi-water-percent</v-icon>
								Flow Plaettchen
							</v-btn>
							<v-btn v-if="uiTabs.evaluation" value="evaluation" depressed>
								<v-icon left>mdi-calculator-variant</v-icon>
								Flow-Test + Auswertung
							</v-btn>
							<v-btn v-if="uiTabs.probe" value="probe" depressed>
								<v-icon left>mdi-crosshairs-gps</v-icon>
								Probe Tests
							</v-btn>
							<v-btn v-if="uiTabs.pid" value="pid" depressed>
								<v-icon left>mdi-thermometer-lines</v-icon>
								PID Tuning
							</v-btn>
							<v-btn v-if="uiTabs.pa" value="pa" depressed>
								<v-icon left>mdi-chart-line</v-icon>
								PA Tuning
							</v-btn>
							<v-btn v-if="uiTabs.flowtest" value="flowtest" depressed>
								<v-icon left>mdi-printer-3d-nozzle</v-icon>
								Level Test
							</v-btn>
							<v-btn v-if="uiTabs.led" value="led" depressed>
								<v-icon left>mdi-led-strip-variant</v-icon>
								LED Steuerung
							</v-btn>
							<v-btn v-if="uiTabs.daemon" value="daemon" depressed>
								<v-icon left>mdi-script-text-outline</v-icon>
								Daemon.g
							</v-btn>
							<v-btn value="settings" depressed>
								<v-icon left>mdi-cog</v-icon>
								Einstellungen
							</v-btn>
						</v-btn-toggle>

						<div v-if="activeMode === 'settings'">
							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">Globale Druck-Standards</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" class="text-subtitle-2 pb-0">Druckparameter</v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.nozzleDia" label="Nozzle mm" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.hotendTemp" label="Hotend C" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.bedTemp" label="Bett C" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.layerH" label="Standard Layerhoehe mm" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.lineW" label="Extrusionsbreite mm" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.flowPct" label="Flow %" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.fanPct" label="Luefter %" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.meshMargin" label="Mesh Rand mm" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.printSpeed" label="Druckgeschwindigkeit mm/s" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.firstLayerSpeed" label="First Layer Druckgeschwindigkeit mm/s" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.travelSpeed" label="Reisegeschwindigkeit mm/s" type="number" dense outlined /></v-col>

										<v-col cols="12" class="text-subtitle-2 pt-1 pb-0">Bettbereich</v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedBed.minX" label="Bett Min X" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedBed.maxX" label="Bett Max X" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedBed.minY" label="Bett Min Y" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedBed.maxY" label="Bett Max Y" type="number" dense outlined /></v-col>

										<v-col cols="12" class="text-subtitle-2 pt-1 pb-0">Level-Test (Prusa)</v-col>
										<v-col cols="12" md="3"><v-switch v-model="sharedPrint.levelGridAdvanced" inset dense label="Erweiterter Prusa Grid" /></v-col>
										<v-col v-if="sharedPrint.levelGridAdvanced" cols="12" md="3"><v-text-field v-model.number="sharedPrint.levelPadCountX" label="Pad-Anzahl X" type="number" min="2" dense outlined /></v-col>
										<v-col v-if="sharedPrint.levelGridAdvanced" cols="12" md="3"><v-text-field v-model.number="sharedPrint.levelPadCountY" label="Pad-Anzahl Y" type="number" min="2" dense outlined /></v-col>
										<v-col v-if="sharedPrint.levelGridAdvanced" cols="12" md="3"><v-text-field v-model.number="sharedPrint.levelPadW" label="Pad-Breite mm" type="number" dense outlined /></v-col>
										<v-col v-if="sharedPrint.levelGridAdvanced" cols="12" md="3"><v-text-field v-model.number="sharedPrint.levelPadH" label="Pad-Hoehe mm" type="number" dense outlined /></v-col>
										<v-col v-if="sharedPrint.levelGridAdvanced" cols="12" md="3"><v-text-field v-model.number="sharedPrint.levelPadGap" label="Pad-Abstand mm" type="number" dense outlined /></v-col>

										<v-col cols="12" class="text-subtitle-2 pt-2 pb-0">Reiter Sichtbarkeit</v-col>
										<v-col cols="12" md="3"><v-switch v-model="uiTabs.flow" inset dense label="Flow Plaettchen" /></v-col>
										<v-col cols="12" md="3"><v-switch v-model="uiTabs.evaluation" inset dense label="Flow-Test + Auswertung" /></v-col>
										<v-col cols="12" md="3"><v-switch v-model="uiTabs.probe" inset dense label="Probe Tests" /></v-col>
										<v-col cols="12" md="3"><v-switch v-model="uiTabs.pid" inset dense label="PID Tuning" /></v-col>
										<v-col cols="12" md="3"><v-switch v-model="uiTabs.pa" inset dense label="PA Tuning" /></v-col>
										<v-col cols="12" md="3"><v-switch v-model="uiTabs.flowtest" inset dense label="Level Test" /></v-col>
										<v-col cols="12" md="3"><v-switch v-model="uiTabs.led" inset dense label="LED Steuerung" /></v-col>
										<v-col cols="12" md="3"><v-switch v-model="uiTabs.daemon" inset dense label="Daemon.g Reiter" /></v-col>

										<v-col cols="12" class="text-subtitle-2 pt-2 pb-0">Daemon-Modul (/sys/daemon.g)</v-col>
										<v-col cols="12" md="8" class="pt-0">
											<div class="text-caption">
												Schreibt <code>/sys/daemon.g</code> und <code>/sys/Daemon/*</code>. Die Laufzeitlogik liest nur und aktualisiert globale Variablen.
											</div>
										</v-col>
										<v-col cols="12" md="4" class="pt-0">
											<v-btn color="primary" @click="saveDaemonModule">Daemon Modul speichern/aktualisieren</v-btn>
										</v-col>
										<v-col cols="12" class="pt-0">
											<v-alert v-if="daemonMessage" dense outlined :type="daemonMessageType === 'error' ? 'error' : (daemonMessageType === 'success' ? 'success' : 'info')">
												{{ daemonMessage }}
											</v-alert>
										</v-col>

										<v-col cols="12" class="text-subtitle-2 pt-2 pb-0">Daemon-Module aktivieren</v-col>
										<v-col cols="12" md="6"><v-switch v-model="daemonCfg.moduleLedEnabled" inset dense label="LED Daemon aktiv" /></v-col>
										<v-col cols="12" md="6"><v-switch v-model="daemonCfg.moduleHeaterModelEnabled" inset dense label="PID/Model-Auswahl Daemon aktiv" /></v-col>
										<v-col cols="12" class="text-subtitle-2 pt-2 pb-0">Idle Shutdown</v-col>
										<v-col cols="12" md="4"><v-switch v-model="daemonCfg.idleShutdownEnabled" inset dense label="Idle Shutdown aktiv" /></v-col>
										<v-col cols="12" md="4"><v-text-field v-model.number="daemonCfg.idleShutdownSeconds" :disabled="!daemonCfg.idleShutdownEnabled" label="Idle Zeit (Sekunden)" type="number" min="10" dense outlined /></v-col>
										<v-col cols="12" md="4"><v-switch v-model="daemonCfg.idleShutdownFanEnabled" :disabled="!daemonCfg.idleShutdownEnabled" inset dense label="Part-Fan mit ausschalten" /></v-col>
										<v-col cols="12" class="text-caption pt-0">
											Wenn Module deaktiviert sind, bleibt <code>/sys/daemon.g</code> erhalten und laeuft ohne Aktionen weiter.
										</v-col>
									</v-row>
									<div class="d-flex flex-wrap mt-2" style="gap:12px">
										<v-btn color="primary" @click="saveSharedSettings">Als Standard speichern</v-btn>
										<v-btn outlined @click="runMacroSelfCheck">Makro-Selbsttest</v-btn>
									</div>
									<v-divider class="my-4"></v-divider>
									<v-textarea
										v-model="startCode"
										rows="4"
										outlined
										label="Startcode (global)"
										hint="Platzhalter: {hotendTemp} {bedTemp} {minX} {minY} {maxX} {maxY} oder [extruder0_temperature] [bed0_temperature] [build_min_x] [build_min_y] [build_max_x] [build_max_y]"
										persistent-hint
									/>
									<v-textarea
										v-model="endCode"
										rows="3"
										outlined
										class="mt-3"
										label="Endcode (global)"
									/>
								</v-card-text>
							</v-card>
							<v-alert v-if="settingsMessage" dense outlined class="mt-3" :type="settingsMessageType === 'error' ? 'error' : 'info'">
								{{ settingsMessage }}
							</v-alert>
						</div>

						<div v-else-if="(activeMode === 'flow') && uiTabs.flow">
							<v-row dense>
								<v-col cols="12" md="3"><v-text-field v-model.number="form.H" label="Hotend C (Test)" type="number" dense outlined /></v-col>
								<v-col cols="12" md="3"><v-text-field v-model.number="form.B" label="Bett C (Test)" type="number" dense outlined /></v-col>
								<v-col cols="12" md="3"><v-text-field v-model.number="form.C" label="Center Flow %" type="number" dense outlined /></v-col>
								<v-col cols="12" md="3"><v-text-field v-model.number="form.D" label="Delta %" type="number" dense outlined /></v-col>
								<v-col cols="12" md="3"><v-text-field v-model.number="form.R" label="Schritt %" type="number" dense outlined /></v-col>
								<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.fanPct" label="Luefter %" type="number" dense outlined /></v-col>

								<v-col cols="12" md="3"><v-text-field v-model.number="form.P" label="Padgroesse mm" type="number" dense outlined /></v-col>
								<v-col cols="12" md="3"><v-text-field v-model.number="form.G" label="Abstand mm" type="number" dense outlined /></v-col>
								<v-col cols="12" md="3"><v-text-field v-model.number="form.Z" label="Layer je Pad" type="number" dense outlined /></v-col>

								<v-col cols="12" md="3"><v-text-field v-model.number="form.X" label="Offset X" type="number" dense outlined /></v-col>
								<v-col cols="12" md="3"><v-text-field v-model.number="form.Y" label="Offset Y" type="number" dense outlined /></v-col>
								<v-col cols="12" md="6"><v-text-field v-model="sharedPrint.materialName" label="Materialname" dense outlined /></v-col>
							</v-row>

							<v-alert dense outlined type="info" class="mt-3">
								Der beste Wert wird nicht in der Firmware gespeichert.
								Trage ihn im Slicer als Flow / Extrusion Multiplier ein.
							</v-alert>

							<div class="d-flex flex-wrap mt-4" style="gap:12px">
								<v-btn color="primary" @click="startPrint">Flow-Test starten</v-btn>
								<v-btn @click="togglePause" :disabled="!isPrinting">{{ isPaused ? "Fortsetzen" : "Pause" }}</v-btn>
								<v-btn color="error" @click="cancelPrint" :disabled="!isPrinting">Abbrechen</v-btn>
								<v-btn @click="resetDefaults">Reset Standard</v-btn>
							</div>

							<v-divider class="my-4"></v-divider>

							<div class="text-subtitle-1 mb-2">Druckstatus</div>
							<v-progress-linear :value="progressPercent" height="18" rounded>
								<template #default>{{ progressPercent.toFixed(1) }} %</template>
							</v-progress-linear>

							<v-row dense class="mt-3">
								<v-col cols="12" md="4">
									<v-text-field :value="statusText" label="Status" dense outlined readonly />
								</v-col>
								<v-col cols="12" md="4">
									<v-text-field :value="currentFile" label="Datei" dense outlined readonly />
								</v-col>
								<v-col cols="12" md="4">
									<v-text-field :value="bestResultText" label="Ergebnis fuer Slicer" dense outlined readonly />
								</v-col>
							</v-row>

							<v-alert v-if="errorText" dense type="error" outlined class="mt-3">
								{{ errorText }}
							</v-alert>
							<v-alert v-if="infoText" dense type="success" outlined class="mt-3">
								{{ infoText }}
							</v-alert>
						</div>

						<div v-else-if="(activeMode === 'evaluation') && uiTabs.evaluation">
							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">Flow-Test drucken (Einzelwand-Box)</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" md="3"><v-text-field v-model.number="boxTest.H" label="Hotend C (Test)" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="boxTest.B" label="Bett C (Test)" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="boxTest.W" label="Linienbreite W mm (optional)" type="number" dense outlined clearable /></v-col>

										<v-col cols="12" md="3"><v-text-field v-model.number="boxTest.S" label="Boxgroesse S mm" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="boxTest.Z" label="Layer Z" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.fanPct" label="Luefter F %" type="number" dense outlined /></v-col>

										<v-col cols="12" md="4"><v-text-field v-model.number="boxTest.X" label="Start X" type="number" dense outlined /></v-col>
										<v-col cols="12" md="4"><v-text-field v-model.number="boxTest.Y" label="Start Y" type="number" dense outlined /></v-col>
									</v-row>

									<div class="d-flex flex-wrap mt-3" style="gap:12px">
										<v-btn color="primary" @click="startBoxFlowTest">Flow-Test drucken</v-btn>
										<v-btn @click="togglePause" :disabled="!isPrinting">{{ isPaused ? "Fortsetzen" : "Pause" }}</v-btn>
										<v-btn color="error" @click="cancelPrint" :disabled="!isPrinting">Abbrechen</v-btn>
									</div>

									<v-row dense class="mt-3">
										<v-col cols="12" md="6">
											<v-text-field :value="statusText" label="Status" dense outlined readonly />
										</v-col>
										<v-col cols="12" md="6">
											<v-text-field :value="currentFile" label="Datei" dense outlined readonly />
										</v-col>
									</v-row>

									<v-alert v-if="boxTestMessage" dense outlined class="mt-3" :type="boxTestMessageType === 'error' ? 'error' : 'info'">
										{{ boxTestMessage }}
									</v-alert>
								</v-card-text>
							</v-card>

							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">Flow-Auswertung</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" md="4">
											<v-text-field v-model.number="evaluation.measured" label="Gemessene Wandstaerke mm" type="number" dense outlined />
										</v-col>
										<v-col cols="12" md="4">
											<v-text-field v-model.number="evaluation.target" label="Zielwandstaerke mm" type="number" dense outlined />
										</v-col>
										<v-col cols="12" md="4">
											<v-text-field v-model.number="evaluation.currentFlow" label="Aktueller Flow %" type="number" dense outlined />
										</v-col>
									</v-row>
									<v-row dense class="mt-3">
										<v-col cols="12" md="4">
											<v-text-field :value="evaluationFlowText" label="Berechneter Flow %" dense outlined readonly />
										</v-col>
										<v-col cols="12" md="8" class="d-flex flex-wrap align-end" style="gap:12px">
											<v-btn color="primary" @click="runFlowEvaluation">Flow berechnen & setzen</v-btn>
											<v-btn outlined @click="calculateFlowOnly">Nur berechnen</v-btn>
										</v-col>
									</v-row>
									<v-alert v-if="evaluationMessage" dense outlined class="mt-3" :type="evaluationMessageType === 'error' ? 'error' : 'info'">
										{{ evaluationMessage }}
									</v-alert>
								</v-card-text>
							</v-card>
						</div>

						<div v-else-if="(activeMode === 'probe') && uiTabs.probe">
							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">IR Mini Z Calibration</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" md="4"><v-text-field v-model.number="probeZCal.safeLift" label="Anheben nach Null (mm)" type="number" dense outlined /></v-col>
									</v-row>
									<div class="d-flex flex-wrap mt-2" style="gap:12px">
										<v-btn color="primary" @click="runZCalibrationMacro">Test starten</v-btn>
									</div>
								</v-card-text>
							</v-card>

							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">SZP Repeatability Test</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" md="3"><v-text-field v-model.number="szpTest.X" label="Probe X" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="szpTest.Y" label="Probe Y" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="szpTest.N" label="Messungen N" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="szpTest.Z" label="Safe Z" type="number" dense outlined /></v-col>
									</v-row>
									<div class="d-flex flex-wrap mt-2" style="gap:12px">
										<v-btn color="primary" @click="runSzpRepeatabilityMacro">Test starten</v-btn>
									</div>
								</v-card-text>
							</v-card>

							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">IR Probe Repeatability Test</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" md="3"><v-text-field v-model.number="irRepeatTest.X" label="Probe X" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="irRepeatTest.Y" label="Probe Y" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="irRepeatTest.N" label="Messungen N" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="irRepeatTest.Zsafe" label="Safe Z" type="number" dense outlined /></v-col>
									</v-row>
									<div class="d-flex flex-wrap mt-2" style="gap:12px">
										<v-btn color="primary" @click="runIrRepeatabilityMacro">Test starten</v-btn>
									</div>
								</v-card-text>
							</v-card>

							<v-alert v-if="probeMessage" dense outlined class="mt-3" :type="probeMessageType === 'error' ? 'error' : 'info'">
								{{ probeMessage }}
							</v-alert>
						</div>

						<div v-else-if="(activeMode === 'pid') && uiTabs.pid">
							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">PID Serie (Model-Dateien je Temperatur)</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" md="3">
											<v-select
												v-model.number="pidSeries.H"
												:items="heaterSelectItems"
												label="Heater H"
												dense
												outlined
											/>
										</v-col>
										<v-col cols="12" md="3">
											<v-select
												v-model="pidSeries.fans"
												:items="fanSelectItems"
												label="Luefter P (optional)"
												multiple
												chips
												small-chips
												dense
												outlined
											/>
										</v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="pidSeries.fanPct" label="Luefter %" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="pidSeries.A" label="Start A" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="pidSeries.E" label="Ende E" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="pidSeries.I" label="Schritt I" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="pidSeries.C" label="Cooldown C" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3">
											<v-select
												v-model="pidHeaterKindOverrideSelected"
												:items="pidHeaterKindOverrideItems"
												label="Heater-Typ Override"
												dense
												outlined
											/>
										</v-col>
										<v-col cols="12" md="3"><v-text-field :value="pidDetectedKindText" label="Auto erkannt" dense outlined readonly /></v-col>
										<v-col cols="12" md="6"><v-text-field :value="pidTargetInfoText" label="Zielordner (auto/override)" dense outlined readonly /></v-col>
										<v-col cols="12" md="6"><v-switch v-model="pidSeries.useCsv" inset dense label="CSV-Speicherung aktivieren" /></v-col>
										<v-col v-if="pidSeries.useCsv" cols="12" md="6"><v-text-field v-model="pidSeries.F" label="CSV Pfad F" dense outlined /></v-col>
									</v-row>
									<v-alert dense outlined type="info" class="mt-2">
										{{ pidSeries.useCsv ? "CSV aktiv: es wird in die CSV-Datei geschrieben." : "CSV aus: pro Temperatur wird eine Model-Datei mit M307 im Typ-Ordner gespeichert." }}
									</v-alert>
									<v-alert dense outlined type="info" class="mt-2">
										Daemon: LED-Logik und Heater-Model-Auswahl werden ueber <b>/sys/daemon.g</b> + <b>/sys/Daemon/*</b> gesteuert.
										Installation/Aktualisierung im Reiter <b>Einstellungen</b>.
									</v-alert>
									<div class="d-flex flex-wrap mt-2" style="gap:12px">
										<v-btn color="primary" @click="runPidSeriesMacro">PID Serie starten</v-btn>
									</div>
								</v-card-text>
							</v-card>
							<v-alert v-if="pidMessage" dense outlined class="mt-3" :type="pidMessageType === 'error' ? 'error' : 'info'">
								{{ pidMessage }}
							</v-alert>
						</div>

						<div v-else-if="(activeMode === 'led') && uiTabs.led">
							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">LED Steuerung (RRF M150)</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" md="3">
											<v-select
												v-model.number="ledControl.strip"
												:items="ledStripItems"
												label="LED Strip E"
												dense
												outlined
											/>
										</v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="ledControl.count" label="LED Anzahl S" type="number" min="1" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field :value="ledPreviewCommand" label="Vorschau G-Code" dense outlined readonly /></v-col>
										<v-col cols="12" md="3"><v-slider v-model="ledControl.brightness" label="Helligkeit P" min="0" max="255" step="1" dense hide-details="auto" /></v-col>

										<v-col cols="12" md="5">
											<v-color-picker
												v-model="ledControl.color"
												mode="hexa"
												hide-inputs
												dot-size="18"
												swatches-max-height="140"
												@input="onLedColorChanged"
											/>
										</v-col>
										<v-col cols="12" md="7">
											<v-row dense>
												<v-col cols="12" md="3"><v-text-field v-model.number="ledControl.r" label="R" type="number" min="0" max="255" dense outlined @change="syncLedHexFromRgb" /></v-col>
												<v-col cols="12" md="3"><v-text-field v-model.number="ledControl.g" label="U (Green)" type="number" min="0" max="255" dense outlined @change="syncLedHexFromRgb" /></v-col>
												<v-col cols="12" md="3"><v-text-field v-model.number="ledControl.b" label="B" type="number" min="0" max="255" dense outlined @change="syncLedHexFromRgb" /></v-col>
												<v-col cols="12" md="3"><v-text-field v-model.number="ledControl.w" label="W (optional)" type="number" min="0" max="255" dense outlined /></v-col>
											</v-row>
											<div class="d-flex flex-wrap mt-2" style="gap:8px">
												<v-btn small color="primary" @click="applyLedColor">Anwenden</v-btn>
												<v-btn small @click="setLedPreset('warm')">Warmweiss</v-btn>
												<v-btn small @click="setLedPreset('white')">Neutralweiss</v-btn>
												<v-btn small @click="setLedPreset('red')">Rot</v-btn>
												<v-btn small @click="setLedPreset('green')">Gruen</v-btn>
												<v-btn small @click="setLedPreset('blue')">Blau</v-btn>
												<v-btn small color="error" @click="turnOffLeds">Aus</v-btn>
											</div>
										</v-col>
									</v-row>
								</v-card-text>
							</v-card>
							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">LED Daemon-Logik (Aktionen)</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" class="text-caption">
											Farbe und Blinken pro Aktion einstellen. Beispiel: Filament-Fehler blinkt.
										</v-col>
										<v-col cols="12" v-for="item in daemonLedActionItems" :key="item.id">
											<v-row dense class="align-center">
												<v-col cols="12" md="3">
													<v-text-field :value="item.label" label="Aktion" dense outlined readonly />
												</v-col>
												<v-col cols="12" md="2">
													<div class="d-flex align-center" style="height:40px;">
														<input type="color" :value="getDaemonColorHex(item.colorKey)" @input="onDaemonActionColorInput(item.colorKey, $event.target.value)" style="width:100%; height:34px; border:0; background:transparent;" />
													</div>
												</v-col>
												<v-col cols="12" md="3">
													<v-text-field :value="getDaemonColorHex(item.colorKey)" label="Hex Farbe" dense outlined @change="onDaemonActionColorInput(item.colorKey, $event)" />
												</v-col>
												<v-col cols="12" md="2">
													<v-switch :input-value="getDaemonBlink(item.blinkKey)" inset dense label="Blinken" @change="setDaemonBlink(item.blinkKey, $event)" />
												</v-col>
												<v-col cols="12" md="2">
													<v-btn small outlined @click="copyLiveColorToAction(item.colorKey)">Live Farbe uebernehmen</v-btn>
												</v-col>
											</v-row>
										</v-col>
										<v-col cols="12" class="d-flex flex-wrap" style="gap:8px;">
											<v-btn color="primary" @click="saveDaemonModule('led')">LED-Logik speichern (Daemon)</v-btn>
										</v-col>
									</v-row>
								</v-card-text>
							</v-card>
							<v-alert v-if="ledMessage" dense outlined class="mt-3" :type="ledMessageType === 'error' ? 'error' : 'info'">
								{{ ledMessage }}
							</v-alert>
						</div>

						<div v-else-if="(activeMode === 'flowtest') && uiTabs.flowtest">
							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">Level Test (First Layer, druckbar)</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" md="4">
											<v-select
												v-model="flowTest.testMode"
												:items="[{ text: 'Prusa Test', value: 'prusa' }, { text: 'Vollflaeche (4-Eck)', value: 'full' }]"
												label="Testmodus"
												dense
												outlined
											/>
										</v-col>
										<v-col cols="12" md="8" class="d-flex align-center">
											<span class="grey--text text--lighten-1">
												Prusa: 3x3 Grid standard (optional erweiterbar in Einstellungen), Vollflaeche: ein grosses Testrechteck.
											</span>
										</v-col>

										<v-col cols="12" md="3"><v-text-field :value="sharedPrint.meshMargin" label="Sicherheitsrand (aus Einstellungen)" dense outlined readonly /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model="sharedPrint.materialName" label="Materialname" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="flowTest.hotendTemp" label="Hotend C (Test)" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="flowTest.bedTemp" label="Bett C (Test)" type="number" dense outlined /></v-col>

										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.lineW" label="Extrusionsbreite mm" type="number" dense outlined /></v-col>
										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.fanPct" label="Luefter %" type="number" dense outlined /></v-col>

										<v-col cols="12" md="3"><v-text-field v-model.number="sharedPrint.flowPct" label="Flow %" type="number" dense outlined /></v-col>

										<v-col cols="12" class="d-flex align-center" style="gap:12px">
											<span class="grey--text text--lighten-1">
												Extrusionsbreite auto: {{ flowTestLineWManual ? "manuell fixiert" : "aktiv (Duese x 1.2)" }}
											</span>
											<v-btn x-small outlined @click="enableAutoLineWidth">Auto wieder aktivieren</v-btn>
										</v-col>
									</v-row>

									<div class="d-flex flex-wrap mt-2" style="gap:12px">
										<v-btn color="primary" @click="startFlowTest">Level Test starten</v-btn>
										<v-btn @click="togglePause" :disabled="!isPrinting">{{ isPaused ? "Fortsetzen" : "Pause" }}</v-btn>
										<v-btn color="error" @click="cancelPrint" :disabled="!isPrinting">Abbrechen</v-btn>
									</div>

									<v-divider class="my-4"></v-divider>

									<div class="text-subtitle-2 mb-2">Live Z-Offset / Microstepping</div>
									<v-row dense>
										<v-col cols="12" md="4">
											<v-select
												v-model.number="flowTestSelectedProbe"
												:items="probeSelectItems"
												label="Probe (K)"
												dense
												outlined
											/>
										</v-col>
										<v-col cols="12" md="4">
											<v-text-field :value="currentProbeZOffsetText" label="Aktueller Probe Z-Offset" dense outlined readonly />
										</v-col>
										<v-col cols="12" md="8" class="d-flex flex-wrap align-center" style="gap:8px">
											<v-btn small outlined @click="adjustProbeZOffset(-0.05)">-0.05</v-btn>
											<v-btn small outlined @click="adjustProbeZOffset(-0.02)">-0.02</v-btn>
											<v-btn small outlined @click="adjustProbeZOffset(-0.01)">-0.01</v-btn>
											<v-btn small outlined @click="adjustProbeZOffset(0.01)">+0.01</v-btn>
											<v-btn small outlined @click="adjustProbeZOffset(0.02)">+0.02</v-btn>
											<v-btn small outlined @click="adjustProbeZOffset(0.05)">+0.05</v-btn>
											<v-btn small outlined @click="adoptMachineBabystepToSelectedProbe">Babystep aus DWC uebernehmen</v-btn>
											<v-btn small @click="resetProbeZOffset">Reset</v-btn>
											<v-btn small color="primary" @click="saveProbeOffsets">Offset speichern</v-btn>
										</v-col>
									</v-row>
								</v-card-text>
							</v-card>
							<v-alert v-if="flowTestMessage" dense outlined class="mt-3" :type="flowTestMessageType === 'error' ? 'error' : 'info'">
								{{ flowTestMessage }}
							</v-alert>
						</div>

						<div v-else-if="(activeMode === 'daemon') && uiTabs.daemon">
							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">Daemon.g Custom Befehle</v-card-title>
								<v-card-text>
									<v-textarea
										v-model="daemonCustomCommands"
										rows="10"
										outlined
										label="Eigene Daemon.g Befehle"
										hint="Diese Befehle werden in daemon.g beibehalten, auch wenn LED/PID-Module deaktiviert sind."
										persistent-hint
									/>
									<div class="d-flex flex-wrap mt-2" style="gap:12px">
										<v-btn color="primary" @click="saveDaemonModule">Daemon Modul speichern/aktualisieren</v-btn>
									</div>
								</v-card-text>
							</v-card>
							<v-alert v-if="daemonMessage" dense outlined class="mt-3" :type="daemonMessageType === 'error' ? 'error' : 'info'">
								{{ daemonMessage }}
							</v-alert>
						</div>

						<div v-else-if="(activeMode === 'pa') && uiTabs.pa">
							<v-card outlined dense class="mb-4">
								<v-card-title class="text-subtitle-1">PA Tuning (zentriert, skalierbar)</v-card-title>
								<v-card-text>
									<v-row dense>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.hotendTemp" label="Hotend C (Test)" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.bedTemp" label="Bett C (Test)" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.flowFactor" label="Flow Faktor" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.startPA" label="PA Start" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.endPA" label="PA Ende" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.stepPA" label="PA Schritt" type="number" dense outlined /></v-col>

										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.zFirst" label="Druckhoehe Z" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.lineW" label="Line W" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.accel" label="Accel" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.paDrive" label="M572 Drive D" type="number" dense outlined /></v-col>

										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.scale" label="Skalierung" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.offsetX" label="Offset X" type="number" dense outlined /></v-col>
										<v-col cols="12" md="2"><v-text-field v-model.number="paTuning.offsetY" label="Offset Y" type="number" dense outlined /></v-col>

										<v-col cols="12" md="2"><v-switch v-model="paTuning.doFrame" inset label="Rahmen" dense /></v-col>
									</v-row>
									<div class="d-flex flex-wrap mt-2" style="gap:12px">
										<v-btn color="primary" @click="startPaTuning">PA Test starten</v-btn>
										<v-btn @click="togglePause" :disabled="!isPrinting">{{ isPaused ? "Fortsetzen" : "Pause" }}</v-btn>
										<v-btn color="error" @click="cancelPrint" :disabled="!isPrinting">Abbrechen</v-btn>
									</div>
								</v-card-text>
							</v-card>
							<v-alert v-if="paMessage" dense outlined class="mt-3" :type="paMessageType === 'error' ? 'error' : 'info'">
								{{ paMessage }}
							</v-alert>
						</div>

						<div v-if="showStartEndEditor">
							<v-divider class="my-4"></v-divider>
							<v-textarea
								v-model="startCode"
								rows="4"
								outlined
								label="Startcode (Flow/Level Test/PA)"
								hint="Platzhalter: {hotendTemp} {bedTemp} {minX} {minY} {maxX} {maxY}"
								persistent-hint
							/>
							<v-textarea
								v-model="endCode"
								rows="3"
								outlined
								class="mt-3"
								label="Endcode (Flow/Level Test/PA)"
							/>
						</div>
					</v-card-text>
				</v-card>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
const START_CODE_STORAGE_KEY = "kalibrierung.startCode";
const END_CODE_STORAGE_KEY = "kalibrierung.endCode";
const SHARED_PRINT_STORAGE_KEY = "kalibrierung.sharedPrint";
const SHARED_BED_STORAGE_KEY = "kalibrierung.sharedBed";
const UI_TABS_STORAGE_KEY = "kalibrierung.uiTabs";
const DAEMON_CFG_STORAGE_KEY = "kalibrierung.daemonCfg";
const PID_SERIES_STORAGE_KEY = "kalibrierung.pidSeries";
const DAEMON_CUSTOM_STORAGE_KEY = "kalibrierung.daemonCustomCommands";
const STORAGE_SCHEMA_VERSION = 2;

const DEFAULT_START_CODE = [
	"M98 P\"0:/sys/print/start.g\" S[bed0_temperature] H[extruder0_temperature] X[build_min_x] Y[build_min_y] I[build_max_x] J[build_max_y]"
].join("\n");

const LEGACY_END_CODE_WITH_SYS_END = [
	"M221 S100",
	"M106 S0",
	"M98 P\"0:/sys/print/end.g\""
].join("\n");

const DEFAULT_END_CODE = [
	"M221 S100",
	"M106 S0",
	"M98 P\"0:/sys/print/end.g\""
].join("\n");

const DEFAULT_UI_TABS = {
	flow: true,
	evaluation: true,
	probe: true,
	pid: true,
	pa: true,
	flowtest: true,
	led: true,
	daemon: false
};

const DEFAULT_DAEMON_CFG = {
	// Modul-Schalter (nur in Einstellungen)
	moduleLedEnabled: true,
	moduleHeaterModelEnabled: true,
	idleShutdownEnabled: false,
	idleShutdownSeconds: 1800,
	idleShutdownFanEnabled: true,
	ledEnabled: true,
	ledStrip: 0,
	ledCount: 12,
	ledBrightness: 255,
	ledUseFilamentState: true,
	ledUseFanState: true,
	ledUseDoneState: true,
	ledHotendHotTemp: 200,
	ledBedHotTemp: 50,
	ledHotendHeatDelta: 5,
	ledBedHeatDelta: 3,
	bed1Heater: 0,
	bed2Heater: -1,
	bed3Heater: -1,
	bed4Heater: -1,
	hotend1Heater: 1,
	hotend2Heater: -1,
	hotend3Heater: -1,
	hotend4Heater: -1,
	colorError: { r: 255, g: 0, b: 0 },
	blinkError: true,
	colorPaused: { r: 255, g: 180, b: 0 },
	blinkPaused: false,
	colorPrinting: { r: 0, g: 0, b: 255 },
	blinkPrinting: false,
	colorHeating: { r: 255, g: 40, b: 0 },
	blinkHeating: false,
	colorDone: { r: 0, g: 255, b: 0 },
	blinkDone: false,
	colorFan: { r: 0, g: 255, b: 255 },
	blinkFan: false,
	colorHotendHot: { r: 120, g: 0, b: 0 },
	blinkHotendHot: false,
	colorBedHot: { r: 255, g: 40, b: 20 },
	blinkBedHot: false,
	colorFilament: { r: 255, g: 0, b: 255 },
	blinkFilament: true,
	colorIdle: { r: 80, g: 60, b: 30 },
	blinkIdle: false
};

const DAEMON_01_SHARED_STATE_G = [
	"; Shared Runtime State",
	"; Liest alle benoetigten Zustaende genau einmal pro Zyklus",
	"",
	"; Alle verwendeten Globals einmalig deklarieren (RRF: global <name> = ... vor set global.<name>)",
	"",
	"if !exists(global.sharedLastStatus)",
	"  global sharedLastStatus = \"unknown\"",
	"",
	"if !exists(global.sharedDoneTimer)",
	"  global sharedDoneTimer = 0",
	"",
	"if !exists(global.sharedLastLedState)",
	"  global sharedLastLedState = \"unknown\"",
	"",
	"if !exists(global.sharedLastLedBlinkPhase)",
	"  global sharedLastLedBlinkPhase = 0",
	"",
	"if !exists(global.sharedBlinkPhase)",
	"  global sharedBlinkPhase = 0",
	"",
	"if !exists(global.sharedStatus)",
	"  global sharedStatus = \"unknown\"",
	"",
	"if !exists(global.sharedIdleSeconds)",
	"  global sharedIdleSeconds = 0",
	"",
	"if !exists(global.sharedBed1Target)",
	"  global sharedBed1Target = 0",
	"if !exists(global.sharedBed1Temp)",
	"  global sharedBed1Temp = 0",
	"if !exists(global.sharedBed2Target)",
	"  global sharedBed2Target = 0",
	"if !exists(global.sharedBed2Temp)",
	"  global sharedBed2Temp = 0",
	"if !exists(global.sharedBed3Target)",
	"  global sharedBed3Target = 0",
	"if !exists(global.sharedBed3Temp)",
	"  global sharedBed3Temp = 0",
	"if !exists(global.sharedBed4Target)",
	"  global sharedBed4Target = 0",
	"if !exists(global.sharedBed4Temp)",
	"  global sharedBed4Temp = 0",
	"",
	"if !exists(global.sharedHotend1Target)",
	"  global sharedHotend1Target = 0",
	"if !exists(global.sharedHotend1Temp)",
	"  global sharedHotend1Temp = 0",
	"if !exists(global.sharedHotend2Target)",
	"  global sharedHotend2Target = 0",
	"if !exists(global.sharedHotend2Temp)",
	"  global sharedHotend2Temp = 0",
	"if !exists(global.sharedHotend3Target)",
	"  global sharedHotend3Target = 0",
	"if !exists(global.sharedHotend3Temp)",
	"  global sharedHotend3Temp = 0",
	"if !exists(global.sharedHotend4Target)",
	"  global sharedHotend4Target = 0",
	"if !exists(global.sharedHotend4Temp)",
	"  global sharedHotend4Temp = 0",
	"",
	"if !exists(global.sharedAnyHotendHeating)",
	"  global sharedAnyHotendHeating = 0",
	"if !exists(global.sharedAnyBedHeating)",
	"  global sharedAnyBedHeating = 0",
	"if !exists(global.sharedAnyHotendVeryHot)",
	"  global sharedAnyHotendVeryHot = 0",
	"if !exists(global.sharedAnyBedVeryHot)",
	"  global sharedAnyBedVeryHot = 0",
	"if !exists(global.sharedIsHeating)",
	"  global sharedIsHeating = 0",
	"if !exists(global.sharedPartFanOn)",
	"  global sharedPartFanOn = 0",
	"if !exists(global.sharedFilamentOk)",
	"  global sharedFilamentOk = 1",
	"if !exists(global.sharedAnyHeaterTuning)",
	"  global sharedAnyHeaterTuning = 0",
	"",
	"if !exists(global.bed1ModelSel)",
	"  global bed1ModelSel = -99999",
	"if !exists(global.bed2ModelSel)",
	"  global bed2ModelSel = -99999",
	"if !exists(global.bed3ModelSel)",
	"  global bed3ModelSel = -99999",
	"if !exists(global.bed4ModelSel)",
	"  global bed4ModelSel = -99999",
	"",
	"if !exists(global.hotend1ModelSel)",
	"  global hotend1ModelSel = -99999",
	"if !exists(global.hotend2ModelSel)",
	"  global hotend2ModelSel = -99999",
	"if !exists(global.hotend3ModelSel)",
	"  global hotend3ModelSel = -99999",
	"if !exists(global.hotend4ModelSel)",
	"  global hotend4ModelSel = -99999",
	"",
	"set global.sharedStatus = state.status",
	"",
	"; Detect active PID tuning to block daemon interventions",
	"set global.sharedAnyHeaterTuning = 0",
	"var hi = 0",
	"while var.hi < #heat.heaters",
	"  if heat.heaters[var.hi].state = \"tuning\"",
	"    set global.sharedAnyHeaterTuning = 1",
	"  set var.hi = var.hi + 1",
	"",
	"; Bettzonen",
	"if global.cfgBed1Heater >= 0",
	"  if #heat.heaters > global.cfgBed1Heater",
	"  set global.sharedBed1Target = heat.heaters[global.cfgBed1Heater].active",
	"  set global.sharedBed1Temp = heat.heaters[global.cfgBed1Heater].current",
	"  else",
	"    set global.sharedBed1Target = 0",
	"    set global.sharedBed1Temp = 0",
	"else",
	"  set global.sharedBed1Target = 0",
	"  set global.sharedBed1Temp = 0",
	"",
	"if global.cfgBed2Heater >= 0",
	"  if #heat.heaters > global.cfgBed2Heater",
	"  set global.sharedBed2Target = heat.heaters[global.cfgBed2Heater].active",
	"  set global.sharedBed2Temp = heat.heaters[global.cfgBed2Heater].current",
	"  else",
	"    set global.sharedBed2Target = 0",
	"    set global.sharedBed2Temp = 0",
	"else",
	"  set global.sharedBed2Target = 0",
	"  set global.sharedBed2Temp = 0",
	"",
	"if global.cfgBed3Heater >= 0",
	"  if #heat.heaters > global.cfgBed3Heater",
	"  set global.sharedBed3Target = heat.heaters[global.cfgBed3Heater].active",
	"  set global.sharedBed3Temp = heat.heaters[global.cfgBed3Heater].current",
	"  else",
	"    set global.sharedBed3Target = 0",
	"    set global.sharedBed3Temp = 0",
	"else",
	"  set global.sharedBed3Target = 0",
	"  set global.sharedBed3Temp = 0",
	"",
	"if global.cfgBed4Heater >= 0",
	"  if #heat.heaters > global.cfgBed4Heater",
	"  set global.sharedBed4Target = heat.heaters[global.cfgBed4Heater].active",
	"  set global.sharedBed4Temp = heat.heaters[global.cfgBed4Heater].current",
	"  else",
	"    set global.sharedBed4Target = 0",
	"    set global.sharedBed4Temp = 0",
	"else",
	"  set global.sharedBed4Target = 0",
	"  set global.sharedBed4Temp = 0",
	"",
	"; Hotends",
	"if global.cfgHotend1Heater >= 0",
	"  if #heat.heaters > global.cfgHotend1Heater",
	"  set global.sharedHotend1Target = heat.heaters[global.cfgHotend1Heater].active",
	"  set global.sharedHotend1Temp = heat.heaters[global.cfgHotend1Heater].current",
	"  else",
	"    set global.sharedHotend1Target = 0",
	"    set global.sharedHotend1Temp = 0",
	"else",
	"  set global.sharedHotend1Target = 0",
	"  set global.sharedHotend1Temp = 0",
	"",
	"if global.cfgHotend2Heater >= 0",
	"  if #heat.heaters > global.cfgHotend2Heater",
	"  set global.sharedHotend2Target = heat.heaters[global.cfgHotend2Heater].active",
	"  set global.sharedHotend2Temp = heat.heaters[global.cfgHotend2Heater].current",
	"  else",
	"    set global.sharedHotend2Target = 0",
	"    set global.sharedHotend2Temp = 0",
	"else",
	"  set global.sharedHotend2Target = 0",
	"  set global.sharedHotend2Temp = 0",
	"",
	"if global.cfgHotend3Heater >= 0",
	"  if #heat.heaters > global.cfgHotend3Heater",
	"  set global.sharedHotend3Target = heat.heaters[global.cfgHotend3Heater].active",
	"  set global.sharedHotend3Temp = heat.heaters[global.cfgHotend3Heater].current",
	"  else",
	"    set global.sharedHotend3Target = 0",
	"    set global.sharedHotend3Temp = 0",
	"else",
	"  set global.sharedHotend3Target = 0",
	"  set global.sharedHotend3Temp = 0",
	"",
	"if global.cfgHotend4Heater >= 0",
	"  if #heat.heaters > global.cfgHotend4Heater",
	"  set global.sharedHotend4Target = heat.heaters[global.cfgHotend4Heater].active",
	"  set global.sharedHotend4Temp = heat.heaters[global.cfgHotend4Heater].current",
	"  else",
	"    set global.sharedHotend4Target = 0",
	"    set global.sharedHotend4Temp = 0",
	"else",
	"  set global.sharedHotend4Target = 0",
	"  set global.sharedHotend4Temp = 0",
	"",
	"; Sammelzustaende fuer LED",
	"set global.sharedAnyHotendHeating = 0",
	"set global.sharedAnyBedHeating = 0",
	"set global.sharedAnyHotendVeryHot = 0",
	"set global.sharedAnyBedVeryHot = 0",
	"",
	"if global.sharedHotend1Target > 0",
	"  if global.sharedHotend1Temp < (global.sharedHotend1Target - global.cfgLedHotendHeatDelta)",
	"    set global.sharedAnyHotendHeating = 1",
	"if global.sharedHotend2Target > 0",
	"  if global.sharedHotend2Temp < (global.sharedHotend2Target - global.cfgLedHotendHeatDelta)",
	"    set global.sharedAnyHotendHeating = 1",
	"if global.sharedHotend3Target > 0",
	"  if global.sharedHotend3Temp < (global.sharedHotend3Target - global.cfgLedHotendHeatDelta)",
	"    set global.sharedAnyHotendHeating = 1",
	"if global.sharedHotend4Target > 0",
	"  if global.sharedHotend4Temp < (global.sharedHotend4Target - global.cfgLedHotendHeatDelta)",
	"    set global.sharedAnyHotendHeating = 1",
	"",
	"if global.sharedBed1Target > 0",
	"  if global.sharedBed1Temp < (global.sharedBed1Target - global.cfgLedBedHeatDelta)",
	"    set global.sharedAnyBedHeating = 1",
	"if global.sharedBed2Target > 0",
	"  if global.sharedBed2Temp < (global.sharedBed2Target - global.cfgLedBedHeatDelta)",
	"    set global.sharedAnyBedHeating = 1",
	"if global.sharedBed3Target > 0",
	"  if global.sharedBed3Temp < (global.sharedBed3Target - global.cfgLedBedHeatDelta)",
	"    set global.sharedAnyBedHeating = 1",
	"if global.sharedBed4Target > 0",
	"  if global.sharedBed4Temp < (global.sharedBed4Target - global.cfgLedBedHeatDelta)",
	"    set global.sharedAnyBedHeating = 1",
	"",
	"if global.sharedHotend1Temp >= global.cfgLedHotendHotTemp",
	"  set global.sharedAnyHotendVeryHot = 1",
	"if global.sharedHotend2Temp >= global.cfgLedHotendHotTemp",
	"  set global.sharedAnyHotendVeryHot = 1",
	"if global.sharedHotend3Temp >= global.cfgLedHotendHotTemp",
	"  set global.sharedAnyHotendVeryHot = 1",
	"if global.sharedHotend4Temp >= global.cfgLedHotendHotTemp",
	"  set global.sharedAnyHotendVeryHot = 1",
	"",
	"if global.sharedBed1Temp >= global.cfgLedBedHotTemp",
	"  set global.sharedAnyBedVeryHot = 1",
	"if global.sharedBed2Temp >= global.cfgLedBedHotTemp",
	"  set global.sharedAnyBedVeryHot = 1",
	"if global.sharedBed3Temp >= global.cfgLedBedHotTemp",
	"  set global.sharedAnyBedVeryHot = 1",
	"if global.sharedBed4Temp >= global.cfgLedBedHotTemp",
	"  set global.sharedAnyBedVeryHot = 1",
	"",
	"set global.sharedIsHeating = 0",
	"if global.sharedAnyHotendHeating > 0",
	"  set global.sharedIsHeating = 1",
	"if global.sharedAnyBedHeating > 0",
	"  set global.sharedIsHeating = 1",
	"",
	"if #fans > 0",
	"  if fans[0].requestedValue > 0.05",
	"    set global.sharedPartFanOn = 1",
	"  else",
	"    set global.sharedPartFanOn = 0",
	"else",
	"  set global.sharedPartFanOn = 0",
	"",
	"if #sensors.filamentMonitors > 0",
	"  if sensors.filamentMonitors[0].status = \"ok\"",
	"    set global.sharedFilamentOk = 1",
	"  else",
	"    set global.sharedFilamentOk = 0",
	"else",
	"  set global.sharedFilamentOk = 1",
	"",
	"if global.sharedLastStatus = \"processing\"",
	"  if global.sharedStatus = \"idle\"",
	"    set global.sharedDoneTimer = 6",
	"",
	"if global.sharedDoneTimer > 0",
	"  set global.sharedDoneTimer = global.sharedDoneTimer - 1",
	"",
	"if global.sharedStatus = \"idle\"",
	"  set global.sharedIdleSeconds = global.sharedIdleSeconds + 1",
	"else",
	"  set global.sharedIdleSeconds = 0",
	"",
	"set global.sharedBlinkPhase = mod(floor(state.upTime), 2)",
	"",
	"set global.sharedLastStatus = global.sharedStatus",
	""
].join("\n");

const DAEMON_10_LED_LOGIC_G = [
	"; Nutzt nur Shared State, keine direkten heat.heaters-Zugriffe",
	"",
	"if global.cfgDaemonLedEnabled = 0",
	"  M99",
	"if global.cfgLedEnabled = 0",
	"  M99",
	"if global.sharedAnyHeaterTuning > 0",
	"  M99",
	"",
	"var ledState = \"idle\"",
	"var blink = 0",
	"",
	"if global.sharedStatus = \"stopped\"",
	"  set var.ledState = \"error\"",
	"  if global.cfgLedBlinkError > 0",
	"    set var.blink = 1",
	"elif global.sharedStatus = \"paused\"",
	"  set var.ledState = \"paused\"",
	"  if global.cfgLedBlinkPaused > 0",
	"    set var.blink = 1",
	"elif global.sharedStatus = \"pausing\"",
	"  set var.ledState = \"paused\"",
	"  if global.cfgLedBlinkPaused > 0",
	"    set var.blink = 1",
	"elif global.sharedStatus = \"resuming\"",
	"  set var.ledState = \"paused\"",
	"  if global.cfgLedBlinkPaused > 0",
	"    set var.blink = 1",
	"elif global.sharedStatus = \"processing\"",
	"  set var.ledState = \"printing\"",
	"  if global.cfgLedBlinkPrinting > 0",
	"    set var.blink = 1",
	"elif global.sharedStatus = \"changingTool\"",
	"  set var.ledState = \"printing\"",
	"  if global.cfgLedBlinkPrinting > 0",
	"    set var.blink = 1",
	"elif global.sharedIsHeating > 0",
	"  set var.ledState = \"heating\"",
	"  if global.cfgLedBlinkHeating > 0",
	"    set var.blink = 1",
	"elif global.cfgLedUseDoneState > 0",
	"  if global.sharedDoneTimer > 0",
	"    set var.ledState = \"done\"",
	"    if global.cfgLedBlinkDone > 0",
	"      set var.blink = 1",
	"elif global.cfgLedUseFanState > 0",
	"  if global.sharedPartFanOn > 0",
	"    set var.ledState = \"fan\"",
	"    if global.cfgLedBlinkFan > 0",
	"      set var.blink = 1",
	"elif global.sharedAnyHotendVeryHot > 0",
	"  set var.ledState = \"hotendHot\"",
	"  if global.cfgLedBlinkHotendHot > 0",
	"    set var.blink = 1",
	"elif global.sharedAnyBedVeryHot > 0",
	"  set var.ledState = \"bedHot\"",
	"  if global.cfgLedBlinkBedHot > 0",
	"    set var.blink = 1",
	"elif global.cfgLedUseFilamentState > 0",
	"  if global.sharedStatus = \"idle\"",
	"    if global.sharedFilamentOk = 0",
	"      set var.ledState = \"filament\"",
	"      if global.cfgLedBlinkFilament > 0",
	"        set var.blink = 1",
	"else",
	"  set var.ledState = \"idle\"",
	"  if global.cfgLedBlinkIdle > 0",
	"    set var.blink = 1",
	"",
	"var doUpdate = 0",
	"if var.ledState != global.sharedLastLedState",
	"  set var.doUpdate = 1",
	"elif var.blink > 0",
	"  set var.doUpdate = 1",
	"",
	"if var.doUpdate > 0",
	"  if var.blink > 0",
	"    if global.sharedBlinkPhase = 0",
	"      M150 E{global.cfgLedStrip} R0 U0 B0 P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"    else",
	"      if var.ledState = \"error\"",
	"        M150 E{global.cfgLedStrip} R{global.cfgLedColorErrorR} U{global.cfgLedColorErrorG} B{global.cfgLedColorErrorB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"      elif var.ledState = \"paused\"",
	"        M150 E{global.cfgLedStrip} R{global.cfgLedColorPausedR} U{global.cfgLedColorPausedG} B{global.cfgLedColorPausedB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"      elif var.ledState = \"printing\"",
	"        M150 E{global.cfgLedStrip} R{global.cfgLedColorPrintingR} U{global.cfgLedColorPrintingG} B{global.cfgLedColorPrintingB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"      elif var.ledState = \"heating\"",
	"        M150 E{global.cfgLedStrip} R{global.cfgLedColorHeatingR} U{global.cfgLedColorHeatingG} B{global.cfgLedColorHeatingB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"      elif var.ledState = \"done\"",
	"        M150 E{global.cfgLedStrip} R{global.cfgLedColorDoneR} U{global.cfgLedColorDoneG} B{global.cfgLedColorDoneB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"      elif var.ledState = \"fan\"",
	"        M150 E{global.cfgLedStrip} R{global.cfgLedColorFanR} U{global.cfgLedColorFanG} B{global.cfgLedColorFanB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"      elif var.ledState = \"hotendHot\"",
	"        M150 E{global.cfgLedStrip} R{global.cfgLedColorHotendHotR} U{global.cfgLedColorHotendHotG} B{global.cfgLedColorHotendHotB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"      elif var.ledState = \"bedHot\"",
	"        M150 E{global.cfgLedStrip} R{global.cfgLedColorBedHotR} U{global.cfgLedColorBedHotG} B{global.cfgLedColorBedHotB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"      elif var.ledState = \"filament\"",
	"        M150 E{global.cfgLedStrip} R{global.cfgLedColorFilamentR} U{global.cfgLedColorFilamentG} B{global.cfgLedColorFilamentB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"      else",
	"        M150 E{global.cfgLedStrip} R{global.cfgLedColorIdleR} U{global.cfgLedColorIdleG} B{global.cfgLedColorIdleB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"  else",
	"    if var.ledState = \"error\"",
	"      M150 E{global.cfgLedStrip} R{global.cfgLedColorErrorR} U{global.cfgLedColorErrorG} B{global.cfgLedColorErrorB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"    elif var.ledState = \"paused\"",
	"      M150 E{global.cfgLedStrip} R{global.cfgLedColorPausedR} U{global.cfgLedColorPausedG} B{global.cfgLedColorPausedB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"    elif var.ledState = \"printing\"",
	"      M150 E{global.cfgLedStrip} R{global.cfgLedColorPrintingR} U{global.cfgLedColorPrintingG} B{global.cfgLedColorPrintingB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"    elif var.ledState = \"heating\"",
	"      M150 E{global.cfgLedStrip} R{global.cfgLedColorHeatingR} U{global.cfgLedColorHeatingG} B{global.cfgLedColorHeatingB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"    elif var.ledState = \"done\"",
	"      M150 E{global.cfgLedStrip} R{global.cfgLedColorDoneR} U{global.cfgLedColorDoneG} B{global.cfgLedColorDoneB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"    elif var.ledState = \"fan\"",
	"      M150 E{global.cfgLedStrip} R{global.cfgLedColorFanR} U{global.cfgLedColorFanG} B{global.cfgLedColorFanB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"    elif var.ledState = \"hotendHot\"",
	"      M150 E{global.cfgLedStrip} R{global.cfgLedColorHotendHotR} U{global.cfgLedColorHotendHotG} B{global.cfgLedColorHotendHotB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"    elif var.ledState = \"bedHot\"",
	"      M150 E{global.cfgLedStrip} R{global.cfgLedColorBedHotR} U{global.cfgLedColorBedHotG} B{global.cfgLedColorBedHotB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"    elif var.ledState = \"filament\"",
	"      M150 E{global.cfgLedStrip} R{global.cfgLedColorFilamentR} U{global.cfgLedColorFilamentG} B{global.cfgLedColorFilamentB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"    else",
	"      M150 E{global.cfgLedStrip} R{global.cfgLedColorIdleR} U{global.cfgLedColorIdleG} B{global.cfgLedColorIdleB} P{global.cfgLedBrightness} S{global.cfgLedCount}",
	"  if var.ledState != global.sharedLastLedState",
	"    M118 P0 S{\"LED state=\" ^ var.ledState ^ \" status=\" ^ global.sharedStatus}",
	"  set global.sharedLastLedState = var.ledState",
	"  set global.sharedLastLedBlinkPhase = global.sharedBlinkPhase",
	""
].join("\n");

const DAEMON_20_HEATER_MODEL_LOGIC_G = [
	"; Nutzt nur Shared State",
	"; Keine Dateischreibvorgaenge, nur fileexists + M98",
	"; Nur bei Modellwechsel laden und optional melden",
	"",
	"; Modul-Schalter (wird in 00_config.g gesetzt)",
	"if global.cfgDaemonHeaterModelEnabled = 0",
	"  M99",
	"if global.sharedAnyHeaterTuning > 0",
	"  M99",
	"; Waehrend Jobs/Kalibrierung nichts nachladen (Standard bleibt aktiv)",
	"if global.sharedStatus = \"processing\"",
	"  M99",
	"if global.sharedStatus = \"pausing\"",
	"  M99",
	"if global.sharedStatus = \"paused\"",
	"  M99",
	"if global.sharedStatus = \"resuming\"",
	"  M99",
	"if global.sharedStatus = \"changingTool\"",
	"  M99",
	"",
	"; -------- Bed_1 --------",
	"if global.cfgBed1Heater >= 0",
	"  if global.sharedBed1Target > 0",
	"    var target = round(global.sharedBed1Target)",
	"    if fileexists({\"0:/sys/Temp_bed/Bed_1/bedmodel_\" ^ var.target ^ \".g\"})",
	"      if global.bed1ModelSel != var.target",
	"        M98 P{\"0:/sys/Temp_bed/Bed_1/bedmodel_\" ^ var.target ^ \".g\"}",
	"        set global.bed1ModelSel = var.target",
	"        M118 P0 S{\"Bed_1 heater model geladen: \" ^ var.target ^ \"C\"}",
	"",
	"; -------- Bed_2 --------",
	"if global.cfgBed2Heater >= 0",
	"  if global.sharedBed2Target > 0",
	"    var target = round(global.sharedBed2Target)",
	"    if fileexists({\"0:/sys/Temp_bed/Bed_2/bedmodel_\" ^ var.target ^ \".g\"})",
	"      if global.bed2ModelSel != var.target",
	"        M98 P{\"0:/sys/Temp_bed/Bed_2/bedmodel_\" ^ var.target ^ \".g\"}",
	"        set global.bed2ModelSel = var.target",
	"        M118 P0 S{\"Bed_2 heater model geladen: \" ^ var.target ^ \"C\"}",
	"",
	"; -------- Bed_3 --------",
	"if global.cfgBed3Heater >= 0",
	"  if global.sharedBed3Target > 0",
	"    var target = round(global.sharedBed3Target)",
	"    if fileexists({\"0:/sys/Temp_bed/Bed_3/bedmodel_\" ^ var.target ^ \".g\"})",
	"      if global.bed3ModelSel != var.target",
	"        M98 P{\"0:/sys/Temp_bed/Bed_3/bedmodel_\" ^ var.target ^ \".g\"}",
	"        set global.bed3ModelSel = var.target",
	"        M118 P0 S{\"Bed_3 heater model geladen: \" ^ var.target ^ \"C\"}",
	"",
	"; -------- Bed_4 --------",
	"if global.cfgBed4Heater >= 0",
	"  if global.sharedBed4Target > 0",
	"    var target = round(global.sharedBed4Target)",
	"    if fileexists({\"0:/sys/Temp_bed/Bed_4/bedmodel_\" ^ var.target ^ \".g\"})",
	"      if global.bed4ModelSel != var.target",
	"        M98 P{\"0:/sys/Temp_bed/Bed_4/bedmodel_\" ^ var.target ^ \".g\"}",
	"        set global.bed4ModelSel = var.target",
	"        M118 P0 S{\"Bed_4 heater model geladen: \" ^ var.target ^ \"C\"}",
	"",
	"; -------- Hotend_1 --------",
	"if global.cfgHotend1Heater >= 0",
	"  if global.sharedHotend1Target > 0",
	"    var target = round(global.sharedHotend1Target)",
	"    if fileexists({\"0:/sys/Temp_hotend/Hotend_1/hotendmodel_\" ^ var.target ^ \".g\"})",
	"      if global.hotend1ModelSel != var.target",
	"        M98 P{\"0:/sys/Temp_hotend/Hotend_1/hotendmodel_\" ^ var.target ^ \".g\"}",
	"        set global.hotend1ModelSel = var.target",
	"        M118 P0 S{\"Hotend_1 heater model geladen: \" ^ var.target ^ \"C\"}",
	"",
	"; -------- Hotend_2 --------",
	"if global.cfgHotend2Heater >= 0",
	"  if global.sharedHotend2Target > 0",
	"    var target = round(global.sharedHotend2Target)",
	"    if fileexists({\"0:/sys/Temp_hotend/Hotend_2/hotendmodel_\" ^ var.target ^ \".g\"})",
	"      if global.hotend2ModelSel != var.target",
	"        M98 P{\"0:/sys/Temp_hotend/Hotend_2/hotendmodel_\" ^ var.target ^ \".g\"}",
	"        set global.hotend2ModelSel = var.target",
	"        M118 P0 S{\"Hotend_2 heater model geladen: \" ^ var.target ^ \"C\"}",
	"",
	"; -------- Hotend_3 --------",
	"if global.cfgHotend3Heater >= 0",
	"  if global.sharedHotend3Target > 0",
	"    var target = round(global.sharedHotend3Target)",
	"    if fileexists({\"0:/sys/Temp_hotend/Hotend_3/hotendmodel_\" ^ var.target ^ \".g\"})",
	"      if global.hotend3ModelSel != var.target",
	"        M98 P{\"0:/sys/Temp_hotend/Hotend_3/hotendmodel_\" ^ var.target ^ \".g\"}",
	"        set global.hotend3ModelSel = var.target",
	"        M118 P0 S{\"Hotend_3 heater model geladen: \" ^ var.target ^ \"C\"}",
	"",
	"; -------- Hotend_4 --------",
	"if global.cfgHotend4Heater >= 0",
	"  if global.sharedHotend4Target > 0",
	"    var target = round(global.sharedHotend4Target)",
	"    if fileexists({\"0:/sys/Temp_hotend/Hotend_4/hotendmodel_\" ^ var.target ^ \".g\"})",
	"      if global.hotend4ModelSel != var.target",
	"        M98 P{\"0:/sys/Temp_hotend/Hotend_4/hotendmodel_\" ^ var.target ^ \".g\"}",
	"        set global.hotend4ModelSel = var.target",
	"        M118 P0 S{\"Hotend_4 heater model geladen: \" ^ var.target ^ \"C\"}",
	""
].join("\n");

const DAEMON_30_IDLE_SHUTDOWN_G = [
	"; --------------------------------------------------",
	"; /sys/Daemon/30_idle_shutdown.g",
	"; Auto-Standby bei Nichtbenutzung",
	"; Nutzt nur Shared-State + Config",
	"; --------------------------------------------------",
	"",
	"if global.sharedAnyHeaterTuning > 0",
	"  M99",
	"if global.cfgIdleShutdownEnabled > 0",
	"  if global.sharedStatus = \"idle\"",
	"    if global.sharedIdleSeconds >= global.cfgIdleShutdownSeconds",
	"",
	"      if global.cfgHotend1Heater >= 0",
	"        if #heat.heaters > global.cfgHotend1Heater",
	"          if heat.heaters[global.cfgHotend1Heater].active > 0",
	"            M104 H{global.cfgHotend1Heater} S0",
	"",
	"      if global.cfgHotend2Heater >= 0",
	"        if #heat.heaters > global.cfgHotend2Heater",
	"          if heat.heaters[global.cfgHotend2Heater].active > 0",
	"            M104 H{global.cfgHotend2Heater} S0",
	"",
	"      if global.cfgHotend3Heater >= 0",
	"        if #heat.heaters > global.cfgHotend3Heater",
	"          if heat.heaters[global.cfgHotend3Heater].active > 0",
	"            M104 H{global.cfgHotend3Heater} S0",
	"",
	"      if global.cfgHotend4Heater >= 0",
	"        if #heat.heaters > global.cfgHotend4Heater",
	"          if heat.heaters[global.cfgHotend4Heater].active > 0",
	"            M104 H{global.cfgHotend4Heater} S0",
	"",
	"      if global.cfgBed1Heater >= 0",
	"        if #heat.heaters > global.cfgBed1Heater",
	"          if heat.heaters[global.cfgBed1Heater].active > 0",
	"            M140 H{global.cfgBed1Heater} S0",
	"",
	"      if global.cfgBed2Heater >= 0",
	"        if #heat.heaters > global.cfgBed2Heater",
	"          if heat.heaters[global.cfgBed2Heater].active > 0",
	"            M140 H{global.cfgBed2Heater} S0",
	"",
	"      if global.cfgBed3Heater >= 0",
	"        if #heat.heaters > global.cfgBed3Heater",
	"          if heat.heaters[global.cfgBed3Heater].active > 0",
	"            M140 H{global.cfgBed3Heater} S0",
	"",
	"      if global.cfgBed4Heater >= 0",
	"        if #heat.heaters > global.cfgBed4Heater",
	"          if heat.heaters[global.cfgBed4Heater].active > 0",
	"            M140 H{global.cfgBed4Heater} S0",
	"",
	"      if global.cfgIdleShutdownFanEnabled > 0",
	"        if #fans > 0",
	"          M106 P0 S0",
	"",
	"      set global.sharedIdleSeconds = 0",
	"      M118 P0 S\"Idle shutdown ausgefuehrt\"",
	""
].join("\n");

const DEFAULT_SHARED_PRINT = {
	materialName: "",
	hotendTemp: 210,
	bedTemp: 55,
	nozzleDia: 0.4,
	layerH: 0.20,
	meshMargin: 5,
	lineW: 0.48,
	printSpeed: 40,
	fanPct: 40,
	flowPct: 100,
	firstLayerSpeed: 20,
	travelSpeed: 150,
	levelGridAdvanced: false,
	levelPadCountX: 3,
	levelPadCountY: 3,
	levelPadW: 30,
	levelPadH: 30,
	levelPadGap: 8
};

const DEFAULT_SHARED_BED = {
	minX: 0,
	maxX: 250,
	minY: 0,
	maxY: 210
};

const DEFAULT_FORM = {
	H: 210, B: 55,
	C: 90, D: 4, R: 1,
	P: 18, G: 4, Z: 6,
	X: 0, Y: 0
};

const DEFAULT_EVALUATION = {
	measured: 0.48,
	target: 0.45,
	currentFlow: 100
};

const DEFAULT_BOX_TEST = {
	H: 215,
	B: 60,
	W: null,
	S: 40,
	Z: 60,
	X: 80,
	Y: 80
};

const DEFAULT_Z_CAL = {
	safeLift: 5,
	savePath: "0:/macros/Kalibrieren/z_calibration_ir_mini.g"
};

const DEFAULT_SZP_TEST = {
	X: 125,
	Y: 110,
	N: 20,
	Z: 6,
	savePath: "0:/macros/Kalibrieren/szp_repeatability_test.g"
};

const DEFAULT_IR_REPEAT_TEST = {
	X: 150,
	Y: 150,
	Zsafe: 5,
	N: 20,
	travelOffset: 50,
	savePath: "0:/macros/Kalibrieren/probe_repeatability.g"
};

const DEFAULT_PID_SERIES = {
	H: 0,
	fans: [],
	fanPct: 0,
	A: 50,
	E: 100,
	I: 5,
	C: 30,
	useCsv: false,
	F: "0:/sys/Pidwerte/pid_log.csv",
	heaterKindOverrides: {}
};

const DEFAULT_FLOW_TEST = {
	testMode: "prusa",
	hotendTemp: 210,
	bedTemp: 60
};

const DEFAULT_PA_TUNING = {
	bedTemp: 55,
	hotendTemp: 205,
	flowFactor: 0.9,
	startPA: 0.0,
	endPA: 0.15,
	stepPA: 0.005,
	zFirst: 0.28,
	vPrint: 80,
	accel: 3000,
	lineLen: 90,
	gapY: 7,
	labelOffsetX: 10,
	labelDy: -2,
	digitW: 3.0,
	digitH: 6.0,
	digitGap: 1.5,
	lineW: 0.45,
	layerH: 0.20,
	filDia: 1.75,
	scale: 1.0,
	offsetX: 0,
	offsetY: 0,
	doFrame: true,
	frameLoops: 2,
	frameWidth: 12,
	frameGap: 4,
	frameExtraY: 6,
	tieEveryN: 1,
	travelRetract: 0.20,
	travelZhop: 0.30,
	fRetract: 1800,
	fZ: 1200,
	fMove: 9000,
	fFrame: 1200,
	paDrive: 0,
	savePath: "0:/macros/Kalibrieren/PA_Test_Label.g"
};

const SEGMENTS = {
	0: ["A", "B", "C", "D", "E", "F"],
	1: ["B", "C"],
	2: ["A", "B", "G", "E", "D"],
	3: ["A", "B", "G", "C", "D"],
	4: ["F", "G", "B", "C"],
	5: ["A", "F", "G", "C", "D"],
	6: ["A", "F", "G", "C", "D", "E"],
	7: ["A", "B", "C"],
	8: ["A", "B", "C", "D", "E", "F", "G"],
	9: ["A", "B", "C", "D", "F", "G"]
};

function toNum(value, fallback) {
	const parsed = Number(value);
	return Number.isFinite(parsed) ? parsed : fallback;
}

function fmt(value, digits = 4) {
	if (!Number.isFinite(value)) {
		return "0";
	}
	return Number(value).toFixed(digits).replace(/\.0+$/, "").replace(/(\.\d*?)0+$/, "$1");
}

function cloneDefaults() {
	return JSON.parse(JSON.stringify(DEFAULT_FORM));
}

function readStoredObject(key, defaults) {
	try {
		const raw = localStorage.getItem(key);
		if (!raw) {
			return { ...defaults };
		}
		const parsed = JSON.parse(raw);
		if (!parsed || typeof parsed !== "object") {
			return { ...defaults };
		}
		return { ...defaults, ...parsed };
	} catch (_error) {
		return { ...defaults };
	}
}

function readVersionedObject(key, defaults, migrate = (value) => value) {
	try {
		const raw = localStorage.getItem(key);
		if (!raw) {
			return { ...defaults };
		}
		const parsed = JSON.parse(raw);
		if (!parsed || typeof parsed !== "object") {
			return { ...defaults };
		}
		if (Object.prototype.hasOwnProperty.call(parsed, "__v") && Object.prototype.hasOwnProperty.call(parsed, "data")) {
			const merged = { ...defaults, ...(parsed.data || {}) };
			return migrate(merged);
		}
		// legacy format (plain object)
		const legacyMerged = { ...defaults, ...parsed };
		return migrate(legacyMerged);
	} catch (_error) {
		return { ...defaults };
	}
}

function writeVersionedObject(key, value) {
	localStorage.setItem(key, JSON.stringify({ __v: STORAGE_SCHEMA_VERSION, data: value || {} }));
}

export default {
	data() {
		const savedStartCode = localStorage.getItem(START_CODE_STORAGE_KEY);
		const savedEndCode = localStorage.getItem(END_CODE_STORAGE_KEY);
		const normalizedSavedEndCode = String(savedEndCode || "").trim();
		const endCodeInitial = !normalizedSavedEndCode || normalizedSavedEndCode === LEGACY_END_CODE_WITH_SYS_END
			? DEFAULT_END_CODE
			: normalizedSavedEndCode;
		const savedSharedPrint = readVersionedObject(SHARED_PRINT_STORAGE_KEY, DEFAULT_SHARED_PRINT);
		const savedSharedBed = readVersionedObject(SHARED_BED_STORAGE_KEY, DEFAULT_SHARED_BED);
		const savedUiTabs = readVersionedObject(UI_TABS_STORAGE_KEY, DEFAULT_UI_TABS);
		const savedDaemonCfg = readVersionedObject(DAEMON_CFG_STORAGE_KEY, DEFAULT_DAEMON_CFG);
		const savedPidSeries = readVersionedObject(PID_SERIES_STORAGE_KEY, DEFAULT_PID_SERIES, (value) => ({
			...value
		}));
		const savedDaemonCustom = localStorage.getItem(DAEMON_CUSTOM_STORAGE_KEY) || "";
		return {
			form: cloneDefaults(),
			bestFlow: 90,
			sharedPrint: savedSharedPrint,
			sharedBed: savedSharedBed,
			uiTabs: savedUiTabs,
			daemonCustomCommands: savedDaemonCustom,
			startCode: savedStartCode || DEFAULT_START_CODE,
			endCode: endCodeInitial,
			copyInfo: "",
			infoText: "",
			errorText: "",
			lastJobFile: "",
			activeMode: "flow",
			boxTest: { ...DEFAULT_BOX_TEST },
			boxTestMessage: "",
			boxTestMessageType: "info",
			probeZCal: { ...DEFAULT_Z_CAL },
			szpTest: { ...DEFAULT_SZP_TEST },
			irRepeatTest: { ...DEFAULT_IR_REPEAT_TEST },
			pidSeries: { ...savedPidSeries },
			paTuning: { ...DEFAULT_PA_TUNING },
			flowTest: { ...DEFAULT_FLOW_TEST },
			probeMessage: "",
			probeMessageType: "info",
			pidMessage: "",
			pidMessageType: "info",
			paMessage: "",
			paMessageType: "info",
			ledControl: {
				strip: 0,
				count: 60,
				brightness: 255,
				color: "#ffffff",
				r: 255,
				g: 255,
				b: 255,
				w: 0
			},
			ledMessage: "",
			ledMessageType: "info",
			flowTestMessage: "",
			flowTestMessageType: "info",
			settingsMessage: "",
			settingsMessageType: "info",
			daemonMessage: "",
			daemonMessageType: "info",
			daemonCfg: { ...savedDaemonCfg },
			flowTestLineWManual: false,
			flowTestLineWAutoWrite: false,
			flowTestSelectedProbe: 0,
			flowTestProbeZOffsetBaseByK: {},
			flowTestProbeZOffsetCurrentByK: {},
			flowTestLiveBabystepTotal: 0,
			flowTestSyncingLive: false,
			generatedTestFiles: [],
			cleanupInProgress: false,
			evaluation: { ...DEFAULT_EVALUATION },
			evaluationMessage: "",
			evaluationMessageType: "info"
		};
	},
	watch: {
		startCode(value) {
			localStorage.setItem(START_CODE_STORAGE_KEY, value || "");
		},
		endCode(value) {
			localStorage.setItem(END_CODE_STORAGE_KEY, value || "");
		},
		"sharedPrint.nozzleDia"(value) {
			if (this.flowTestLineWManual) {
				return;
			}
			const autoWidth = this.resolveLineWidth(toNum(value, DEFAULT_SHARED_PRINT.nozzleDia));
			this.flowTestLineWAutoWrite = true;
			this.sharedPrint.lineW = Number(fmt(autoWidth, 3));
		},
		"sharedPrint.lineW"(value) {
			if (this.flowTestLineWAutoWrite) {
				this.flowTestLineWAutoWrite = false;
				return;
			}
			const num = Number(value);
			if (!Number.isFinite(num)) {
				return;
			}
			const expected = this.resolveLineWidth(toNum(this.sharedPrint.nozzleDia, DEFAULT_SHARED_PRINT.nozzleDia));
			if (Math.abs(num - expected) > 0.0005) {
				this.flowTestLineWManual = true;
			}
		},
		flowTestSelectedProbe() {
			const idx = this.getSelectedProbeIndex();
			this.ensureProbeZCache(idx);
			this.syncLiveBabystepToSelectedProbe();
		},
		uiTabs: {
			deep: true,
			handler(value) {
				writeVersionedObject(UI_TABS_STORAGE_KEY, value || {});
				this.ensureValidActiveMode();
			}
		},
		sharedPrint: {
			deep: true,
			handler(value) {
				writeVersionedObject(SHARED_PRINT_STORAGE_KEY, value || {});
			}
		},
		sharedBed: {
			deep: true,
			handler(value) {
				writeVersionedObject(SHARED_BED_STORAGE_KEY, value || {});
			}
		},
		daemonCfg: {
			deep: true,
			handler(value) {
				writeVersionedObject(DAEMON_CFG_STORAGE_KEY, value || {});
			}
		},
		pidSeries: {
			deep: true,
			handler(value) {
				writeVersionedObject(PID_SERIES_STORAGE_KEY, value || {});
			}
		},
		daemonCustomCommands(value) {
			localStorage.setItem(DAEMON_CUSTOM_STORAGE_KEY, value || "");
		},
		activeMode() {
			this.ensureValidActiveMode();
		},
		stateStatus(newStatus, oldStatus) {
			const wasPrinting = ["processing", "paused", "pausing", "resuming"].includes(oldStatus);
			const isPrintingNow = ["processing", "paused", "pausing", "resuming"].includes(newStatus);
			if (wasPrinting && !isPrintingNow) {
				this.cleanupGeneratedTestFiles();
			}
		}
	},
	created() {
		this.ensureValidActiveMode();
	},
	computed: {
		model() {
			return this.$store?.state?.machine?.model || {};
		},
		stateStatus() {
			return this.model.state?.status || "unknown";
		},
		currentFile() {
			return this.model.job?.file?.fileName || this.lastJobFile || "";
		},
		progressPercent() {
			const filePos = this.model.job?.filePosition;
			const fileSize = this.model.job?.file?.size;
			if (filePos != null && fileSize) {
				return Math.max(0, Math.min(100, (filePos / fileSize) * 100));
			}
			const p = Number(this.model.job?.progress || 0);
			return Math.max(0, Math.min(100, p));
		},
		isPrinting() {
			return ["processing", "paused", "pausing", "resuming"].includes(this.stateStatus);
		},
		isPaused() {
			return this.stateStatus === "paused";
		},
		statusText() {
			return this.stateStatus;
		},
		bestResultText() {
			const prefix = this.sharedPrint.materialName ? `${this.sharedPrint.materialName}: ` : "";
			return `${prefix}Ergebnis im Slicer eintragen`;
		},
		evaluationFlowValue() {
			const measured = toNum(this.evaluation.measured, 0);
			const target = toNum(this.evaluation.target, 0);
			const currentFlow = toNum(this.evaluation.currentFlow, 0);
			if (measured <= 0 || target <= 0 || currentFlow <= 0) {
				return null;
			}
			return currentFlow * (target / measured);
		},
		evaluationFlowText() {
			const value = this.evaluationFlowValue;
			if (value == null) {
				return "Messwerte erforderlich";
			}
			return `${fmt(value, 3)} %`;
		},
		probeSelectItems() {
			const probes = Array.isArray(this.model?.sensors?.probes) ? this.model.sensors.probes : [];
			const items = [];
			for (let i = 0; i < probes.length; i++) {
				if (probes[i] !== null && probes[i] !== undefined) {
					items.push({ text: `K${i}`, value: i });
				}
			}
			if (items.length === 0) {
				items.push({ text: "K0", value: 0 });
			}
			return items;
		},
		heaterSelectItems() {
			const heaters = Array.isArray(this.model?.heat?.heaters) ? this.model.heat.heaters : [];
			const items = [];
			const kindLabel = (kind) => {
				if (kind === "bed") return "Bed";
				if (kind === "chamber") return "Chamber";
				return "Hotend";
			};
			for (let i = 0; i < heaters.length; i++) {
				if (heaters[i] !== null && heaters[i] !== undefined) {
					const name = String(heaters[i]?.name || "").trim();
					const kind = this.classifyHeaterKind(i);
					const autoKind = this.classifyHeaterKind(i, { ignoreOverride: true });
					const overrideMark = kind !== autoKind ? " (override)" : "";
					items.push({ text: name ? `H${i} (${name}) [${kindLabel(kind)}${overrideMark}]` : `H${i} [${kindLabel(kind)}${overrideMark}]`, value: i });
				}
			}
			if (items.length === 0) {
				items.push({ text: "H0", value: 0 });
			}
			return items;
		},
		fanSelectItems() {
			const fans = Array.isArray(this.model?.fans) ? this.model.fans : [];
			const items = [];
			for (let i = 0; i < fans.length; i++) {
				if (fans[i] !== null && fans[i] !== undefined) {
					const name = String(fans[i]?.name || "").trim();
					items.push({ text: name ? `Luefter P${i} (${name})` : `Luefter P${i}`, value: i });
				}
			}
			return items;
		},
		pidTargetInfoText() {
			const heater = Math.floor(toNum(this.pidSeries?.H, DEFAULT_PID_SERIES.H));
			const info = this.getPidTargetInfo(heater);
			return `${info.label}: ${info.baseDir}`;
		},
		pidHeaterKindOverrideItems() {
			return [
				{ text: "Auto", value: "auto" },
				{ text: "Bed", value: "bed" },
				{ text: "Hotend", value: "hotend" },
				{ text: "Chamber", value: "chamber" }
			];
		},
		pidHeaterKindOverrideSelected: {
			get() {
				const heater = Math.floor(toNum(this.pidSeries?.H, DEFAULT_PID_SERIES.H));
				const map = this.pidSeries?.heaterKindOverrides || {};
				const raw = String(map?.[heater] || "auto").toLowerCase();
				return ["bed", "hotend", "chamber"].includes(raw) ? raw : "auto";
			},
			set(value) {
				const heater = Math.floor(toNum(this.pidSeries?.H, DEFAULT_PID_SERIES.H));
				const normalized = String(value || "auto").toLowerCase();
				const map = { ...(this.pidSeries?.heaterKindOverrides || {}) };
				if (["bed", "hotend", "chamber"].includes(normalized)) {
					map[heater] = normalized;
				} else {
					delete map[heater];
				}
				this.pidSeries = {
					...this.pidSeries,
					heaterKindOverrides: map
				};
			}
		},
		pidDetectedKindText() {
			const heater = Math.floor(toNum(this.pidSeries?.H, DEFAULT_PID_SERIES.H));
			const autoKind = this.classifyHeaterKind(heater, { ignoreOverride: true });
			if (autoKind === "bed") return "Bed";
			if (autoKind === "chamber") return "Chamber";
			return "Hotend";
		},
		ledStripItems() {
			const stripCount = Math.max(1, Math.floor(toNum(this.model?.ledStrips?.length, 1)));
			const items = [];
			for (let i = 0; i < stripCount; i++) {
				items.push({ text: `Strip E${i}`, value: i });
			}
			return items;
		},
		ledPreviewCommand() {
			const strip = Math.max(0, Math.floor(toNum(this.ledControl.strip, 0)));
			const count = Math.max(1, Math.floor(toNum(this.ledControl.count, 1)));
			const r = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.r, 0))));
			const g = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.g, 0))));
			const b = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.b, 0))));
			const w = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.w, 0))));
			const p = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.brightness, 255))));
			const whitePart = w > 0 ? ` W${w}` : "";
			return `M150 E${strip} S${count} R${r} U${g} B${b}${whitePart} P${p}`;
		},
		daemonLedActionItems() {
			return [
				{ id: "error", label: "Fehler", colorKey: "colorError", blinkKey: "blinkError" },
				{ id: "paused", label: "Pausiert", colorKey: "colorPaused", blinkKey: "blinkPaused" },
				{ id: "printing", label: "Drucken", colorKey: "colorPrinting", blinkKey: "blinkPrinting" },
				{ id: "heating", label: "Aufheizen", colorKey: "colorHeating", blinkKey: "blinkHeating" },
				{ id: "done", label: "Fertig", colorKey: "colorDone", blinkKey: "blinkDone" },
				{ id: "fan", label: "Luefter aktiv", colorKey: "colorFan", blinkKey: "blinkFan" },
				{ id: "hotendHot", label: "Hotend heiss", colorKey: "colorHotendHot", blinkKey: "blinkHotendHot" },
				{ id: "bedHot", label: "Bett heiss", colorKey: "colorBedHot", blinkKey: "blinkBedHot" },
				{ id: "filament", label: "Filament Fehler", colorKey: "colorFilament", blinkKey: "blinkFilament" },
				{ id: "idle", label: "Idle", colorKey: "colorIdle", blinkKey: "blinkIdle" }
			];
		},
		currentProbeZOffsetValue() {
			const idx = this.getSelectedProbeIndex();
			const local = Number(this.flowTestProbeZOffsetCurrentByK?.[idx]);
			const baseValue = Number.isFinite(local) ? local : this.getProbeModelOffset(idx);
			const machineLive = this.getMachineZBabystep();
			return baseValue + machineLive;
		},
		currentProbeZOffsetText() {
			const idx = this.getSelectedProbeIndex();
			const value = this.currentProbeZOffsetValue;
			const base = Number(this.flowTestProbeZOffsetBaseByK?.[idx]);
			const machineLive = this.getMachineZBabystep();
			const delta = Number.isFinite(base) ? (value - base) : machineLive;
			return `${value >= 0 ? "+" : ""}${fmt(value, 3)} mm (Live ${delta >= 0 ? "+" : ""}${fmt(delta, 3)} mm)`;
		},
		showStartEndEditor() {
			return false;
		}
	},
	methods: {
		getVisibleModes() {
			const tabs = this.uiTabs || {};
			const modes = [];
			if (tabs.flow) modes.push("flow");
			if (tabs.evaluation) modes.push("evaluation");
			if (tabs.probe) modes.push("probe");
			if (tabs.pid) modes.push("pid");
			if (tabs.pa) modes.push("pa");
			if (tabs.flowtest) modes.push("flowtest");
			if (tabs.led) modes.push("led");
			if (tabs.daemon) modes.push("daemon");
			return modes;
		},
		ensureValidActiveMode() {
			if (this.activeMode === "settings") {
				return;
			}
			const visible = this.getVisibleModes();
			if (!visible.includes(this.activeMode)) {
				this.activeMode = visible.length > 0 ? visible[0] : "settings";
			}
		},
		setInfo(message) {
			this.infoText = message;
			this.errorText = "";
		},
		setError(message) {
			this.errorText = message;
			this.infoText = "";
		},
		setEvaluationMessage(message, type = "info") {
			this.evaluationMessage = message;
			this.evaluationMessageType = type;
		},
		setBoxTestMessage(message, type = "info") {
			this.boxTestMessage = message;
			this.boxTestMessageType = type;
		},
		setProbeMessage(message, type = "info") {
			this.probeMessage = message;
			this.probeMessageType = type;
		},
		setPidMessage(message, type = "info") {
			this.pidMessage = message;
			this.pidMessageType = type;
		},
		setPaMessage(message, type = "info") {
			this.paMessage = message;
			this.paMessageType = type;
		},
		setLedMessage(message, type = "info") {
			this.ledMessage = message;
			this.ledMessageType = type;
		},
		setFlowTestMessage(message, type = "info") {
			this.flowTestMessage = message;
			this.flowTestMessageType = type;
		},
		setSettingsMessage(message, type = "info") {
			this.settingsMessage = message;
			this.settingsMessageType = type;
		},
		setDaemonMessage(message, type = "info") {
			this.daemonMessage = message;
			this.daemonMessageType = type;
		},
		runMacroSelfCheck() {
			try {
				const daemonCfg = this.sanitizeDaemonCfg(this.daemonCfg);
				const errors = [];
				errors.push(...this.validateDaemonGeneratedFiles(daemonCfg));
				errors.push(...this.validateGeneratedMacro("pid_series_macro", this.buildPidSeriesMacro()));
				errors.push(...this.validateGeneratedMacro("box_test_macro", this.buildBoxTestMacro()));
				errors.push(...this.validateGeneratedMacro("flow_plate_macro", this.buildFlowPlaettchenMacro()));
				if (errors.length > 0) {
					this.setSettingsMessage(`Selbsttest fehlgeschlagen: ${errors.join(" | ")}`, "error");
					return;
				}
				this.setSettingsMessage("Selbsttest erfolgreich: Makro-Generatoren sind konsistent", "info");
			} catch (error) {
				this.setSettingsMessage(error.message || "Selbsttest konnte nicht ausgeführt werden", "error");
			}
		},
		saveSharedSettings() {
			try {
				this.sharedPrint.levelGridAdvanced = Boolean(this.sharedPrint.levelGridAdvanced);
				this.sharedPrint.levelPadCountX = Math.max(2, Math.floor(toNum(this.sharedPrint.levelPadCountX, DEFAULT_SHARED_PRINT.levelPadCountX)));
				this.sharedPrint.levelPadCountY = Math.max(2, Math.floor(toNum(this.sharedPrint.levelPadCountY, DEFAULT_SHARED_PRINT.levelPadCountY)));
				this.sharedPrint.levelPadW = Math.max(1, toNum(this.sharedPrint.levelPadW, DEFAULT_SHARED_PRINT.levelPadW));
				this.sharedPrint.levelPadH = Math.max(1, toNum(this.sharedPrint.levelPadH, DEFAULT_SHARED_PRINT.levelPadH));
				this.sharedPrint.levelPadGap = Math.max(0, toNum(this.sharedPrint.levelPadGap, DEFAULT_SHARED_PRINT.levelPadGap));

				// Apply shared temperature defaults immediately to all test-local temp fields
				this.form.H = toNum(this.sharedPrint.hotendTemp, DEFAULT_SHARED_PRINT.hotendTemp);
				this.form.B = toNum(this.sharedPrint.bedTemp, DEFAULT_SHARED_PRINT.bedTemp);
				this.boxTest.H = toNum(this.sharedPrint.hotendTemp, DEFAULT_SHARED_PRINT.hotendTemp);
				this.boxTest.B = toNum(this.sharedPrint.bedTemp, DEFAULT_SHARED_PRINT.bedTemp);
				this.flowTest.hotendTemp = toNum(this.sharedPrint.hotendTemp, DEFAULT_SHARED_PRINT.hotendTemp);
				this.flowTest.bedTemp = toNum(this.sharedPrint.bedTemp, DEFAULT_SHARED_PRINT.bedTemp);
				this.paTuning.hotendTemp = toNum(this.sharedPrint.hotendTemp, DEFAULT_SHARED_PRINT.hotendTemp);
				this.paTuning.bedTemp = toNum(this.sharedPrint.bedTemp, DEFAULT_SHARED_PRINT.bedTemp);

				writeVersionedObject(SHARED_PRINT_STORAGE_KEY, this.sharedPrint);
				writeVersionedObject(SHARED_BED_STORAGE_KEY, this.sharedBed);
				this.setSettingsMessage("Standards gespeichert und sofort auf alle Tests angewendet", "info");
			} catch (error) {
				this.setSettingsMessage(error.message || "Standards konnten nicht gespeichert werden", "error");
			}
		},
		async sendCode(code) {
			return this.$store.dispatch("machine/sendCode", code);
		},
		async uploadJob(path, content) {
			return this.$store.dispatch("machine/upload", {
				filename: path,
				content,
				showProgress: false,
				showSuccess: false,
				showError: true
			});
		},
		async uploadMacro(path, content) {
			return this.uploadJob(path, content);
		},
		normalizeTextForCompare(text) {
			return String(text ?? "")
				.replace(/\r\n/g, "\n")
				.replace(/[ \t]+\n/g, "\n")
				.trimEnd() + "\n";
		},
		async downloadText(path) {
			try {
				const res = await this.$store.dispatch("machine/download", {
					filename: path,
					type: "text",
					showProgress: false,
					showSuccess: false,
					showError: false
				});
				if (res && typeof res === "object" && "content" in res) {
					return String(res.content ?? "");
				}
				return String(res ?? "");
			} catch (_error) {
				return null;
			}
		},
		async uploadIfChanged(path, content) {
			const desired = this.normalizeTextForCompare(content);
			const existing = await this.downloadText(path);
			if (existing !== null) {
				const current = this.normalizeTextForCompare(existing);
				if (current === desired) {
					return { path, written: false };
				}
			}
			if (path === "0:/sys/daemon.g") {
				let lastError = null;
				for (let attempt = 0; attempt < 6; attempt++) {
					try {
						await this.uploadMacro(path, desired);
						return { path, written: true };
					} catch (error) {
						lastError = error;
						const msg = String(error?.message || "").toLowerCase();
						if (!msg.includes("open") || attempt === 5) {
							throw error;
						}
						await new Promise((resolve) => setTimeout(resolve, 500));
					}
				}
				throw lastError || new Error("daemon.g konnte nicht geschrieben werden");
			}
			if (path.startsWith("0:/sys/Daemon/") && path.toLowerCase().endsWith(".g")) {
				return this.uploadIfChangedAtomic(path, desired, existing);
			}
			await this.uploadMacro(path, desired);
			return { path, written: true };
		},
		async uploadIfChangedAtomic(path, desiredNormalized, existingRaw = null) {
			const desired = this.normalizeTextForCompare(desiredNormalized);
			if (existingRaw !== null) {
				const current = this.normalizeTextForCompare(existingRaw);
				if (current === desired) {
					return { path, written: false };
				}
			}

			const tmpPath = `${path}.tmp`;
			try {
				// 1) tmp schreiben
				await this.uploadMacro(tmpPath, desired);
				// 2) tmp verifizieren
				const verifyTmp = await this.downloadText(tmpPath);
				if (verifyTmp === null || this.normalizeTextForCompare(verifyTmp) !== desired) {
					throw new Error(`Atomic verify fehlgeschlagen (tmp): ${tmpPath}`);
				}
				// 3) Ziel schreiben
				await this.uploadMacro(path, desired);
				const verifyFinal = await this.downloadText(path);
				if (verifyFinal === null || this.normalizeTextForCompare(verifyFinal) !== desired) {
					throw new Error(`Atomic verify fehlgeschlagen (final): ${path}`);
				}
				return { path, written: true };
			} finally {
				// tmp Cleanup (best effort)
				try {
					await this.$store.dispatch("machine/delete", tmpPath);
				} catch (_error) {
					// ignore
				}
			}
		},
		sanitizeDaemonCfg(cfg) {
			const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, Number(v)));
			const clampInt = (v, lo, hi) => Math.trunc(clamp(v, lo, hi));
			const heaterIdx = (v) => {
				const n = Math.trunc(Number(v));
				if (!Number.isFinite(n)) return -1;
				return n;
			};
			const clampColor = (c) => ({
				r: clampInt(c?.r ?? 0, 0, 255),
				g: clampInt(c?.g ?? 0, 0, 255),
				b: clampInt(c?.b ?? 0, 0, 255)
			});
			return {
				ledEnabled: Boolean(cfg.ledEnabled),
				moduleLedEnabled: Boolean(cfg.moduleLedEnabled),
				moduleHeaterModelEnabled: Boolean(cfg.moduleHeaterModelEnabled),
				ledStrip: clampInt(cfg.ledStrip, 0, 32),
				ledCount: clampInt(cfg.ledCount, 1, 4096),
				ledBrightness: clampInt(cfg.ledBrightness, 0, 255),
				ledUseFilamentState: Boolean(cfg.ledUseFilamentState),
				ledUseFanState: Boolean(cfg.ledUseFanState),
				ledUseDoneState: Boolean(cfg.ledUseDoneState),
				ledHotendHotTemp: clamp(cfg.ledHotendHotTemp, 0, 400),
				ledBedHotTemp: clamp(cfg.ledBedHotTemp, 0, 200),
				ledHotendHeatDelta: clamp(cfg.ledHotendHeatDelta, 0, 50),
				ledBedHeatDelta: clamp(cfg.ledBedHeatDelta, 0, 50),
				bed1Heater: heaterIdx(cfg.bed1Heater),
				bed2Heater: heaterIdx(cfg.bed2Heater),
				bed3Heater: heaterIdx(cfg.bed3Heater),
				bed4Heater: heaterIdx(cfg.bed4Heater),
				hotend1Heater: heaterIdx(cfg.hotend1Heater),
				hotend2Heater: heaterIdx(cfg.hotend2Heater),
				hotend3Heater: heaterIdx(cfg.hotend3Heater),
				hotend4Heater: heaterIdx(cfg.hotend4Heater),
				idleShutdownEnabled: Boolean(cfg.idleShutdownEnabled),
				idleShutdownSeconds: clampInt(cfg.idleShutdownSeconds, 10, 86400),
				idleShutdownFanEnabled: Boolean(cfg.idleShutdownFanEnabled),
				colorError: clampColor(cfg.colorError),
				blinkError: Boolean(cfg.blinkError),
				colorPaused: clampColor(cfg.colorPaused),
				blinkPaused: Boolean(cfg.blinkPaused),
				colorPrinting: clampColor(cfg.colorPrinting),
				blinkPrinting: Boolean(cfg.blinkPrinting),
				colorHeating: clampColor(cfg.colorHeating),
				blinkHeating: Boolean(cfg.blinkHeating),
				colorDone: clampColor(cfg.colorDone),
				blinkDone: Boolean(cfg.blinkDone),
				colorFan: clampColor(cfg.colorFan),
				blinkFan: Boolean(cfg.blinkFan),
				colorHotendHot: clampColor(cfg.colorHotendHot),
				blinkHotendHot: Boolean(cfg.blinkHotendHot),
				colorBedHot: clampColor(cfg.colorBedHot),
				blinkBedHot: Boolean(cfg.blinkBedHot),
				colorFilament: clampColor(cfg.colorFilament),
				blinkFilament: Boolean(cfg.blinkFilament),
				colorIdle: clampColor(cfg.colorIdle),
				blinkIdle: Boolean(cfg.blinkIdle)
			};
		},
		renderDaemon00Config() {
			const c = this.sanitizeDaemonCfg(this.daemonCfg);
			const b = (v) => (v ? "1" : "0");
			const i = (v) => Math.trunc(Number(v));
			const num = (v) => String(Number(v));
			const lines = [];
			const addBool = (name, value) => {
				lines.push(`if !exists(global.${name})`);
				lines.push(`  global ${name} = ${b(value)}`);
				lines.push("else");
				lines.push(`  set global.${name} = ${b(value)}`);
				lines.push("");
			};
			lines.push("; Persistente Plugin-Konfiguration");
			lines.push("; Diese Datei darf nur vom Plugin geaendert werden");
			lines.push("; Nur if !exists(...) initialisieren, damit Laufzeitwerte im RAM bleiben");
			lines.push("");
			addBool("cfgDaemonLedEnabled", c.moduleLedEnabled);
			addBool("cfgDaemonHeaterModelEnabled", c.moduleHeaterModelEnabled);
			addBool("cfgLedEnabled", c.ledEnabled);
			lines.push("if !exists(global.cfgLedStrip)");
			lines.push(`  global cfgLedStrip = ${i(c.ledStrip)}`);
			lines.push("");
			lines.push("if !exists(global.cfgLedCount)");
			lines.push(`  global cfgLedCount = ${i(c.ledCount)}`);
			lines.push("");
			lines.push("if !exists(global.cfgLedBrightness)");
			lines.push(`  global cfgLedBrightness = ${i(c.ledBrightness)}`);
			lines.push("");
			addBool("cfgLedUseFilamentState", c.ledUseFilamentState);
			addBool("cfgLedUseFanState", c.ledUseFanState);
			addBool("cfgLedUseDoneState", c.ledUseDoneState);
			lines.push("if !exists(global.cfgLedHotendHotTemp)");
			lines.push(`  global cfgLedHotendHotTemp = ${num(c.ledHotendHotTemp)}`);
			lines.push("");
			lines.push("if !exists(global.cfgLedBedHotTemp)");
			lines.push(`  global cfgLedBedHotTemp = ${num(c.ledBedHotTemp)}`);
			lines.push("");
			lines.push("if !exists(global.cfgLedHotendHeatDelta)");
			lines.push(`  global cfgLedHotendHeatDelta = ${num(c.ledHotendHeatDelta)}`);
			lines.push("");
			lines.push("if !exists(global.cfgLedBedHeatDelta)");
			lines.push(`  global cfgLedBedHeatDelta = ${num(c.ledBedHeatDelta)}`);
			lines.push("");
			lines.push("if !exists(global.cfgBed1Heater)");
			lines.push(`  global cfgBed1Heater = ${i(c.bed1Heater)}`);
			lines.push("if !exists(global.cfgBed2Heater)");
			lines.push(`  global cfgBed2Heater = ${i(c.bed2Heater)}`);
			lines.push("if !exists(global.cfgBed3Heater)");
			lines.push(`  global cfgBed3Heater = ${i(c.bed3Heater)}`);
			lines.push("if !exists(global.cfgBed4Heater)");
			lines.push(`  global cfgBed4Heater = ${i(c.bed4Heater)}`);
			lines.push("");
			lines.push("if !exists(global.cfgHotend1Heater)");
			lines.push(`  global cfgHotend1Heater = ${i(c.hotend1Heater)}`);
			lines.push("if !exists(global.cfgHotend2Heater)");
			lines.push(`  global cfgHotend2Heater = ${i(c.hotend2Heater)}`);
			lines.push("if !exists(global.cfgHotend3Heater)");
			lines.push(`  global cfgHotend3Heater = ${i(c.hotend3Heater)}`);
			lines.push("if !exists(global.cfgHotend4Heater)");
			lines.push(`  global cfgHotend4Heater = ${i(c.hotend4Heater)}`);
			lines.push("");
			addBool("cfgIdleShutdownEnabled", c.idleShutdownEnabled);
			lines.push("if !exists(global.cfgIdleShutdownSeconds)");
			lines.push(`  global cfgIdleShutdownSeconds = ${i(c.idleShutdownSeconds)}`);
			lines.push("");
			addBool("cfgIdleShutdownFanEnabled", c.idleShutdownFanEnabled);
			lines.push("; LED-Farben");
			const addColor = (key, col) => {
				lines.push(`if !exists(global.${key}R)`);
				lines.push(`  global ${key}R = ${i(col.r)}`);
				lines.push(`if !exists(global.${key}G)`);
				lines.push(`  global ${key}G = ${i(col.g)}`);
				lines.push(`if !exists(global.${key}B)`);
				lines.push(`  global ${key}B = ${i(col.b)}`);
				lines.push("");
			};
			const addBlink = (key, value) => addBool(key, value);
			addColor("cfgLedColorError", c.colorError);
			addBlink("cfgLedBlinkError", c.blinkError);
			addColor("cfgLedColorPaused", c.colorPaused);
			addBlink("cfgLedBlinkPaused", c.blinkPaused);
			addColor("cfgLedColorPrinting", c.colorPrinting);
			addBlink("cfgLedBlinkPrinting", c.blinkPrinting);
			addColor("cfgLedColorHeating", c.colorHeating);
			addBlink("cfgLedBlinkHeating", c.blinkHeating);
			addColor("cfgLedColorDone", c.colorDone);
			addBlink("cfgLedBlinkDone", c.blinkDone);
			addColor("cfgLedColorFan", c.colorFan);
			addBlink("cfgLedBlinkFan", c.blinkFan);
			addColor("cfgLedColorHotendHot", c.colorHotendHot);
			addBlink("cfgLedBlinkHotendHot", c.blinkHotendHot);
			addColor("cfgLedColorBedHot", c.colorBedHot);
			addBlink("cfgLedBlinkBedHot", c.blinkBedHot);
			addColor("cfgLedColorFilament", c.colorFilament);
			addBlink("cfgLedBlinkFilament", c.blinkFilament);
			addColor("cfgLedColorIdle", c.colorIdle);
			addBlink("cfgLedBlinkIdle", c.blinkIdle);
			return lines.join("\n");
		},
		buildDaemonG() {
			const lines = [];
			lines.push("; daemon.g (single-pass). RRF ruft diese Datei zyklisch selbst auf.");
			lines.push("M98 P\"/sys/Daemon/00_config.g\"");
			lines.push("M98 P\"/sys/Daemon/01_shared_state.g\"");
			lines.push("M98 P\"/sys/Daemon/10_led_logic.g\"");
			lines.push("M98 P\"/sys/Daemon/20_heater_model_logic.g\"");
			lines.push("M98 P\"/sys/Daemon/30_idle_shutdown.g\"");
			lines.push("if fileexists(\"0:/sys/Daemon/99_custom.g\")");
			lines.push("  M98 P\"/sys/Daemon/99_custom.g\"");
			lines.push("");
			return lines.join("\n");
		},
		buildDaemonCustomG() {
			const { safeLines } = this.sanitizeDaemonCustomCommands(this.daemonCustomCommands);
			const lines = ["; Custom commands managed by Kalibrierung plugin"];
			for (const line of safeLines) {
				lines.push(line);
			}
			lines.push("");
			return lines.join("\n");
		},
		validateGeneratedMacro(name, content) {
			const text = String(content || "");
			const errors = [];
			if (!text.trim()) {
				errors.push(`${name}: leerer Inhalt`);
				return errors;
			}
			const lineCount = text.split("\n").length;
			if (lineCount > 4000) {
				errors.push(`${name}: zu viele Zeilen (${lineCount})`);
			}
			if (/Btrue|Bfalse/i.test(text)) {
				errors.push(`${name}: ungültiges M307 B-Format (Btrue/Bfalse)`);
			}
			if (name === "daemon.g" && /\bwhile\s+true\b/i.test(text)) {
				errors.push(`${name}: Endlosschleife nicht erlaubt`);
			}
			let quoteCount = 0;
			for (const ch of text) {
				if (ch === "\"") quoteCount++;
			}
			if (quoteCount % 2 !== 0) {
				errors.push(`${name}: ungerade Anzahl von Anführungszeichen`);
			}
			return errors;
		},
		validateDaemonGeneratedFiles(cfg) {
			const files = [
				{ name: "daemon.g", content: this.buildDaemonG() },
				{ name: "00_config.g", content: this.renderDaemon00Config() },
				{ name: "01_shared_state.g", content: DAEMON_01_SHARED_STATE_G },
				{ name: "10_led_logic.g", content: DAEMON_10_LED_LOGIC_G },
				{ name: "20_heater_model_logic.g", content: DAEMON_20_HEATER_MODEL_LOGIC_G },
				{ name: "30_idle_shutdown.g", content: DAEMON_30_IDLE_SHUTDOWN_G },
				{ name: "99_custom.g", content: this.buildDaemonCustomG() }
			];
			const all = [];
			for (const f of files) {
				all.push(...this.validateGeneratedMacro(f.name, f.content));
			}
			if (!cfg || typeof cfg !== "object") {
				all.push("Daemon-Konfiguration fehlt");
			}
			return all;
		},
		sanitizeDaemonCustomCommands(text) {
			const raw = String(text || "").replace(/\r\n/g, "\n");
			const safeLines = [];
			const blockedLines = [];
			for (const rawLine of raw.split("\n")) {
				const line = rawLine.trimRight();
				const trimmed = line.trim();
				if (!trimmed) {
					continue;
				}
				const normalized = trimmed.toLowerCase();
				const touchesDaemonFile =
					normalized.includes("0:/sys/daemon.g") ||
					normalized.includes("/sys/daemon.g") ||
					normalized.includes("0:/sys/daemon/") ||
					normalized.includes("/sys/daemon/");
				const dangerousDelete =
					/\bm30\b/i.test(trimmed) ||
					normalized.includes("machine/delete") ||
					normalized.includes("remove-item");
				if (touchesDaemonFile && dangerousDelete) {
					blockedLines.push(trimmed);
					continue;
				}
				safeLines.push(trimmed);
			}
			return { safeLines, blockedLines };
		},
		async saveDaemonModule(forceModule = "") {
			try {
				this.setDaemonMessage("Speichere Daemon Modul...", "info");
				let cfg = this.sanitizeDaemonCfg(this.daemonCfg);
				if (forceModule === "led") {
					cfg = { ...cfg, moduleLedEnabled: true };
				}
				const sanitizedCustom = this.sanitizeDaemonCustomCommands(this.daemonCustomCommands);
				const hasCustom = sanitizedCustom.safeLines.length > 0;
				if (sanitizedCustom.blockedLines.length > 0) {
					this.daemonCustomCommands = sanitizedCustom.safeLines.join("\n");
				}
				const validationErrors = this.validateDaemonGeneratedFiles(cfg);
				if (validationErrors.length > 0) {
					throw new Error(`Daemon-Validierung fehlgeschlagen: ${validationErrors.join(" | ")}`);
				}

				// /sys/daemon.g wird nur inhaltlich aktualisiert, nie geloescht.

				await this.ensureDirectory("0:/sys/Daemon");
				const fileWrites = [
					{ path: "0:/sys/daemon.g", content: this.buildDaemonG() },
					{ path: "0:/sys/Daemon/00_config.g", content: this.renderDaemon00Config() },
					{ path: "0:/sys/Daemon/01_shared_state.g", content: DAEMON_01_SHARED_STATE_G },
					{ path: "0:/sys/Daemon/10_led_logic.g", content: DAEMON_10_LED_LOGIC_G },
					{ path: "0:/sys/Daemon/20_heater_model_logic.g", content: DAEMON_20_HEATER_MODEL_LOGIC_G },
					{ path: "0:/sys/Daemon/30_idle_shutdown.g", content: DAEMON_30_IDLE_SHUTDOWN_G },
					{ path: "0:/sys/Daemon/99_custom.g", content: this.buildDaemonCustomG() }
				];

				let wrote = 0;
				let skipped = 0;
				for (const f of fileWrites) {
					const res = await this.uploadIfChanged(f.path, f.content);
					if (res.written) wrote++; else skipped++;
				}
				this.daemonCfg = { ...cfg };
				const blockedLines = sanitizedCustom.blockedLines;
				if (blockedLines.length > 0) {
					this.setDaemonMessage(`Daemon Modul bereit (LED=${cfg.moduleLedEnabled}, PID=${cfg.moduleHeaterModelEnabled}, Idle=${cfg.idleShutdownEnabled}, Custom=${hasCustom}). Geschrieben: ${wrote}, unveraendert: ${skipped}. Geblockte Custom-Zeilen: ${blockedLines.length} (Schutz fuer /sys/daemon.g).`, "success");
				} else {
					this.setDaemonMessage(`Daemon Modul bereit (LED=${cfg.moduleLedEnabled}, PID=${cfg.moduleHeaterModelEnabled}, Idle=${cfg.idleShutdownEnabled}, Custom=${hasCustom}). Geschrieben: ${wrote}, unveraendert: ${skipped}.`, "success");
				}
			} catch (error) {
				this.setDaemonMessage(error.message || "Daemon Modul konnte nicht gespeichert werden", "error");
			}
		},
		registerGeneratedTestFile(path) {
			const raw = String(path || "").trim();
			if (!raw) {
				return;
			}
			// Accept both plain paths and accidentally passed gcode fragments like: M30 P"0:/gcodes/....g"
			let normalized = raw;
			const pMatch = /P\"([^\"]+)\"/i.exec(normalized);
			if (pMatch) {
				normalized = pMatch[1];
			}
			normalized = normalized.replace(/^"+|"+$/g, "");
			if (normalized.toLowerCase().startsWith("0:/gcodes/")) {
				normalized = normalized.substring("0:/gcodes/".length);
			}
			if (!this.generatedTestFiles.includes(normalized)) {
				this.generatedTestFiles.push(normalized);
			}
		},
		async cleanupGeneratedTestFiles() {
			if (this.cleanupInProgress || this.generatedTestFiles.length === 0) {
				return;
			}
			this.cleanupInProgress = true;
			try {
				const pending = [...this.generatedTestFiles];
				const keep = [];
				for (const file of pending) {
					try {
						// machine/delete expects a plain path, not a whole gcode command
						let target = file.toLowerCase().startsWith("0:/") ? file : `0:/gcodes/${file}`;
						const pMatch = /P\"([^\"]+)\"/i.exec(target);
						if (pMatch) {
							target = pMatch[1];
						}
						target = target.replace(/^"+|"+$/g, "");
						await this.$store.dispatch("machine/delete", target);
					} catch (_error) {
						keep.push(file);
					}
				}
				this.generatedTestFiles = keep;
				if (pending.length > 0 && keep.length === 0) {
					this.setInfo("Test-GCodes wurden nach Druckende automatisch geloescht");
				}
			} finally {
				this.cleanupInProgress = false;
			}
		},
		resetDefaults() {
			this.form = cloneDefaults();
			this.bestFlow = DEFAULT_FORM.C;
			this.sharedPrint = { ...DEFAULT_SHARED_PRINT };
			this.sharedBed = { ...DEFAULT_SHARED_BED };
			this.uiTabs = { ...DEFAULT_UI_TABS };
			this.activeMode = "flow";
			this.boxTest = { ...DEFAULT_BOX_TEST };
			this.probeZCal = { ...DEFAULT_Z_CAL };
			this.szpTest = { ...DEFAULT_SZP_TEST };
			this.irRepeatTest = { ...DEFAULT_IR_REPEAT_TEST };
			this.pidSeries = { ...DEFAULT_PID_SERIES };
			this.paTuning = { ...DEFAULT_PA_TUNING };
			this.flowTest = { ...DEFAULT_FLOW_TEST };
			this.flowTestLineWManual = false;
			this.flowTestLineWAutoWrite = false;
			this.flowTestSelectedProbe = 0;
			this.flowTestProbeZOffsetBaseByK = {};
			this.flowTestProbeZOffsetCurrentByK = {};
			this.flowTestLiveBabystepTotal = 0;
			this.flowTestSyncingLive = false;
			this.generatedTestFiles = [];
			this.cleanupInProgress = false;
			this.evaluation = { ...DEFAULT_EVALUATION };
			this.startCode = DEFAULT_START_CODE;
			this.endCode = DEFAULT_END_CODE;
			this.setBoxTestMessage("", "info");
			this.setProbeMessage("", "info");
			this.setPidMessage("", "info");
			this.setPaMessage("", "info");
			this.setLedMessage("", "info");
			this.setFlowTestMessage("", "info");
			this.setSettingsMessage("", "info");
			this.setEvaluationMessage("", "info");
			this.setInfo("Standardwerte wiederhergestellt");
		},
		resolveLineWidth(nozzleDia) {
			const map = {
				0.25: 0.30,
				0.4: 0.48,
				0.5: 0.60,
				0.6: 0.72,
				0.8: 0.96
			};
			const exact = map[Number(nozzleDia)];
			if (exact) {
				return exact;
			}
			return Number(nozzleDia) * 1.2;
		},
		enableAutoLineWidth() {
			this.flowTestLineWManual = false;
			const autoWidth = this.resolveLineWidth(toNum(this.sharedPrint.nozzleDia, DEFAULT_SHARED_PRINT.nozzleDia));
			this.flowTestLineWAutoWrite = true;
			this.sharedPrint.lineW = Number(fmt(autoWidth, 3));
			this.setFlowTestMessage("Extrusionsbreite wieder auf Auto (Duese x 1.2) gesetzt", "info");
		},
		getSelectedProbeIndex() {
			const available = this.probeSelectItems.map(item => Number(item.value));
			const requested = Math.floor(toNum(this.flowTestSelectedProbe, 0));
			if (available.includes(requested)) {
				return requested;
			}
			return available.length > 0 ? available[0] : 0;
		},
		getProbeModelOffset(probeIndex) {
			const probe = this.model?.sensors?.probes?.[probeIndex];
			// G31 Z corresponds to trigger height; prefer this over geometric offsets[2]
			const triggerHeight = Number(probe?.triggerHeight);
			if (Number.isFinite(triggerHeight)) {
				return triggerHeight;
			}
			const legacyOffset = Number(probe?.offsets?.[2]);
			return Number.isFinite(legacyOffset) ? legacyOffset : 0;
		},
		ensureProbeZCache(probeIndex) {
			const currentKnown = Number(this.flowTestProbeZOffsetCurrentByK?.[probeIndex]);
			if (Number.isFinite(currentKnown)) {
				return;
			}
			const modelValue = this.getProbeModelOffset(probeIndex);
			this.flowTestProbeZOffsetBaseByK = {
				...this.flowTestProbeZOffsetBaseByK,
				[probeIndex]: modelValue
			};
			this.flowTestProbeZOffsetCurrentByK = {
				...this.flowTestProbeZOffsetCurrentByK,
				[probeIndex]: modelValue
			};
		},
		getProbeLiveDelta(probeIndex) {
			const base = Number(this.flowTestProbeZOffsetBaseByK?.[probeIndex]);
			const current = Number(this.flowTestProbeZOffsetCurrentByK?.[probeIndex]);
			if (!Number.isFinite(base) || !Number.isFinite(current)) {
				return 0;
			}
			return current - base;
		},
		getMachineZBabystep() {
			const axes = Array.isArray(this.model?.move?.axes) ? this.model.move.axes : [];
			const zAxis = axes.find(axis => String(axis?.letter || "").toUpperCase() === "Z");
			const value = Number(zAxis?.babystep);
			if (Number.isFinite(value)) {
				return value;
			}
			return toNum(this.flowTestLiveBabystepTotal, 0);
		},
		async syncLiveBabystepToSelectedProbe() {
			// Keep plugin state aligned with current machine babystep, but do not modify live Z automatically.
			this.flowTestLiveBabystepTotal = this.getMachineZBabystep();
		},
		async adjustProbeZOffset(delta) {
			try {
				const value = toNum(delta, 0);
				if (Math.abs(value) < 0.0001) {
					return;
				}
				const probeIndex = this.getSelectedProbeIndex();
				this.ensureProbeZCache(probeIndex);
				await this.sendCode(`M290 R1 Z${fmt(value, 3)}`);
				this.flowTestLiveBabystepTotal = this.getMachineZBabystep();
				this.setFlowTestMessage(`Probe K${probeIndex} live angepasst: ${value >= 0 ? "+" : ""}${fmt(value, 3)} mm (M290)`, "info");
			} catch (error) {
				this.setFlowTestMessage(error.message || "Probe Z-Offset konnte nicht geaendert werden", "error");
			}
		},
		async resetProbeZOffset() {
			try {
				const probeIndex = this.getSelectedProbeIndex();
				this.ensureProbeZCache(probeIndex);
				const base = Number(this.flowTestProbeZOffsetBaseByK?.[probeIndex]) || 0;
				this.flowTestProbeZOffsetCurrentByK = {
					...this.flowTestProbeZOffsetCurrentByK,
					[probeIndex]: base
				};
				await this.syncLiveBabystepToSelectedProbe();
				this.setFlowTestMessage(`Probe K${probeIndex} Z-Offset auf geladenen Wert ${fmt(base, 3)} gesetzt`, "info");
			} catch (error) {
				this.setFlowTestMessage(error.message || "Reset des Probe Z-Offsets fehlgeschlagen", "error");
			}
		},
		async adoptMachineBabystepToSelectedProbe() {
			try {
				const probeIndex = this.getSelectedProbeIndex();
				this.ensureProbeZCache(probeIndex);
				const combined = this.currentProbeZOffsetValue;
				const current = Number(this.flowTestProbeZOffsetCurrentByK?.[probeIndex]) || 0;
				const delta = combined - current;
				if (Math.abs(delta) <= 0.0001) {
					this.setFlowTestMessage("Kein externer DWC-Babystep zum Uebernehmen gefunden", "info");
					return;
				}
				this.flowTestProbeZOffsetCurrentByK = {
					...this.flowTestProbeZOffsetCurrentByK,
					[probeIndex]: combined
				};
				const liveTotal = this.getMachineZBabystep();
				if (Math.abs(liveTotal) > 0.0001) {
					await this.sendCode(`M290 R1 Z${fmt(-liveTotal, 3)}`);
				}
				this.flowTestLiveBabystepTotal = 0;
				this.setFlowTestMessage(`DWC-Babystep fuer K${probeIndex} uebernommen: ${delta >= 0 ? "+" : ""}${fmt(delta, 3)} mm`, "info");
			} catch (error) {
				this.setFlowTestMessage(error.message || "DWC-Babystep konnte nicht uebernommen werden", "error");
			}
		},
		async saveProbeOffsets() {
			try {
				// Ensure we have current values for all discovered probes
				for (const item of this.probeSelectItems) {
					const probeIndex = Number(item.value);
					this.ensureProbeZCache(probeIndex);
				}

				const selectedProbeIndex = this.getSelectedProbeIndex();
				this.ensureProbeZCache(selectedProbeIndex);
				// Persist exactly what is displayed (offset + current live babystep)
				this.flowTestProbeZOffsetCurrentByK = {
					...this.flowTestProbeZOffsetCurrentByK,
					[selectedProbeIndex]: this.currentProbeZOffsetValue
				};
				this.flowTestLiveBabystepTotal = this.getMachineZBabystep();

				// Persist current per-probe target offsets into G31 first
				for (const key of Object.keys(this.flowTestProbeZOffsetCurrentByK || {})) {
					const probeIndex = Number(key);
					const value = Number(this.flowTestProbeZOffsetCurrentByK[key]);
					if (Number.isFinite(probeIndex) && Number.isFinite(value)) {
						await this.sendCode(`G31 K${probeIndex} Z${fmt(value, 3)}`);
					}
				}
				await this.sendCode("M500 P31");

				// Remove temporary live babystepping so G31 is the single source of truth
				const liveTotal = this.getMachineZBabystep();
				if (Math.abs(liveTotal) > 0.0001) {
					await this.sendCode(`M290 R1 Z${fmt(-liveTotal, 3)}`);
				}

				this.flowTestLiveBabystepTotal = 0;
				this.flowTestProbeZOffsetBaseByK = { ...this.flowTestProbeZOffsetCurrentByK };
				this.setFlowTestMessage("Probe-Offsets gespeichert (G31 + M500 P31), Live-Babystep ausgeglichen", "info");
			} catch (error) {
				this.setFlowTestMessage(error.message || "Probe-Offsets konnten nicht gespeichert werden", "error");
			}
		},
		calculateNewFlow() {
			const measured = toNum(this.evaluation.measured, 0);
			const target = toNum(this.evaluation.target, 0);
			const currentFlow = toNum(this.evaluation.currentFlow, 0);
			if (measured <= 0) {
				throw new Error("Gemessene Wandstaerke muss groesser als 0 sein");
			}
			if (target <= 0) {
				throw new Error("Zielwandstaerke muss groesser als 0 sein");
			}
			if (currentFlow <= 0) {
				throw new Error("Aktueller Flow muss groesser als 0 sein");
			}
			return currentFlow * (target / measured);
		},
		calculateFlowOnly() {
			try {
				const newFlow = this.calculateNewFlow();
				this.setEvaluationMessage(`Berechneter Flow: ${fmt(newFlow, 3)} %`, "info");
				return newFlow;
			} catch (error) {
				this.setEvaluationMessage(error.message || "Berechnung fehlgeschlagen", "error");
				throw error;
			}
		},
		async runFlowEvaluation() {
			try {
				const newFlow = this.calculateFlowOnly();
				const measured = fmt(this.evaluation.measured, 3);
				const target = fmt(this.evaluation.target, 3);
				const newFlowValue = fmt(newFlow, 3);
				const commands = [
					`M118 P0 S"FlowTest measured=${measured}"`,
					`M118 P0 S"FlowTest target=${target}"`,
					`M118 P0 S"FlowTest newFlow=${newFlowValue}"`,
					`M221 S${newFlowValue}`,
					`M291 P"Neuer Flow ${newFlowValue} %" R"Flow-Test + Auswertung" S1 T10`
				].join("\n");
				await this.sendCode(commands);
				this.setEvaluationMessage(`Flowwert ${newFlowValue} % gesetzt`, "info");
			} catch (error) {
				if (this.evaluationMessageType !== "error") {
					this.setEvaluationMessage(error.message || "Flow setzen fehlgeschlagen", "error");
				}
			}
		},
		sanitizeMacroPath(path, fallbackName) {
			const trimmed = String(path || "").trim();
			if (trimmed) {
				return trimmed;
			}
			return `0:/macros/Kalibrieren/${fallbackName}`;
		},
		buildIrMiniZCalibrationMacro() {
			const safeLift = toNum(this.probeZCal.safeLift, DEFAULT_Z_CAL.safeLift);
			return [
				"; Z calibration with IR mini sensor",
				"",
				"M291 P\"Starting z calibration\" R\"Z calibration\" S0 T2",
				"M291 P\"Homing all axis\" R\"Z calibration\" S0 T10",
				"G28",
				"M291 P\"Put a paper under the hotend and jog until it touches the paper. Hit OK when finished\" R\"Z calibration\" Z1 T0 S3",
				"M291 P\"Setting this position as z=0\" R\"Z calibration\" S0 T2",
				"G92 Z0",
				`M291 P\"Moving Z up ${fmt(safeLift, 2)}mm\" R\"Z calibration\" S3 T0`,
				`G1 Z${fmt(safeLift, 3)} F3000`,
				"M291 P\"Probing Z position\" R\"Z calibration\" S3 T0",
				"G30 S-1",
				"M291 P\"Go to console and copy the z value to config.g\" R\"Z calibration\" S0 T5",
				"M291 P\"Write down the z position\" R\"Z calibration\" S1 T0",
				""
			].join("\n");
		},
		buildSzpRepeatabilityMacro() {
			const x = toNum(this.szpTest.X, DEFAULT_SZP_TEST.X);
			const y = toNum(this.szpTest.Y, DEFAULT_SZP_TEST.Y);
			const n = Math.max(1, Math.floor(toNum(this.szpTest.N, DEFAULT_SZP_TEST.N)));
			const safeZ = toNum(this.szpTest.Z, DEFAULT_SZP_TEST.Z);
			return [
				"; szp_repeatability_test.g",
				"; Generated by Kalibrierung plugin",
				"",
				`var x = ${fmt(x, 3)}`,
				`var y = ${fmt(y, 3)}`,
				`var n = ${n}`,
				`var safeZ = ${fmt(safeZ, 3)}`,
				"",
				"G90",
				"M561",
				"G29 S2",
				"G28",
				"G1 X{var.x} Y{var.y} Z{var.safeZ} F12000",
				"",
				"M118 P0 S\"Kalibriere SZP...\"",
				"M558.1 K1 S1.5",
				"",
				"var i = 0",
				"var sum = 0.0",
				"var minVal = 9999.0",
				"var maxVal = -9999.0",
				"",
				"echo >\"0:/sys/szp_repeatability_last.csv\" \"index,z\"",
				"",
				"while var.i < var.n",
				"  G1 X{var.x} Y{var.y} Z{var.safeZ} F12000",
				"  G30 S-1 K1",
				"",
				"  var zNow = move.axes[2].machinePosition",
				"",
				"  set var.sum = var.sum + var.zNow",
				"  if var.zNow < var.minVal",
				"    set var.minVal = var.zNow",
				"  if var.zNow > var.maxVal",
				"    set var.maxVal = var.zNow",
				"",
				"  echo >>\"0:/sys/szp_repeatability_last.csv\" {var.i ^ \",\" ^ var.zNow}",
				"  M118 P0 S{\"Messung \" ^ (var.i + 1) ^ \"/\" ^ var.n ^ \": Z=\" ^ var.zNow}",
				"",
				"  set var.i = var.i + 1",
				"",
				"var mean = var.sum / var.n",
				"var span = var.maxVal - var.minVal",
				"",
				"M118 P0 S{\"--- Ergebnis SZP ---\"}",
				"M118 P0 S{\"Mittel: \" ^ var.mean}",
				"M118 P0 S{\"Min: \" ^ var.minVal}",
				"M118 P0 S{\"Max: \" ^ var.maxVal}",
				"M118 P0 S{\"Spannweite: \" ^ var.span ^ \" mm\"}",
				""
			].join("\n");
		},
		buildIrRepeatabilityMacro() {
			const x = toNum(this.irRepeatTest.X, DEFAULT_IR_REPEAT_TEST.X);
			const y = toNum(this.irRepeatTest.Y, DEFAULT_IR_REPEAT_TEST.Y);
			const zsafe = toNum(this.irRepeatTest.Zsafe, DEFAULT_IR_REPEAT_TEST.Zsafe);
			const n = Math.max(2, Math.floor(toNum(this.irRepeatTest.N, DEFAULT_IR_REPEAT_TEST.N)));
			const travelOffset = Math.max(5, toNum(this.irRepeatTest.travelOffset, DEFAULT_IR_REPEAT_TEST.travelOffset));
			return [
				"; Probe_Repeatability.g",
				"; Generated by Kalibrierung plugin",
				"",
				`var X = ${fmt(x, 3)}`,
				`var Y = ${fmt(y, 3)}`,
				`var Zsafe = ${fmt(zsafe, 3)}`,
				`var N = ${n}`,
				`var TravelOffset = ${fmt(travelOffset, 3)}`,
				"",
				"G90",
				"M400",
				"G1 Z{var.Zsafe} F6000",
				"",
				"var i = 0",
				"while var.i < var.N-1",
				"  G1 Z{var.Zsafe} F6000",
				"  G1 X{var.X} Y{var.Y} F9000",
				"  G30 P{var.i} X{var.X} Y{var.Y} Z-99999 F5000",
				"",
				"  G1 Z{var.Zsafe} F6000",
				"  G1 X{var.X-var.TravelOffset} Y{var.Y} F9000",
				"  G1 X{var.X} Y{var.Y-var.TravelOffset} F9000",
				"  G1 X{var.X+var.TravelOffset} Y{var.Y} F9000",
				"  G1 X{var.X} Y{var.Y+var.TravelOffset} F9000",
				"",
				"  set var.i = var.i + 1",
				"",
				"G1 Z{var.Zsafe} F6000",
				"G1 X{var.X} Y{var.Y} F9000",
				"G30 P{var.N-1} X{var.X} Y{var.Y} Z-99999 F5000 S-1",
				""
			].join("\n");
		},
		async runGeneratedMacro(tempFileName, content) {
			const path = `0:/macros/Kalibrieren/${tempFileName}`;
			await this.uploadMacro(path, content);
			await this.sendCode(`M98 P"${path}"`);
		},
		async runZCalibrationMacro() {
			try {
				const content = this.buildIrMiniZCalibrationMacro();
				await this.runGeneratedMacro("_tmp_z_calibration_ir_mini.g", content);
				this.setProbeMessage("IR Mini Z Calibration gestartet", "info");
			} catch (error) {
				this.setProbeMessage(error.message || "Z Calibration konnte nicht gestartet werden", "error");
			}
		},
		async saveZCalibrationMacro() {
			try {
				const content = this.buildIrMiniZCalibrationMacro();
				const path = this.sanitizeMacroPath(this.probeZCal.savePath, "z_calibration_ir_mini.g");
				await this.uploadMacro(path, content);
				this.setProbeMessage(`Macro gespeichert: ${path}`, "info");
			} catch (error) {
				this.setProbeMessage(error.message || "Macro konnte nicht gespeichert werden", "error");
			}
		},
		async runSzpRepeatabilityMacro() {
			try {
				const content = this.buildSzpRepeatabilityMacro();
				await this.runGeneratedMacro("_tmp_szp_repeatability_test.g", content);
				this.setProbeMessage("SZP Repeatability Test gestartet", "info");
			} catch (error) {
				this.setProbeMessage(error.message || "SZP Test konnte nicht gestartet werden", "error");
			}
		},
		async saveSzpRepeatabilityMacro() {
			try {
				const content = this.buildSzpRepeatabilityMacro();
				const path = this.sanitizeMacroPath(this.szpTest.savePath, "szp_repeatability_test.g");
				await this.uploadMacro(path, content);
				this.setProbeMessage(`Macro gespeichert: ${path}`, "info");
			} catch (error) {
				this.setProbeMessage(error.message || "Macro konnte nicht gespeichert werden", "error");
			}
		},
		async runIrRepeatabilityMacro() {
			try {
				const content = this.buildIrRepeatabilityMacro();
				await this.runGeneratedMacro("_tmp_ir_probe_repeatability.g", content);
				this.setProbeMessage("IR Probe Repeatability Test gestartet", "info");
			} catch (error) {
				this.setProbeMessage(error.message || "IR Probe Test konnte nicht gestartet werden", "error");
			}
		},
		async saveIrRepeatabilityMacro() {
			try {
				const content = this.buildIrRepeatabilityMacro();
				const path = this.sanitizeMacroPath(this.irRepeatTest.savePath, "probe_repeatability.g");
				await this.uploadMacro(path, content);
				this.setProbeMessage(`Macro gespeichert: ${path}`, "info");
			} catch (error) {
				this.setProbeMessage(error.message || "Macro konnte nicht gespeichert werden", "error");
			}
		},
		buildStartCommand(hotendTemp, bedTemp, minX, minY, maxX, maxY) {
			const code = String(this.startCode || "").trim();
			if (!code) {
				throw new Error("Startcode ist leer");
			}
			return this.applyTemplatePlaceholders(code, {
				hotendTemp: fmt(hotendTemp, 2),
				bedTemp: fmt(bedTemp, 2),
				minX: fmt(minX, 3),
				minY: fmt(minY, 3),
				maxX: fmt(maxX, 3),
				maxY: fmt(maxY, 3),
				extruder0_temperature: fmt(hotendTemp, 2),
				bed0_temperature: fmt(bedTemp, 2),
				build_min_x: fmt(minX, 3),
				build_min_y: fmt(minY, 3),
				build_max_x: fmt(maxX, 3),
				build_max_y: fmt(maxY, 3)
			});
		},
		applyTemplatePlaceholders(template, values) {
			let out = String(template || "");
			for (const [key, value] of Object.entries(values || {})) {
				const safe = String(value ?? "");
				out = out.replace(new RegExp(`\\{${key}\\}`, "g"), safe);
				out = out.replace(new RegExp(`\\[${key}\\]`, "g"), safe);
			}
			return out;
		},
		addDefaultEndSequence(lines, values = {}) {
			const code = String(this.endCode || "").trim();
			if (!code) {
				throw new Error("Endcode ist leer");
			}
			const rendered = this.applyTemplatePlaceholders(code, values);
			const endLines = rendered.split(/\r?\n/).map(item => item.trim()).filter(item => item.length > 0);
			lines.push(...endLines);
		},
		getToolHeaterSet() {
			const set = new Set();
			const tools = Array.isArray(this.model?.tools) ? this.model.tools : [];
			for (const tool of tools) {
				const heaters = Array.isArray(tool?.heaters) ? tool.heaters : [];
				for (const heater of heaters) {
					const idx = Math.floor(Number(heater));
					if (Number.isFinite(idx) && idx >= 0) {
						set.add(idx);
					}
				}
			}
			return set;
		},
		classifyHeaterKind(heaterIndex, options = {}) {
			if (!options.ignoreOverride) {
				const map = this.pidSeries?.heaterKindOverrides || {};
				const override = String(map?.[heaterIndex] || "").toLowerCase();
				if (override === "bed" || override === "hotend" || override === "chamber") {
					return override;
				}
			}
			const toolHeaters = this.getToolHeaterSet();
			if (toolHeaters.has(heaterIndex)) {
				return "hotend";
			}
			const name = String(this.model?.heat?.heaters?.[heaterIndex]?.name || "").toLowerCase();
			if (name.includes("bed")) return "bed";
			if (name.includes("chamber") || name.includes("kammer") || name.includes("enclosure")) return "chamber";
			if (name.includes("hotend") || name.includes("nozzle") || name.includes("extruder")) return "hotend";
			if (heaterIndex === 0) return "bed";
			return "hotend";
		},
		getHeaterGroupsByKind() {
			const heaters = Array.isArray(this.model?.heat?.heaters) ? this.model.heat.heaters : [];
			const groups = { bed: [], hotend: [], chamber: [] };
			for (let i = 0; i < heaters.length; i++) {
				if (heaters[i] === null || heaters[i] === undefined) {
					continue;
				}
				const kind = this.classifyHeaterKind(i);
				groups[kind].push(i);
			}
			groups.bed.sort((a, b) => a - b);
			groups.hotend.sort((a, b) => a - b);
			groups.chamber.sort((a, b) => a - b);
			return groups;
		},
		getPidTargetInfo(heaterIndex) {
			const kind = this.classifyHeaterKind(heaterIndex);
			const groups = this.getHeaterGroupsByKind();
			const list = groups[kind];
			const zoneIndex = Math.max(1, (list.indexOf(heaterIndex) + 1) || 1);
			if (kind === "bed") {
				return {
					kind,
					zoneIndex,
					label: `Heatbed ${zoneIndex}`,
					baseDir: `0:/sys/Temp_bed/Bed_${zoneIndex}`,
					filePrefix: "bedmodel"
				};
			}
			if (kind === "chamber") {
				return {
					kind,
					zoneIndex,
					label: `Chamber ${zoneIndex}`,
					baseDir: `0:/sys/Temp_chamber/Chamber_${zoneIndex}`,
					filePrefix: "chambermodel"
				};
			}
			return {
				kind: "hotend",
				zoneIndex,
				label: `Hotend ${zoneIndex}`,
				baseDir: `0:/sys/Temp_hotend/Hotend_${zoneIndex}`,
				filePrefix: "hotendmodel"
			};
		},
		async ensureDirectory(path) {
			try {
				await this.$store.dispatch("machine/makeDirectory", path);
			} catch (_error) {
				// ignore if existing
			}
		},
		async ensurePidTargetDirectories(baseDir) {
			const parts = String(baseDir || "").split("/");
			if (parts.length >= 4) {
				await this.ensureDirectory(parts.slice(0, 4).join("/"));
			}
			await this.ensureDirectory(baseDir);
		},
		buildPidSeriesMacro() {
			const heater = Math.floor(toNum(this.pidSeries.H, DEFAULT_PID_SERIES.H));
			const info = this.getPidTargetInfo(heater);
			const useCsv = Boolean(this.pidSeries.useCsv);
			const csvFile = String(this.pidSeries.F || DEFAULT_PID_SERIES.F).trim() || DEFAULT_PID_SERIES.F;
			const fanPct = Math.max(0, Math.min(100, toNum(this.pidSeries.fanPct, DEFAULT_PID_SERIES.fanPct)));
			const tStart = toNum(this.pidSeries.A, DEFAULT_PID_SERIES.A);
			const tEnd = toNum(this.pidSeries.E, DEFAULT_PID_SERIES.E);
			const tStep = toNum(this.pidSeries.I, DEFAULT_PID_SERIES.I);
			const cool = toNum(this.pidSeries.C, DEFAULT_PID_SERIES.C);
			const fanIds = Array.from(new Set(
				(Array.isArray(this.pidSeries.fans) ? this.pidSeries.fans : [])
					.map(item => Math.floor(toNum(item, -1)))
					.filter(item => item >= 0)
			)).sort((a, b) => a - b);
			const fanS = fanPct / 100;
			const fanOnLines = fanIds.map(id => `  M106 P${id} S{var.fanS}`);
			const fanOffLines = fanIds.map(id => `  M106 P${id} S0`);

			if (tStep <= 0) throw new Error("Schrittweite I muss > 0 sein");
			if (tEnd < tStart) throw new Error("Endtemperatur E muss >= A sein");
			if (cool < 0) throw new Error("Cooldown C muss >= 0 sein");

			if (useCsv) {
				return [
					"; /sys/pid_series_to_csv.g",
					"; Generated by Kalibrierung plugin",
					"",
					`var heater = ${heater}`,
					`var tStart = ${fmt(tStart, 3)}`,
					`var tEnd = ${fmt(tEnd, 3)}`,
					`var tStep = ${fmt(tStep, 3)}`,
					`var cool = ${fmt(cool, 3)}`,
					`var fanS = ${fmt(fanS, 4)}`,
					`var file = "${csvFile}"`,
					"",
					"echo >{var.file} \"heater,temp,R,K1,K2,D,E,S,V,B,status\"",
					"",
					"var t = var.tStart",
					"while {var.t <= var.tEnd}",
					"  while {heat.heaters[var.heater].state = \"tuning\"}",
					"    G4 S5",
					...fanOnLines,
					"  M303 H{var.heater} S{var.t}",
					"  while {heat.heaters[var.heater].state = \"tuning\"}",
					"    G4 S5",
					"  M118 P0 S{\"PID step done: heater=\" ^ var.heater ^ \" temp=\" ^ var.t ^ \" state=\" ^ heat.heaters[var.heater].state}",
					"  if {heat.heaters[var.heater].state = \"fault\"}",
					"    echo >>{var.file} {var.heater ^ \",\" ^ var.t ^ \",,,,,,,,,fault\"}",
					"    M118 P0 S{\"PID fault: heater=\" ^ var.heater ^ \" temp=\" ^ var.t}",
					...fanOffLines,
					"    abort {\"PID tuning fault bei Heater \" ^ var.heater ^ \" / \" ^ var.t ^ \"C\"}",
					"  var R = heat.heaters[var.heater].model.heatingRate",
					"  var K1 = heat.heaters[var.heater].model.coolingRate",
					"  var K2 = heat.heaters[var.heater].model.fanCoolingRate",
					"  var D = heat.heaters[var.heater].model.deadTime",
					"  var E = heat.heaters[var.heater].model.coolingExp",
					"  var S = heat.heaters[var.heater].model.maxPwm",
					"  var V = heat.heaters[var.heater].model.standardVoltage",
					"  var Btxt = \"1\"",
					"  if heat.heaters[var.heater].model.pid.used",
					"    set var.Btxt = \"0\"",
					"  echo >>{var.file} {var.heater ^ \",\" ^ var.t ^ \",\" ^ var.R ^ \",\" ^ var.K1 ^ \",\" ^ var.K2 ^ \",\" ^ var.D ^ \",\" ^ var.E ^ \",\" ^ var.S ^ \",\" ^ var.V ^ \",\" ^ var.Btxt ^ \",finished\"}",
					"  M400",
					"  var hasNext = (var.t + var.tStep) <= var.tEnd",
					"  if {var.heater = 0}",
					"    M140 S-273.15",
					"  else",
					"    M144 H{var.heater}",
					...fanOffLines,
					"  if {var.hasNext}",
					"    while {heat.heaters[var.heater].current > var.cool}",
					"      G4 S10",
					"  set var.t = var.t + var.tStep",
					"",
					...fanOffLines.map(line => line.trim()),
					"M291 P{\"PID-Serie fertig. CSV: \" ^ var.file} R\"PID-Serie\" S1 T8",
					""
				].join("\n");
			}

			return [
				"; /sys/pid_series_to_models.g",
				"; Generated by Kalibrierung plugin",
				"",
				`var heater = ${heater}`,
				`var tStart = ${fmt(tStart, 3)}`,
				`var tEnd = ${fmt(tEnd, 3)}`,
				`var tStep = ${fmt(tStep, 3)}`,
				`var cool = ${fmt(cool, 3)}`,
				`var fanS = ${fmt(fanS, 4)}`,
				`var baseDir = "${info.baseDir}"`,
				`var prefix = "${info.filePrefix}"`,
				"",
				"if {var.tStep <= 0}",
				"  abort \"Schrittweite muss > 0 sein\"",
				"if {var.tEnd < var.tStart}",
				"  abort \"Endtemperatur muss >= Anfangstemperatur sein\"",
				"if {var.cool < 0}",
				"  abort \"Cooldown-Temperatur muss >= 0 sein\"",
				"",
				"var t = var.tStart",
				"while {var.t <= var.tEnd}",
				"",
				"  while {heat.heaters[var.heater].state = \"tuning\"}",
				"    G4 S5",
				"",
				...fanOnLines,
				"",
				"  M291 P{\"Starte Heater-Tuning H\" ^ var.heater ^ \" bei \" ^ var.t ^ \"C\"} R\"PID-Serie\" S0 T3",
				"  M303 H{var.heater} S{var.t}",
				"",
				"  while {heat.heaters[var.heater].state = \"tuning\"}",
				"    G4 S5",
				"",
				"  M118 P0 S{\"PID step done: heater=\" ^ var.heater ^ \" temp=\" ^ var.t ^ \" state=\" ^ heat.heaters[var.heater].state}",
				"  if {heat.heaters[var.heater].state = \"fault\"}",
				"    M118 P0 S{\"PID fault: heater=\" ^ var.heater ^ \" temp=\" ^ var.t}",
				...fanOffLines,
				"    abort {\"PID tuning fault bei Heater \" ^ var.heater ^ \" / \" ^ var.t ^ \"C\"}",
				"",
				"  var R = heat.heaters[var.heater].model.heatingRate",
				"  var K1 = heat.heaters[var.heater].model.coolingRate",
				"  var K2 = heat.heaters[var.heater].model.fanCoolingRate",
				"  var D = heat.heaters[var.heater].model.deadTime",
				"  var E = heat.heaters[var.heater].model.coolingExp",
				"  var S = heat.heaters[var.heater].model.maxPwm",
				"  var V = heat.heaters[var.heater].model.standardVoltage",
				"  var Btxt = \"1\"",
				"  if heat.heaters[var.heater].model.pid.used",
				"    set var.Btxt = \"0\"",
				"  var tRounded = round(var.t)",
				"  var filePath = var.baseDir ^ \"/\" ^ var.prefix ^ \"_\" ^ var.tRounded ^ \".g\"",
				"  echo >{var.filePath} {\"M307 H\" ^ var.heater ^ \" R\" ^ var.R ^ \" K\" ^ var.K1 ^ \":\" ^ var.K2 ^ \" D\" ^ var.D ^ \" E\" ^ var.E ^ \" S\" ^ var.S ^ \" B\" ^ var.Btxt ^ \" V\" ^ var.V}",
				"  M400",
				"  M118 P0 S{\"Model gespeichert: \" ^ var.filePath}",
				"",
				"  var hasNext = (var.t + var.tStep) <= var.tEnd",
				"  if {var.heater = 0}",
				"    M140 S-273.15",
				"  else",
				"    M144 H{var.heater}",
				...fanOffLines,
				"",
				"  if {var.hasNext}",
				"    while {heat.heaters[var.heater].current > var.cool}",
				"      G4 S10",
				"",
				"  set var.t = var.t + var.tStep",
				"",
				...fanOffLines.map(line => line.trim()),
				"M291 P{\"PID-Serie fertig. Modelle in: \" ^ var.baseDir} R\"PID-Serie\" S1 T8",
				""
			].join("\n");
		},
		// Daemon Modul wird ueber saveDaemonModule() im Reiter Einstellungen installiert/aktualisiert.
		async runPidSeriesMacro() {
			try {
				const heater = Math.floor(toNum(this.pidSeries.H, DEFAULT_PID_SERIES.H));
				const info = this.getPidTargetInfo(heater);
				if (!this.pidSeries.useCsv) {
					await this.ensurePidTargetDirectories(info.baseDir);
				}
				const content = this.buildPidSeriesMacro();
				const pidValidation = this.validateGeneratedMacro("pid_series_macro", content);
				if (pidValidation.length > 0) {
					throw new Error(`PID-Makro ungültig: ${pidValidation.join(" | ")}`);
				}
				const tempName = this.pidSeries.useCsv ? "_tmp_pid_series_to_csv.g" : "_tmp_pid_series_to_models.g";
				await this.runGeneratedMacro(tempName, content);
				const modeText = this.pidSeries.useCsv ? "CSV" : "Model-Dateien";
				this.setPidMessage(`PID-Serie gestartet (${info.label}, Modus: ${modeText})`, "info");
			} catch (error) {
				this.setPidMessage(error.message || "PID-Serie konnte nicht gestartet werden", "error");
			}
		},
		getDaemonColorHex(colorKey) {
			const col = this.daemonCfg?.[colorKey] || { r: 0, g: 0, b: 0 };
			const clamp = (n) => Math.max(0, Math.min(255, Math.floor(toNum(n, 0))));
			const toHex = (n) => clamp(n).toString(16).padStart(2, "0");
			return `#${toHex(col.r)}${toHex(col.g)}${toHex(col.b)}`;
		},
		onDaemonActionColorInput(colorKey, value) {
			const input = typeof value === "string" ? value : String(value?.target?.value || "");
			const match = /^#?([0-9a-fA-F]{6})$/.exec(input.trim());
			if (!match) {
				return;
			}
			const raw = match[1];
			this.daemonCfg = {
				...this.daemonCfg,
				[colorKey]: {
					r: parseInt(raw.substring(0, 2), 16),
					g: parseInt(raw.substring(2, 4), 16),
					b: parseInt(raw.substring(4, 6), 16)
				}
			};
		},
		getDaemonBlink(blinkKey) {
			return Boolean(this.daemonCfg?.[blinkKey]);
		},
		setDaemonBlink(blinkKey, value) {
			this.daemonCfg = {
				...this.daemonCfg,
				[blinkKey]: Boolean(value)
			};
		},
		copyLiveColorToAction(colorKey) {
			this.daemonCfg = {
				...this.daemonCfg,
				[colorKey]: {
					r: Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.r, 0)))),
					g: Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.g, 0)))),
					b: Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.b, 0))))
				}
			};
		},
		onLedColorChanged(value) {
			const hex = String(value || "").trim();
			const match = /^#?([0-9a-fA-F]{6})/.exec(hex);
			if (!match) {
				return;
			}
			const raw = match[1];
			this.ledControl.r = parseInt(raw.substring(0, 2), 16);
			this.ledControl.g = parseInt(raw.substring(2, 4), 16);
			this.ledControl.b = parseInt(raw.substring(4, 6), 16);
		},
		syncLedHexFromRgb() {
			const r = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.r, 0))));
			const g = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.g, 0))));
			const b = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.b, 0))));
			this.ledControl.r = r;
			this.ledControl.g = g;
			this.ledControl.b = b;
			const toHex = (n) => n.toString(16).padStart(2, "0");
			this.ledControl.color = `#${toHex(r)}${toHex(g)}${toHex(b)}`;
		},
		setLedPreset(name) {
			const presets = {
				warm: { r: 255, g: 180, b: 80, w: 100 },
				white: { r: 255, g: 255, b: 255, w: 40 },
				red: { r: 255, g: 0, b: 0, w: 0 },
				green: { r: 0, g: 255, b: 0, w: 0 },
				blue: { r: 0, g: 0, b: 255, w: 0 }
			};
			const p = presets[name] || presets.white;
			this.ledControl.r = p.r;
			this.ledControl.g = p.g;
			this.ledControl.b = p.b;
			this.ledControl.w = p.w;
			this.syncLedHexFromRgb();
		},
		async applyLedColor() {
			try {
				const strip = Math.max(0, Math.floor(toNum(this.ledControl.strip, 0)));
				const count = Math.max(1, Math.floor(toNum(this.ledControl.count, 1)));
				const r = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.r, 0))));
				const g = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.g, 0))));
				const b = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.b, 0))));
				const w = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.w, 0))));
				const p = Math.max(0, Math.min(255, Math.floor(toNum(this.ledControl.brightness, 255))));
				const whitePart = w > 0 ? ` W${w}` : "";
				await this.sendCode(`M150 E${strip} S${count} R${r} U${g} B${b}${whitePart} P${p}`);
				this.setLedMessage(`LED gesetzt: Strip E${strip}, ${count} LEDs`, "info");
			} catch (error) {
				this.setLedMessage(error.message || "LED konnte nicht gesetzt werden", "error");
			}
		},
		async turnOffLeds() {
			try {
				const strip = Math.max(0, Math.floor(toNum(this.ledControl.strip, 0)));
				const count = Math.max(1, Math.floor(toNum(this.ledControl.count, 1)));
				await this.sendCode(`M150 E${strip} S${count} R0 U0 B0 W0 P0`);
				this.setLedMessage(`LED aus: Strip E${strip}`, "info");
			} catch (error) {
				this.setLedMessage(error.message || "LED Aus fehlgeschlagen", "error");
			}
		},
		buildStartCommandFromTemplate(template, hotendTemp, bedTemp, minX, minY, maxX, maxY) {
			const code = String(template || "").trim();
			if (!code) {
				throw new Error("Startcode ist leer");
			}
			return this.applyTemplatePlaceholders(code, {
				hotendTemp: fmt(hotendTemp, 2),
				bedTemp: fmt(bedTemp, 2),
				minX: fmt(minX, 3),
				minY: fmt(minY, 3),
				maxX: fmt(maxX, 3),
				maxY: fmt(maxY, 3),
				extruder0_temperature: fmt(hotendTemp, 2),
				bed0_temperature: fmt(bedTemp, 2),
				build_min_x: fmt(minX, 3),
				build_min_y: fmt(minY, 3),
				build_max_x: fmt(maxX, 3),
				build_max_y: fmt(maxY, 3)
			});
		},
		addEndSequenceFromTemplate(lines, template, values = {}) {
			const code = String(template || "").trim();
			if (!code) {
				throw new Error("Endcode ist leer");
			}
			const rendered = this.applyTemplatePlaceholders(code, values);
			const endLines = rendered.split(/\r?\n/).map(item => item.trim()).filter(item => item.length > 0);
			lines.push(...endLines);
		},
				buildFlowTestJob() {
			const p = this.flowTest || {};
			const sp = this.sharedPrint || {};
			const sb = this.sharedBed || {};
			const testMode = String(p.testMode || DEFAULT_FLOW_TEST.testMode).toLowerCase();
			const bedMinX = toNum(sb.minX, DEFAULT_SHARED_BED.minX);
			const bedMaxX = toNum(sb.maxX, DEFAULT_SHARED_BED.maxX);
			const bedMinY = toNum(sb.minY, DEFAULT_SHARED_BED.minY);
			const bedMaxY = toNum(sb.maxY, DEFAULT_SHARED_BED.maxY);
			const margin = Math.max(0, toNum(sp.meshMargin, DEFAULT_SHARED_PRINT.meshMargin));
			const materialName = String(sp.materialName || "").trim();
			const nozzleDia = toNum(sp.nozzleDia, DEFAULT_SHARED_PRINT.nozzleDia);
			const layerH = toNum(sp.layerH, DEFAULT_SHARED_PRINT.layerH);
			const lineW = toNum(sp.lineW, DEFAULT_SHARED_PRINT.lineW);
			const hotendTemp = toNum(p.hotendTemp, toNum(sp.hotendTemp, DEFAULT_SHARED_PRINT.hotendTemp));
			const bedTemp = toNum(p.bedTemp, toNum(sp.bedTemp, DEFAULT_SHARED_PRINT.bedTemp));
			const fanPct = Math.max(0, Math.min(100, toNum(sp.fanPct, DEFAULT_SHARED_PRINT.fanPct)));
			const flowPct = Math.max(1, toNum(sp.flowPct, DEFAULT_SHARED_PRINT.flowPct));
			const firstLayerSpeed = toNum(sp.firstLayerSpeed, DEFAULT_SHARED_PRINT.firstLayerSpeed);
			const travelSpeed = toNum(sp.travelSpeed, DEFAULT_SHARED_PRINT.travelSpeed);
			const padW = toNum(sp.levelPadW, DEFAULT_SHARED_PRINT.levelPadW);
			const padH = toNum(sp.levelPadH, DEFAULT_SHARED_PRINT.levelPadH);
			const padGap = toNum(sp.levelPadGap, DEFAULT_SHARED_PRINT.levelPadGap);
			const startTemplate = String(this.startCode || "").trim();
			const endTemplate = String(this.endCode || "").trim();

			if (bedMaxX <= bedMinX || bedMaxY <= bedMinY) throw new Error("Bett-Min/Max ungueltig");
			if (nozzleDia <= 0 || layerH <= 0 || lineW <= 0) throw new Error("Nozzle/Layer/Line muss > 0 sein");
			if (firstLayerSpeed <= 0 || travelSpeed <= 0) throw new Error("Geschwindigkeiten muessen > 0 sein");
			if (padW <= lineW * 2 || padH <= lineW * 2) throw new Error("Pad-Groesse in Einstellungen zu klein");
			if (padGap < 0) throw new Error("Pad-Abstand darf nicht negativ sein");
			if (!startTemplate || !endTemplate) throw new Error("Start-/Endcode darf nicht leer sein");

			const printableW = (bedMaxX - bedMinX) - (2 * margin);
			const printableH = (bedMaxY - bedMinY) - (2 * margin);
			if (printableW <= 0 || printableH <= 0) throw new Error("Sicherheitsrand zu gross");

			const areaMinX = bedMinX + margin;
			const areaMinY = bedMinY + margin;
			const areaMaxX = bedMaxX - margin;
			const areaMaxY = bedMaxY - margin;
			const isAdvancedGrid = Boolean(sp.levelGridAdvanced);
			const padCountX = isAdvancedGrid ? Math.max(2, Math.floor(toNum(sp.levelPadCountX, 3))) : 3;
			const padCountY = isAdvancedGrid ? Math.max(2, Math.floor(toNum(sp.levelPadCountY, 3))) : 3;
			const modeLabel = testMode === "full" ? "Vollflaeche" : `Prusa Grid ${padCountX}x${padCountY}`;

			const startCode = this.buildStartCommandFromTemplate(startTemplate, hotendTemp, bedTemp, areaMinX, areaMinY, areaMaxX, areaMaxY);
			const filArea = Math.PI * Math.pow(1.75 / 2, 2);
			const ePerMM = ((lineW * layerH) / filArea) * (flowPct / 100);
			const drawF = firstLayerSpeed * 60;
			const moveF = travelSpeed * 60;

			const lines = [];
			let eTotal = 0;
			let currentX = null;
			let currentY = null;

			lines.push("; Auto-generated Level Test (first layer)");
			lines.push(startCode);
			lines.push("G90");
			lines.push("M82");
			lines.push("G92 E0");
			lines.push(`M106 S${fmt(fanPct / 100, 4)}`);
			lines.push(`G1 Z${fmt(layerH, 3)} F1200`);
			lines.push(`M118 S"Level Test Start (${modeLabel}): ${materialName || "Material"}"`);

			const moveTo = (x, y) => {
				lines.push(`G1 X${fmt(x, 3)} Y${fmt(y, 3)} F${fmt(moveF, 0)}`);
				currentX = x;
				currentY = y;
			};

			const extrudeTo = (x, y, feed = drawF, factor = 1) => {
				if (currentX === null || currentY === null) {
					moveTo(x, y);
					return;
				}
				const dx = x - currentX;
				const dy = y - currentY;
				const dist = Math.sqrt((dx * dx) + (dy * dy));
				if (dist <= 0) {
					return;
				}
				eTotal += dist * ePerMM * factor;
				lines.push(`G1 X${fmt(x, 3)} Y${fmt(y, 3)} F${fmt(feed, 0)} E${fmt(eTotal, 5)}`);
				currentX = x;
				currentY = y;
			};

			const drawPad = (cx, cy, width, height) => {
				const x0 = cx - (width / 2);
				const y0 = cy - (height / 2);
				const x1 = cx + (width / 2);
				const y1 = cy + (height / 2);

				moveTo(x0, y0);
				extrudeTo(x1, y0);
				extrudeTo(x1, y1);
				extrudeTo(x0, y1);
				extrudeTo(x0, y0);

				const inset = lineW;
				const fx0 = x0 + inset;
				const fx1 = x1 - inset;
				const fy0 = y0 + inset;
				const fy1 = y1 - inset;
				if (fx1 <= fx0 || fy1 <= fy0) {
					return;
				}

				const fillSpacing = lineW;
				moveTo(fx0, fy0);
				let y = fy0;
				let dir = 1;
				while (y <= (fy1 + 0.0001)) {
					extrudeTo(dir > 0 ? fx1 : fx0, y);
					const nextY = y + fillSpacing;
					if (nextY <= (fy1 + 0.0001)) {
						extrudeTo(dir > 0 ? fx1 : fx0, nextY);
					}
					y = nextY;
					dir *= -1;
				}
			};

			const drawFullArea = () => {
				const x0 = areaMinX;
				const y0 = areaMinY;
				const x1 = areaMaxX;
				const y1 = areaMaxY;

				// Outer perimeters first (slicer-like order)
				const perimeterCount = 2;
				for (let i = 0; i < perimeterCount; i++) {
					const off = i * lineW;
					const px0 = x0 + off;
					const py0 = y0 + off;
					const px1 = x1 - off;
					const py1 = y1 - off;
					if (px1 <= px0 || py1 <= py0) {
						break;
					}
					moveTo(px0, py0);
					extrudeTo(px1, py0);
					extrudeTo(px1, py1);
					extrudeTo(px0, py1);
					extrudeTo(px0, py0);
				}

				// Diagonal infill (45 deg), connected in snake order where possible
				const inset = perimeterCount * lineW;
				const fx0 = x0 + inset;
				const fx1 = x1 - inset;
				const fy0 = y0 + inset;
				const fy1 = y1 - inset;
				if (fx1 <= fx0 || fy1 <= fy0) {
					return;
				}

				const spacing = lineW;
				const kMin = fx0 - fy1;
				const kMax = fx1 - fy0;
				const segments = [];
				for (let k = kMin; k <= (kMax + 0.0001); k += spacing) {
					const pts = [];
					const yAtX0 = fx0 - k;
					if (yAtX0 >= fy0 && yAtX0 <= fy1) pts.push([fx0, yAtX0]);
					const yAtX1 = fx1 - k;
					if (yAtX1 >= fy0 && yAtX1 <= fy1) pts.push([fx1, yAtX1]);
					const xAtY0 = k + fy0;
					if (xAtY0 >= fx0 && xAtY0 <= fx1) pts.push([xAtY0, fy0]);
					const xAtY1 = k + fy1;
					if (xAtY1 >= fx0 && xAtY1 <= fx1) pts.push([xAtY1, fy1]);

					const unique = [];
					for (const p of pts) {
						if (!unique.some(q => Math.abs(q[0] - p[0]) < 0.0001 && Math.abs(q[1] - p[1]) < 0.0001)) {
							unique.push(p);
						}
					}
					if (unique.length >= 2) {
						unique.sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));
						segments.push([unique[0], unique[1]]);
					}
				}

				for (let i = 0; i < segments.length; i++) {
					const seg = segments[i];
					const a = seg[0];
					const b = seg[1];
					const start = (i % 2 === 0) ? a : b;
					const end = (i % 2 === 0) ? b : a;
					moveTo(start[0], start[1]);
					extrudeTo(end[0], end[1]);
				}
			};

			const drawPrusaGrid = () => {
				const minGap = Math.max(0, padGap);
				const maxPadW = (printableW - ((padCountX - 1) * minGap)) / padCountX;
				const maxPadH = (printableH - ((padCountY - 1) * minGap)) / padCountY;
				if (maxPadW <= lineW * 3 || maxPadH <= lineW * 3) {
					throw new Error(`Bettflaeche zu klein fuer ${padCountX}x${padCountY} Grid mit aktuellem Rand/Pad-Abstand`);
				}

				const padWidthUsed = Math.min(padW, maxPadW);
				const padHeightUsed = Math.min(padH, maxPadH);
				const gapX = padCountX > 1 ? (printableW - (padCountX * padWidthUsed)) / (padCountX - 1) : 0;
				const gapY = padCountY > 1 ? (printableH - (padCountY * padHeightUsed)) / (padCountY - 1) : 0;
				if (gapX < 0 || gapY < 0) {
					throw new Error("Pad-Groesse passt nicht in den verfuegbaren Druckbereich");
				}

				const xCenters = [];
				for (let x = 0; x < padCountX; x++) {
					xCenters.push(areaMinX + (padWidthUsed / 2) + (x * (padWidthUsed + gapX)));
				}
				const yCenters = [];
				for (let y = 0; y < padCountY; y++) {
					yCenters.push(areaMinY + (padHeightUsed / 2) + (y * (padHeightUsed + gapY)));
				}

				const connectorFactor = 0.65;
				for (const y of yCenters) {
					for (let x = 0; x < xCenters.length - 1; x++) {
						moveTo(xCenters[x] + (padWidthUsed / 2), y);
						extrudeTo(xCenters[x + 1] - (padWidthUsed / 2), y, drawF, connectorFactor);
					}
				}
				for (const x of xCenters) {
					for (let y = 0; y < yCenters.length - 1; y++) {
						moveTo(x, yCenters[y] + (padHeightUsed / 2));
						extrudeTo(x, yCenters[y + 1] - (padHeightUsed / 2), drawF, connectorFactor);
					}
				}

				const rowIndices = [];
				for (let y = yCenters.length - 1; y >= 0; y--) {
					rowIndices.push(y);
				}
				for (let r = 0; r < rowIndices.length; r++) {
					const yIndex = rowIndices[r];
					if (r % 2 === 0) {
						for (let x = 0; x < xCenters.length; x++) {
							drawPad(xCenters[x], yCenters[yIndex], padWidthUsed, padHeightUsed);
						}
					} else {
						for (let x = xCenters.length - 1; x >= 0; x--) {
							drawPad(xCenters[x], yCenters[yIndex], padWidthUsed, padHeightUsed);
						}
					}
				}
			};

			if (testMode === "full") {
				drawFullArea();
			} else {
				drawPrusaGrid();
			}

			this.addEndSequenceFromTemplate(lines, endTemplate, {
				hotendTemp: fmt(hotendTemp, 2),
				bedTemp: fmt(bedTemp, 2),
				minX: fmt(areaMinX, 3),
				minY: fmt(areaMinY, 3),
				maxX: fmt(areaMaxX, 3),
				maxY: fmt(areaMaxY, 3),
				materialName,
				patchCount: "1",
				extruder0_temperature: fmt(hotendTemp, 2),
				bed0_temperature: fmt(bedTemp, 2),
				build_min_x: fmt(areaMinX, 3),
				build_min_y: fmt(areaMinY, 3),
				build_max_x: fmt(areaMaxX, 3),
				build_max_y: fmt(areaMaxY, 3)
			});
			lines.push(`M291 P"Level Test fertig (${modeLabel})." R"Level Test" S1 T8`);
			lines.push("");
			return lines.join("\n");
		},
		async startFlowTest() {
			try {
				const fileName = `_Kalibrierung/flow-first-layer-test-${Date.now()}.g`;
				const fullPath = `0:/gcodes/${fileName}`;
				const content = this.buildFlowTestJob();
				await this.uploadJob(fullPath, content);
				this.registerGeneratedTestFile(fullPath);
				await this.sendCode(`M32 "${fileName}"`);
				this.lastJobFile = fileName;
				this.setFlowTestMessage("Level Test gestartet", "info");
			} catch (error) {
				this.setFlowTestMessage(error.message || "Level Test konnte nicht gestartet werden", "error");
			}
		},
		buildPaTuningJob() {
			const p = this.paTuning || {};
			const sp = this.sharedPrint || {};
			const bedTemp = toNum(p.bedTemp, toNum(sp.bedTemp, DEFAULT_SHARED_PRINT.bedTemp));
			const hotendTemp = toNum(p.hotendTemp, toNum(sp.hotendTemp, DEFAULT_SHARED_PRINT.hotendTemp));
			const flowFactor = toNum(p.flowFactor, DEFAULT_PA_TUNING.flowFactor);
			const startPA = toNum(p.startPA, DEFAULT_PA_TUNING.startPA);
			const endPA = toNum(p.endPA, DEFAULT_PA_TUNING.endPA);
			const stepPA = toNum(p.stepPA, DEFAULT_PA_TUNING.stepPA);
			const zFirst = toNum(p.zFirst, DEFAULT_PA_TUNING.zFirst);
			const vPrint = toNum(sp.printSpeed, DEFAULT_SHARED_PRINT.printSpeed);
			const accel = toNum(p.accel, DEFAULT_PA_TUNING.accel);
			const scale = toNum(p.scale, DEFAULT_PA_TUNING.scale);
			const lineLen = DEFAULT_PA_TUNING.lineLen * scale;
			const gapY = DEFAULT_PA_TUNING.gapY * scale;
			const labelOffsetX = DEFAULT_PA_TUNING.labelOffsetX * scale;
			const labelDy = DEFAULT_PA_TUNING.labelDy * scale;
			const digitW = DEFAULT_PA_TUNING.digitW * scale;
			const digitH = DEFAULT_PA_TUNING.digitH * scale;
			const digitGap = DEFAULT_PA_TUNING.digitGap * scale;
			const lineW = toNum(p.lineW, DEFAULT_PA_TUNING.lineW) * scale;
			const layerH = toNum(sp.layerH, DEFAULT_SHARED_PRINT.layerH);
			const filDia = toNum(p.filDia, DEFAULT_PA_TUNING.filDia);
			const offsetX = toNum(p.offsetX, DEFAULT_PA_TUNING.offsetX);
			const offsetY = toNum(p.offsetY, DEFAULT_PA_TUNING.offsetY);
			const doFrame = Boolean(p.doFrame);
			const frameLoops = DEFAULT_PA_TUNING.frameLoops;
			const frameWidth = DEFAULT_PA_TUNING.frameWidth * scale;
			const frameGap = DEFAULT_PA_TUNING.frameGap * scale;
			const frameExtraY = DEFAULT_PA_TUNING.frameExtraY * scale;
			const tieEveryN = DEFAULT_PA_TUNING.tieEveryN;
			const travelRetract = Math.max(0, toNum(p.travelRetract, DEFAULT_PA_TUNING.travelRetract));
			const travelZhop = Math.max(0, toNum(p.travelZhop, DEFAULT_PA_TUNING.travelZhop));
			const fRetract = toNum(p.fRetract, DEFAULT_PA_TUNING.fRetract);
			const fZ = toNum(p.fZ, DEFAULT_PA_TUNING.fZ);
			const fMove = toNum(p.fMove, DEFAULT_PA_TUNING.fMove);
			const fFrame = toNum(p.fFrame, DEFAULT_PA_TUNING.fFrame);
			const paDrive = Math.max(0, Math.floor(toNum(p.paDrive, DEFAULT_PA_TUNING.paDrive)));

			if (stepPA <= 0) throw new Error("PA Schritt muss > 0 sein");
			if (endPA < startPA) throw new Error("PA Ende muss >= Start sein");
			if (gapY <= 0 || lineLen <= 0) throw new Error("GapY und Linienlaenge muessen > 0 sein");
			if (lineW <= 0 || layerH <= 0 || filDia <= 0) throw new Error("LineW/LayerH/FilDia muessen > 0 sein");
			if (scale <= 0) throw new Error("Skalierung muss > 0 sein");

			const nSeg = Math.floor(((endPA - startPA) / stepPA) + 0.5) + 1;
			if (nSeg < 1) throw new Error("PA Bereich/Schritt ungueltig");
			if (nSeg > 200) throw new Error("Zu viele Segmente (>200)");

			const yFirst = gapY;
			const yLast = nSeg * gapY;
			const yMinFrame = yFirst - frameExtraY;
			const yMaxFrame = yLast + frameExtraY;
			const labelWidth = (2 * digitW) + digitGap;
			const x0 = 0;
			const labelX = x0 + lineLen + labelOffsetX;
			const lx1 = x0 - frameGap - frameWidth;
			const lx2 = x0 - frameGap;
			const rx1 = labelX + labelWidth + frameGap;
			const rx2 = rx1 + frameWidth;
			const areaMinX = lx1 - 3;
			const areaMinY = yMinFrame - 3;
			const areaMaxX = rx2 + 3;
			const areaMaxY = yMaxFrame + 3;

			const axes = this.model?.move?.axes || [];
			const bedMinX = toNum(axes[0]?.min, 0);
			const bedMaxX = toNum(axes[0]?.max, 250);
			const bedMinY = toNum(axes[1]?.min, 0);
			const bedMaxY = toNum(axes[1]?.max, 210);
			const bedCenterX = (bedMinX + bedMaxX) / 2;
			const bedCenterY = (bedMinY + bedMaxY) / 2;
			const areaCenterX = (areaMinX + areaMaxX) / 2;
			const areaCenterY = (areaMinY + areaMaxY) / 2;
			const shiftX = (bedCenterX - areaCenterX) + offsetX;
			const shiftY = (bedCenterY - areaCenterY) + offsetY;
			const sx = (v) => v + shiftX;
			const sy = (v) => v + shiftY;

			const startCommand = this.buildStartCommand(
				hotendTemp,
				bedTemp,
				sx(areaMinX),
				sy(areaMinY),
				sx(areaMaxX),
				sy(areaMaxY)
			);

			const lines = [];
			let eTotal = 0;
			const ePerMM = (lineW * layerH) / (Math.PI * Math.pow(filDia / 2, 2));
			const feed = vPrint * 60;
			const primeLen = Math.min(110 * scale, lineLen + (20 * scale));

			const retract = () => {
				eTotal = Math.max(0, eTotal - travelRetract);
				lines.push(`G1 E${fmt(eTotal, 5)} F${fmt(fRetract, 0)}`);
			};
			const prime = () => {
				eTotal += travelRetract;
				lines.push(`G1 E${fmt(eTotal, 5)} F${fmt(fRetract, 0)}`);
			};
			const travelTo = (x, y) => {
				retract();
				lines.push(`G1 Z${fmt(zFirst + travelZhop, 3)} F${fmt(fZ, 0)}`);
				lines.push(`G1 X${fmt(x, 3)} Y${fmt(y, 3)} F${fmt(fMove, 0)}`);
				lines.push(`G1 Z${fmt(zFirst, 3)} F${fmt(fZ, 0)}`);
				prime();
			};
			const extrudeTo = (x, y, dist, f) => {
				eTotal += Math.abs(dist) * ePerMM;
				lines.push(`G1 X${fmt(x, 3)} Y${fmt(y, 3)} E${fmt(eTotal, 5)} F${fmt(f, 0)}`);
			};

			lines.push("; Auto-generated PA tuning test");
			lines.push(startCommand);
			lines.push("G90");
			lines.push("M82");
			lines.push("G92 E0");
			lines.push("T0");
			lines.push(`M204 P${fmt(accel, 0)} T${fmt(accel, 0)}`);
			lines.push(`M221 S${fmt(flowFactor * 100, 3)}`);
			lines.push(`G1 Z10 F${fmt(fMove, 0)}`);
			lines.push(`G1 X${fmt(sx(x0), 3)} Y${fmt(sy(0), 3)} F${fmt(fMove, 0)}`);
			lines.push(`G1 Z${fmt(zFirst, 3)} F${fmt(fZ, 0)}`);
			lines.push("G92 E0");
			eTotal = 0;
			extrudeTo(sx(x0 + primeLen), sy(0), primeLen, 1200);
			lines.push("G92 E0");
			eTotal = 0;

			if (doFrame && frameLoops > 0) {
				for (let k = 0; k < frameLoops; k++) {
					const off = k * 0.6 * scale;
					const leftX1 = sx(lx1 - off);
					const leftX2 = sx(lx2 + off);
					const rightX1 = sx(rx1 - off);
					const rightX2 = sx(rx2 + off);
					const y1 = sy(yMinFrame - off);
					const y2 = sy(yMaxFrame + off);

					lines.push(`G1 X${fmt(leftX1, 3)} Y${fmt(y1, 3)} F${fmt(fMove, 0)}`);
					extrudeTo(leftX2, y1, leftX2 - leftX1, fFrame);
					extrudeTo(leftX2, y2, y2 - y1, fFrame);
					extrudeTo(leftX1, y2, leftX2 - leftX1, fFrame);
					extrudeTo(leftX1, y1, y2 - y1, fFrame);

					lines.push(`G1 X${fmt(rightX1, 3)} Y${fmt(y1, 3)} F${fmt(fMove, 0)}`);
					extrudeTo(rightX2, y1, rightX2 - rightX1, fFrame);
					extrudeTo(rightX2, y2, y2 - y1, fFrame);
					extrudeTo(rightX1, y2, rightX2 - rightX1, fFrame);
					extrudeTo(rightX1, y1, y2 - y1, fFrame);
				}

				lines.push(`G1 X${fmt(sx(lx2), 3)} Y${fmt(sy(yMinFrame), 3)} F${fmt(fMove, 0)}`);
				extrudeTo(sx(rx1), sy(yMinFrame), rx1 - lx2, fFrame);
				lines.push(`G1 X${fmt(sx(lx2), 3)} Y${fmt(sy(yMaxFrame), 3)} F${fmt(fMove, 0)}`);
				extrudeTo(sx(rx1), sy(yMaxFrame), rx1 - lx2, fFrame);
			}

			let pa = startPA;
			for (let i = 0; i < nSeg; i++) {
				const y = (i + 1) * gapY;
				const yAbs = sy(y);
				lines.push(`M572 D${paDrive} S${fmt(pa, 4)}`);

				if (doFrame && tieEveryN > 0 && (i % tieEveryN) === 0) {
					travelTo(sx(lx2), yAbs);
					extrudeTo(sx(x0), yAbs, x0 - lx2, fFrame);
					travelTo(sx(x0 + lineLen), yAbs);
					extrudeTo(sx(rx1), yAbs, rx1 - (x0 + lineLen), fFrame);
				}

				travelTo(sx(x0), yAbs);
				extrudeTo(sx(x0 + lineLen), yAbs, lineLen, feed);
				extrudeTo(sx(x0), yAbs, lineLen, feed);

				let pa100 = Math.floor((pa * 100) + 0.5);
				pa100 = Math.max(0, Math.min(99, pa100));
				const labelState = { e: eTotal };
				const labelCfg = {
					ePerMM: ePerMM * 0.85,
					travelRetract,
					travelZhop,
					fRetract,
					fZ,
					fMove,
					fDraw: fFrame,
					digitW,
					digitH,
					digitGap
				};
				const labelBox = (2 * digitW) + digitGap + (2 * scale);
				this.drawLabel(lines, labelState, pa100, sx(labelX), sy(y + labelDy), labelBox, zFirst, labelCfg);
				eTotal = labelState.e;

				pa += stepPA;
			}

			lines.push(`M572 D${paDrive} S0`);
			lines.push("M221 S100");
			retract();
			lines.push(`G1 Z25 F${fmt(fMove, 0)}`);
			this.addDefaultEndSequence(lines, {
				hotendTemp: fmt(hotendTemp, 2),
				bedTemp: fmt(bedTemp, 2),
				minX: fmt(sx(areaMinX), 3),
				minY: fmt(sy(areaMinY), 3),
				maxX: fmt(sx(areaMaxX), 3),
				maxY: fmt(sy(areaMaxY), 3)
			});
			lines.push("M118 S\"PA Test fertig\" ");
			lines.push("");
			return lines.join("\n");
		},
		async startPaTuning() {
			try {
				const fileName = `_Kalibrierung/pa-test-${Date.now()}.g`;
				const fullPath = `0:/gcodes/${fileName}`;
				const content = this.buildPaTuningJob();
				await this.uploadJob(fullPath, content);
				this.registerGeneratedTestFile(fullPath);
				await this.sendCode(`M32 "${fileName}"`);
				this.lastJobFile = fileName;
				this.setPaMessage("PA Test gestartet", "info");
			} catch (error) {
				this.setPaMessage(error.message || "PA Test konnte nicht gestartet werden", "error");
			}
		},
		async savePaTuningMacro() {
			try {
				const content = this.buildPaTuningJob();
				const path = this.sanitizeMacroPath(this.paTuning.savePath, "PA_Test_Label.g");
				await this.uploadMacro(path, content);
				this.setPaMessage(`Macro gespeichert: ${path}`, "info");
			} catch (error) {
				this.setPaMessage(error.message || "PA Macro konnte nicht gespeichert werden", "error");
			}
		},
		buildBoxFlowTestJob() {
			const p = this.boxTest || {};
			const sp = this.sharedPrint || {};
			const hotendTemp = toNum(p.H, toNum(sp.hotendTemp, DEFAULT_SHARED_PRINT.hotendTemp));
			const bedTemp = toNum(p.B, toNum(sp.bedTemp, DEFAULT_SHARED_PRINT.bedTemp));
			const nozzleDia = toNum(sp.nozzleDia, DEFAULT_SHARED_PRINT.nozzleDia);
			const layerH = toNum(sp.layerH, DEFAULT_SHARED_PRINT.layerH);
			const printSpeed = Math.max(1, toNum(sp.printSpeed, DEFAULT_SHARED_PRINT.printSpeed));
			const firstLayerSpeed = Math.max(1, toNum(sp.firstLayerSpeed, DEFAULT_SHARED_PRINT.firstLayerSpeed));
			const boxSize = toNum(p.S, DEFAULT_BOX_TEST.S);
			const layers = Math.floor(toNum(p.Z, DEFAULT_BOX_TEST.Z));
			const startX = toNum(p.X, DEFAULT_BOX_TEST.X);
			const startY = toNum(p.Y, DEFAULT_BOX_TEST.Y);
			const margin = Math.max(0, toNum(sp.meshMargin, DEFAULT_SHARED_PRINT.meshMargin));
			const fanPct = Math.max(0, Math.min(100, toNum(sp.fanPct, DEFAULT_SHARED_PRINT.fanPct)));
			const rawW = p.W;
			const hasWOverride = rawW !== null && rawW !== undefined && rawW !== "";

			if (hotendTemp < 0) throw new Error("H muss >= 0 sein");
			if (bedTemp < 0) throw new Error("B muss >= 0 sein");
			if (layerH <= 0) throw new Error("L muss > 0 sein");
			if (boxSize <= 5) throw new Error("S ist zu klein");
			if (layers <= 0) throw new Error("Z muss > 0 sein");
			if (margin < 0) throw new Error("M muss >= 0 sein");

			const nozzleMap = {
				0.25: 0.30,
				0.4: 0.48,
				0.5: 0.60,
				0.6: 0.72,
				0.8: 0.96
			};
			const mappedWidth = nozzleMap[Number(nozzleDia)];
			if (!mappedWidth) {
				throw new Error("N nicht unterstuetzt. Erlaubt: 0.25, 0.4, 0.5, 0.6, 0.8");
			}
			let lineW = mappedWidth;
			if (hasWOverride) {
				lineW = toNum(rawW, -1);
			}
			if (lineW <= 0) throw new Error("W muss > 0 sein");

			const minX = startX - margin;
			const minY = startY - margin;
			const maxX = startX + boxSize + margin;
			const maxY = startY + boxSize + margin;

			const startCode = this.buildStartCommand(hotendTemp, bedTemp, minX, minY, maxX, maxY);

			const filDia = 1.75;
			const area = Math.PI * Math.pow(filDia / 2, 2);
			const ePerMM = (lineW * layerH) / area;
			const eEdge = ePerMM * boxSize;
			const brimLines = 4;
			const brimStep = lineW;
			const brimOuter = boxSize + (2 * brimLines * brimStep);
			const brimX0 = startX - (brimLines * brimStep);
			const brimY0 = startY - (brimLines * brimStep);
			const fanS = fanPct / 100;
			const firstLayerPrintF = firstLayerSpeed * 60;
			const printF = printSpeed * 60;

			const lines = [];
			let eTotal = 0;

			lines.push("; Auto-generated Flow-Test box job");
			lines.push(startCode);
			lines.push("M106 S0");
			lines.push("G90");
			lines.push("M82");
			lines.push("G92 E0");
			lines.push(`G1 X${fmt(startX, 3)} Y${fmt(startY, 3)} F9000`);
			lines.push(`G1 Z${fmt(layerH, 3)} F1200`);

			for (let i = 0; i < layers; i++) {
				if (i === 2) {
					lines.push(`M106 S${fmt(fanS, 4)}`);
				}

				const zNow = layerH * (i + 1);
				lines.push(`G1 Z${fmt(zNow, 3)} F900`);

				if (i < 2) {
					for (let b = 0; b < brimLines; b++) {
						const ringSize = brimOuter - (2 * b * brimStep);
						const rx = brimX0 + (b * brimStep);
						const ry = brimY0 + (b * brimStep);
						const eRingEdge = ePerMM * ringSize;

						lines.push(`G1 X${fmt(rx, 3)} Y${fmt(ry, 3)} F9000`);
						eTotal += eRingEdge;
						lines.push(`G1 X${fmt(rx + ringSize, 3)} Y${fmt(ry, 3)} F${fmt(i === 0 ? firstLayerPrintF : printF, 0)} E${fmt(eTotal, 5)}`);
						eTotal += eRingEdge;
						lines.push(`G1 X${fmt(rx + ringSize, 3)} Y${fmt(ry + ringSize, 3)} E${fmt(eTotal, 5)}`);
						eTotal += eRingEdge;
						lines.push(`G1 X${fmt(rx, 3)} Y${fmt(ry + ringSize, 3)} E${fmt(eTotal, 5)}`);
						eTotal += eRingEdge;
						lines.push(`G1 X${fmt(rx, 3)} Y${fmt(ry, 3)} E${fmt(eTotal, 5)}`);
					}
				}

				eTotal += eEdge;
				lines.push(`G1 X${fmt(startX + boxSize, 3)} Y${fmt(startY, 3)} F${fmt(i === 0 ? firstLayerPrintF : printF, 0)} E${fmt(eTotal, 5)}`);
				eTotal += eEdge;
				lines.push(`G1 X${fmt(startX + boxSize, 3)} Y${fmt(startY + boxSize, 3)} E${fmt(eTotal, 5)}`);
				eTotal += eEdge;
				lines.push(`G1 X${fmt(startX, 3)} Y${fmt(startY + boxSize, 3)} E${fmt(eTotal, 5)}`);
				eTotal += eEdge;
				lines.push(`G1 X${fmt(startX, 3)} Y${fmt(startY, 3)} E${fmt(eTotal, 5)}`);
			}

			this.addDefaultEndSequence(lines, {
				hotendTemp: fmt(hotendTemp, 2),
				bedTemp: fmt(bedTemp, 2),
				minX: fmt(minX, 3),
				minY: fmt(minY, 3),
				maxX: fmt(maxX, 3),
				maxY: fmt(maxY, 3)
			});
			lines.push(`M118 S"Flow-Test: Duese=${fmt(nozzleDia, 2)}mm Soll-Wand=${fmt(lineW, 3)}mm"`);
			lines.push(`M291 P"Flow-Test fertig. N=${fmt(nozzleDia, 2)}mm, W=${fmt(lineW, 3)}mm" R"Flow-Test" S1 T12`);
			lines.push("");
			return lines.join("\n");
		},
		async startBoxFlowTest() {
			try {
				const fileName = `_Kalibrierung/flow-box-test-${Date.now()}.g`;
				const fullPath = `0:/gcodes/${fileName}`;
				const content = this.buildBoxFlowTestJob();
				await this.uploadJob(fullPath, content);
				this.registerGeneratedTestFile(fullPath);
				await this.sendCode(`M32 "${fileName}"`);
				this.lastJobFile = fileName;
				this.setBoxTestMessage("Flow-Test (Einzelwand-Box) gestartet", "info");
			} catch (error) {
				this.setBoxTestMessage(error.message || "Flow-Test konnte nicht gestartet werden", "error");
			}
		},
		addRetractMove(lines, state, amount, feed) {
			state.e = Math.max(0, state.e - amount);
			lines.push(`G1 E${fmt(state.e, 5)} F${fmt(feed, 0)}`);
		},
		addPrimeMove(lines, state, amount, feed) {
			state.e = state.e + amount;
			lines.push(`G1 E${fmt(state.e, 5)} F${fmt(feed, 0)}`);
		},
		addTravel(lines, state, x, y, z, cfg) {
			this.addRetractMove(lines, state, cfg.travelRetract, cfg.fRetract);
			lines.push(`G1 Z${fmt(z + cfg.travelZhop, 3)} F${fmt(cfg.fZ, 0)}`);
			lines.push(`G1 X${fmt(x, 3)} Y${fmt(y, 3)} F${fmt(cfg.fMove, 0)}`);
			lines.push(`G1 Z${fmt(z, 3)} F${fmt(cfg.fZ, 0)}`);
			this.addPrimeMove(lines, state, cfg.travelRetract, cfg.fRetract);
		},
		addExtrudeLine(lines, state, x, y, length, cfg) {
			state.e = state.e + (cfg.ePerMM * length);
			lines.push(`G1 X${fmt(x, 3)} Y${fmt(y, 3)} F${fmt(cfg.fDraw, 0)} E${fmt(state.e, 5)}`);
		},
		drawSegment(lines, state, seg, x, y, w, h, z, cfg) {
			if (seg === "A") {
				this.addTravel(lines, state, x, y + h, z, cfg);
				this.addExtrudeLine(lines, state, x + w, y + h, w, cfg);
			} else if (seg === "B") {
				this.addTravel(lines, state, x + w, y + h, z, cfg);
				this.addExtrudeLine(lines, state, x + w, y + (h / 2), h / 2, cfg);
			} else if (seg === "C") {
				this.addTravel(lines, state, x + w, y + (h / 2), z, cfg);
				this.addExtrudeLine(lines, state, x + w, y, h / 2, cfg);
			} else if (seg === "D") {
				this.addTravel(lines, state, x, y, z, cfg);
				this.addExtrudeLine(lines, state, x + w, y, w, cfg);
			} else if (seg === "E") {
				this.addTravel(lines, state, x, y + (h / 2), z, cfg);
				this.addExtrudeLine(lines, state, x, y, h / 2, cfg);
			} else if (seg === "F") {
				this.addTravel(lines, state, x, y + h, z, cfg);
				this.addExtrudeLine(lines, state, x, y + (h / 2), h / 2, cfg);
			} else if (seg === "G") {
				this.addTravel(lines, state, x, y + (h / 2), z, cfg);
				this.addExtrudeLine(lines, state, x + w, y + (h / 2), w, cfg);
			}
		},
		drawLabel(lines, state, labelValue, x, y, padSize, z, cfg) {
			const text = String(Math.round(labelValue));
			const charCount = text.length;
			const labelMargin = 1.2;
			const gap = cfg.digitGap;
			const availW = Math.max(6, padSize - (2 * labelMargin));
			const availH = Math.max(6, padSize - (2 * labelMargin));
			const minWidthForDigits = Math.max(availW - ((charCount - 1) * gap), charCount * 2.2);
			const maxDigitW = minWidthForDigits / charCount;
			const digitW = Math.max(2.2, Math.min(cfg.digitW, maxDigitW));
			const digitH = Math.min(availH, cfg.digitH * (digitW / cfg.digitW));
			const totalW = (charCount * digitW) + ((charCount - 1) * gap);
			let cursorX = x + ((padSize - totalW) / 2);
			const baseY = y + ((padSize - digitH) / 2);

			for (const ch of text.split("")) {
				if (ch === "-") {
					this.drawSegment(lines, state, "G", cursorX, baseY, digitW, digitH, z, cfg);
					cursorX += digitW + gap;
					continue;
				}
				const digit = Number(ch);
				const segs = SEGMENTS[digit] || [];
				for (const seg of segs) {
					this.drawSegment(lines, state, seg, cursorX, baseY, digitW, digitH, z, cfg);
				}
				cursorX += digitW + gap;
			}
		},
		buildJob() {
			const p = this.form;
			const sp = this.sharedPrint || {};
			const hotendTemp = toNum(p.H, toNum(sp.hotendTemp, DEFAULT_SHARED_PRINT.hotendTemp));
			const bedTemp = toNum(p.B, toNum(sp.bedTemp, DEFAULT_SHARED_PRINT.bedTemp));
			const nozzleDia = toNum(sp.nozzleDia, DEFAULT_SHARED_PRINT.nozzleDia);
			const layerH = toNum(sp.layerH, DEFAULT_SHARED_PRINT.layerH);
			const centerFlow = toNum(p.C, DEFAULT_FORM.C);
			const deltaFlow = toNum(p.D, DEFAULT_FORM.D);
			const stepFlow = toNum(p.R, DEFAULT_FORM.R);
			const fanPct = Math.max(0, Math.min(100, toNum(sp.fanPct, DEFAULT_SHARED_PRINT.fanPct)));
			const printSpeed = Math.max(1, toNum(sp.printSpeed, DEFAULT_SHARED_PRINT.printSpeed));
			const firstLayerSpeed = Math.max(1, toNum(sp.firstLayerSpeed, DEFAULT_SHARED_PRINT.firstLayerSpeed));
			const travelSpeed = Math.max(1, toNum(sp.travelSpeed, DEFAULT_SHARED_PRINT.travelSpeed));
			const padSize = toNum(p.P, DEFAULT_FORM.P);
			const gap = toNum(p.G, DEFAULT_FORM.G);
			const padLayers = Math.floor(toNum(p.Z, DEFAULT_FORM.Z));
			const margin = Math.max(0, toNum(sp.meshMargin, DEFAULT_SHARED_PRINT.meshMargin));
			const offsetX = toNum(p.X, DEFAULT_FORM.X);
			const offsetY = toNum(p.Y, DEFAULT_FORM.Y);

			if (layerH <= 0) throw new Error("Layerhoehe muss > 0 sein");
			if (padSize < 12) throw new Error("Padgroesse zu klein (min 12)");
			if (gap < 2) throw new Error("Abstand zu klein (min 2)");
			if (padLayers < 4) throw new Error("Layer je Pad muss >= 4 sein");
			if (stepFlow <= 0) throw new Error("Schritt muss > 0 sein");
			if (deltaFlow < 0) throw new Error("Delta muss >= 0 sein");

			const axes = this.model?.move?.axes || [];
			const xAxis = axes[0] || {};
			const yAxis = axes[1] || {};
			const bedMinX = toNum(xAxis.min, 0);
			const bedMaxX = toNum(xAxis.max, 250);
			const bedMinY = toNum(yAxis.min, 0);
			const bedMaxY = toNum(yAxis.max, 210);

			const lineW = this.resolveLineWidth(nozzleDia);
			if (lineW <= 0) throw new Error("Linienbreite ungueltig");

			const from = centerFlow - deltaFlow;
			const to = centerFlow + deltaFlow;
			const padCount = Math.floor(((to - from) / stepFlow) + 1);
			if (padCount < 1) throw new Error("Ungueltiger Flow Bereich");

			const cols = Math.min(5, padCount);
			const rows = Math.floor((padCount - 1) / cols) + 1;
			const totalW = (cols * padSize) + ((cols - 1) * gap);
			const totalH = (rows * padSize) + ((rows - 1) * gap);
			const centerX = (bedMinX + bedMaxX) / 2;
			const centerY = (bedMinY + bedMaxY) / 2;
			const startX = centerX - (totalW / 2) + offsetX;
			const startY = centerY - (totalH / 2) + offsetY;
			const minX = startX - margin;
			const minY = startY - margin;
			const maxX = startX + totalW + margin;
			const maxY = startY + totalH + margin;

			const filDia = 1.75;
			const areaFil = Math.PI * Math.pow(filDia / 2, 2);
			const ePerMM = (lineW * layerH) / areaFil;
			const cfg = {
				ePerMM,
				travelRetract: 0.20,
				travelZhop: 0.30,
				fRetract: 1800,
				fZ: 1200,
				fMove: travelSpeed * 60,
				fDraw: firstLayerSpeed * 60,
				digitW: 5.5,
				digitH: 9.0,
				digitGap: 1.6
			};

			const lines = [];
			const state = { e: 0 };
			const startCode = this.buildStartCommand(hotendTemp, bedTemp, minX, minY, maxX, maxY);

			lines.push("; Auto-generated Flow Plaettchen direct job");
			lines.push("; No /sys macro install, no external M98 required");
			lines.push(startCode);
			lines.push("M106 S0");
			lines.push("G90");
			lines.push("M82");
			lines.push("G92 E0");

			for (let layer = 0; layer < padLayers; layer++) {
				cfg.fDraw = (layer === 0 ? firstLayerSpeed : printSpeed) * 60;
				if (layer === 2) {
					lines.push(`M106 S${fmt(fanPct / 100, 4)}`);
				}
				const zNow = layerH * (layer + 1);
				lines.push(`G1 Z${fmt(zNow, 3)} F${fmt(cfg.fZ, 0)}`);

				let factor = from;
				for (let padIndex = 0; padIndex < padCount; padIndex++) {
					lines.push(`M221 S${fmt(factor, 3)}`);
					const col = padIndex % cols;
					const row = Math.floor(padIndex / cols);
					const px = startX + (col * (padSize + gap));
					const py = startY + (row * (padSize + gap));
					let yLine = py;
					let dir = (layer + padIndex) % 2;

					while (yLine <= (py + padSize + 0.0001)) {
						if (dir === 0) {
							this.addTravel(lines, state, px, yLine, zNow, cfg);
							this.addExtrudeLine(lines, state, px + padSize, yLine, padSize, cfg);
							dir = 1;
						} else {
							this.addTravel(lines, state, px + padSize, yLine, zNow, cfg);
							this.addExtrudeLine(lines, state, px, yLine, padSize, cfg);
							dir = 0;
						}
						yLine += lineW;
					}
					factor += stepFlow;
				}
			}

			const labelZ = layerH * padLayers;
			let factor = from;
			for (let idx = 0; idx < padCount; idx++) {
				const col = idx % cols;
				const row = Math.floor(idx / cols);
				const px = startX + (col * (padSize + gap));
				const py = startY + (row * (padSize + gap));
				lines.push(`M221 S${fmt(factor, 3)}`);
				this.drawLabel(lines, state, factor, px, py, padSize, labelZ, cfg);
				factor += stepFlow;
			}

			this.addDefaultEndSequence(lines, {
				hotendTemp: fmt(hotendTemp, 2),
				bedTemp: fmt(bedTemp, 2),
				minX: fmt(minX, 3),
				minY: fmt(minY, 3),
				maxX: fmt(maxX, 3),
				maxY: fmt(maxY, 3),
				materialName: this.sharedPrint.materialName || "",
				bestFlow: fmt(this.bestFlow, 3)
			});
			lines.push("M400");
			lines.push("; End of auto-generated Flow Plaettchen job");
			lines.push("");
			return lines.join("\n");
		},
		async startPrint() {
			try {
				const fileName = `_FlowPlaettchen/flow-test-${Date.now()}.g`;
				const fullPath = `0:/gcodes/${fileName}`;
				const content = this.buildJob();
				await this.uploadJob(fullPath, content);
				this.registerGeneratedTestFile(fullPath);
				await this.sendCode(`M32 "${fileName}"`);
				this.lastJobFile = fileName;
				this.setInfo("Flow-Test als direkter Druckjob gestartet");
			} catch (e) {
				this.setError(`Start fehlgeschlagen: ${e.message}`);
			}
		},
		async togglePause() {
			try {
				if (this.isPaused) {
					await this.sendCode("M24");
					this.setInfo("Druck wird fortgesetzt");
				} else {
					await this.sendCode("M25");
					this.setInfo("Druck pausiert");
				}
			} catch (e) {
				this.setError(`Pause/Fortsetzen fehlgeschlagen: ${e.message}`);
			}
		},
		async cancelPrint() {
			try {
				await this.sendCode("M0");
				this.setInfo("Druck abgebrochen");
			} catch (e) {
				this.setError(`Abbrechen fehlgeschlagen: ${e.message}`);
			}
		},
		async copyResult() {
			try {
				await navigator.clipboard.writeText(this.bestResultText);
				this.copyInfo = "Kopiert";
			} catch (e) {
				this.copyInfo = this.bestResultText;
			}
			setTimeout(() => {
				this.copyInfo = "";
			}, 2500);
		}
	}
};
</script>



