<template>
	<v-container fluid>
		<v-row>
			<v-col cols="12">
				<v-card outlined>
					<v-tabs v-if="calibrations.length" v-model="tab">
						<v-tab v-for="calibration in calibrations" :key="calibration.id" :href="`#${calibration.id}`">
							<v-icon v-if="calibration.icon" class="mr-1">{{ calibration.icon }}</v-icon>
							{{ calibration.title }}
						</v-tab>
					</v-tabs>

					<v-tabs-items v-if="calibrations.length" v-model="tab">
						<v-tab-item v-for="calibration in calibrations" :key="calibration.id" :value="calibration.id">
							<div class="px-4 pt-4" v-if="calibration.description">
								<div class="text-subtitle-2">{{ calibration.description }}</div>
							</div>
							<component :is="calibration.component" />
						</v-tab-item>
					</v-tabs-items>

					<v-card-text v-if="!calibrations.length">
						<v-alert dense outlined type="info">
							Keine Kalibrierungen registriert. Fuege neue Module in
							<code>src/plugins/Kalibrierung/calibrations/index.js</code> hinzu.
						</v-alert>
					</v-card-text>
				</v-card>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import calibrations from "./calibrations";

export default {
	data() {
		return {
			tab: calibrations.length ? calibrations[0].id : null,
			calibrations
		};
	}
};
</script>
