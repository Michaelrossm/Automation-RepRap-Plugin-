﻿'use strict'

import { registerRoute } from '@/routes'

import Kalibrierungs from './Kalibrierungs.vue'

registerRoute(Kalibrierungs, {
	Plugins: {
		Kalibrierung: {
			icon: 'mdi-hammer-wrench',
			caption: 'Kalibrierungs Plugin',
			translated: true,
			path: '/Plugins/Kalibrierung'
		}
	}
})
